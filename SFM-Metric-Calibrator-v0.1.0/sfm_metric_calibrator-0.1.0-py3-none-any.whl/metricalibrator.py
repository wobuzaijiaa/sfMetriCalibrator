import os
import sys
import time
import math
import re
import shutil
import tempfile
import traceback
import datetime as _dt
from pathlib import Path
import numpy as np
import cv2
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
import threading

try:
    import pycolmap
except ImportError as e:
    print(f"FATAL: pycolmap not installed: {e}")
    sys.exit(1)

try:
    import rerun as rr
    import rerun.blueprint as rrb
except ImportError as e:
    print(f"FATAL: rerun-sdk not installed: {e}")
    sys.exit(1)


# =============================================================================
# Module-level state
# =============================================================================

_recording_stream = None
_current_reconstruction = None
_current_reconstruction_path = None

_scale_anchors = []

REPROJ_WARN_PX = 3.0
_COLMAP_INVALID_PID = (1 << 64) - 1

_SUPPORTED_PINHOLE_MODELS = frozenset({
    "SIMPLE_PINHOLE", "PINHOLE", "SIMPLE_RADIAL", "RADIAL",
    "OPENCV", "FULL_OPENCV",
})

# Models where the manual (OpenCV-style) projection path is
# mathematically correct. FULL_OPENCV is deliberately excluded:
# without native pycolmap support it must be refused rather than
# approximated with the wrong distortion model.
_MANUAL_PINHOLE_MODELS = frozenset({
    "SIMPLE_PINHOLE", "PINHOLE", "SIMPLE_RADIAL", "RADIAL",
    "OPENCV",
})

# Triangulation quality gates. These are starting values, not
# universally optimal thresholds; they can be tightened or loosened
# at the call site. The parallax threshold is deliberately
# permissive: short-baseline handheld video frequently has under
# one degree of parallax between adjacent frames, and the residual
# and positive-depth checks already filter most bad geometry.
_MIN_TRI_ANGLE_RAD = math.radians(0.2)
_MAX_ACCEPTABLE_REPROJ_PX = 8.0


def _is_finite(x):
    try:
        return math.isfinite(float(x))
    except (TypeError, ValueError):
        return False


def _is_finite_positive(x):
    try:
        xf = float(x)
    except (TypeError, ValueError):
        return False
    return math.isfinite(xf) and xf > 0.0

_F32_MAX = float(np.finfo(np.float32).max)


def _fits_float32(x):
    """True iff x is a Python float that survives a round trip to a
    32-bit float. The PLY header declares coordinates as
    ``property float`` (32-bit), so a value that is finite in
    Python's 64-bit float can still overflow the declared format.
    """
    try:
        xf = float(x)
    except (TypeError, ValueError):
        return False
    return math.isfinite(xf) and abs(xf) <= _F32_MAX

def _slot_has_xyz(slot):
    return slot is not None and slot.get('xyz') is not None


# =============================================================================
# Pluggable value calculators
# =============================================================================

_target_value_script_path = None
_target_value_fn = None
_scale_value_script_path = None
_scale_value_fn = None


def _default_target_value(slot_a_xyz_list, slot_b_xyz_list):
    xa = (np.mean(np.asarray(slot_a_xyz_list, dtype=np.float64), axis=0)
          if slot_a_xyz_list else None)
    xb = (np.mean(np.asarray(slot_b_xyz_list, dtype=np.float64), axis=0)
          if slot_b_xyz_list else None)
    return xa, xb


def _default_scale_value(anchors):
    ratios = []
    for a in anchors:
        sfm = a.get('sfm', 0.0)
        metric = a.get('metric', 0.0)
        if not (_is_finite(sfm) and _is_finite(metric)):
            continue
        if sfm <= 0.0:
            continue
        r = metric / sfm
        if _is_finite_positive(r):
            ratios.append(r)
    return sum(ratios) / len(ratios) if ratios else None


def _load_value_script(path, fn_name):
    if not path:
        return None
    if not os.path.isfile(path):
        print(f"WARNING: value script not found: {path}")
        return None
    try:
        import importlib.util
        spec = importlib.util.spec_from_file_location(
            "_user_value_script", path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        fn = getattr(module, fn_name, None)
        if not callable(fn):
            raise RuntimeError(f"script must define a callable {fn_name}")
        return fn
    except Exception as e:
        print(f"WARNING: failed to load value script {path}: {e}")
        return None


def _set_target_value_script(path):
    global _target_value_script_path, _target_value_fn
    if not path:
        _target_value_script_path = None
        _target_value_fn = None
        return True
    fn = _load_value_script(path, "compute_target_value")
    if fn is None:
        return False
    _target_value_script_path = path
    _target_value_fn = fn
    return True


def _set_scale_value_script(path):
    global _scale_value_script_path, _scale_value_fn
    if not path:
        _scale_value_script_path = None
        _scale_value_fn = None
        return True
    fn = _load_value_script(path, "compute_scale")
    if fn is None:
        return False
    _scale_value_script_path = path
    _scale_value_fn = fn
    return True


def _compute_target_value(slot_a_xyz_list, slot_b_xyz_list):
    fn = _target_value_fn
    if fn is not None:
        try:
            result = fn(list(slot_a_xyz_list), list(slot_b_xyz_list))
            if isinstance(result, tuple) and len(result) == 2:
                return result
        except Exception as e:
            print(f"WARNING: target value script failed: {e}")
    return _default_target_value(slot_a_xyz_list, slot_b_xyz_list)


def _compute_scale_value(anchors):
    fn = _scale_value_fn
    if fn is not None:
        try:
            result = fn(list(anchors))
            if result is None:
                pass
            else:
                # Accept any numeric type that can be coerced to a
                # Python float (this includes numpy scalar types
                # such as np.float32, which are not subclasses of
                # the built-in float).
                try:
                    rf = float(result)
                except (TypeError, ValueError):
                    print(f"WARNING: scale value script returned "
                          f"non-numeric value: "
                          f"{type(result).__name__}; falling back "
                          f"to mean")
                else:
                    if math.isfinite(rf) and rf > 0.0:
                        return rf
                    print(f"WARNING: scale value script returned "
                          f"non-positive or non-finite value: "
                          f"{result!r}; falling back to mean")
        except Exception as e:
            print(f"WARNING: scale value script failed: {e}")
    return _default_scale_value(anchors)


def _mean_scale():
    s = _compute_scale_value(_scale_anchors)
    if s is None:
        return None
    sf = float(s)
    if not math.isfinite(sf) or sf <= 0.0:
        return None
    return sf


# =============================================================================
# Core geometry
# =============================================================================

def _safe_flush():
    global _recording_stream
    if _recording_stream is None:
        return
    fn = getattr(rr, "flush", None)
    if callable(fn):
        try:
            fn()
            return
        except Exception:
            pass
    fn = getattr(_recording_stream, "flush", None)
    if callable(fn):
        try:
            fn()
        except Exception:
            pass


def _get_camera(reconstruction, camera_id):
    if reconstruction is None or camera_id is None:
        return None
    try:
        return reconstruction.cameras[camera_id]
    except (KeyError, IndexError, TypeError):
        return None


def _get_point3d(reconstruction, pid):
    if reconstruction is None or pid is None:
        return None
    try:
        return reconstruction.points3D[pid]
    except (KeyError, IndexError, TypeError):
        return None


def _cam_from_world_of(image):
    attr = getattr(image, "cam_from_world", None)
    if attr is None:
        raise RuntimeError("image has no cam_from_world")
    return attr() if callable(attr) else attr


def _bp_heuristic():
    return None


def _bp_3d_only():
    return rrb.Blueprint(
        rrb.Spatial3DView(origin="reconstruction", name="3D Scene"),
        collapse_panels=True,
    )


def _bp_3d_plus_cameras_horizontal():
    return rrb.Blueprint(
        rrb.Horizontal(
            rrb.Spatial3DView(origin="reconstruction", name="3D Scene"),
            rrb.Spatial2DView(origin="reconstruction/cameras",
                              name="Camera Previews"),
        ),
        collapse_panels=True,
    )


def _bp_3d_plus_cameras_vertical():
    return rrb.Blueprint(
        rrb.Vertical(
            rrb.Spatial3DView(origin="reconstruction", name="3D Scene"),
            rrb.Spatial2DView(origin="reconstruction/cameras",
                              name="Camera Previews"),
        ),
        collapse_panels=True,
    )


def _bp_3d_plus_cameras_tabs():
    return rrb.Blueprint(
        rrb.Tabs(
            rrb.Spatial3DView(origin="reconstruction", name="3D Scene"),
            rrb.Spatial2DView(origin="reconstruction/cameras",
                              name="Camera Previews"),
        ),
        collapse_panels=True,
    )


BLUEPRINT_PRESETS = {
    "Heuristic (auto-layout)":       _bp_heuristic,
    "3D Scene Only":                 _bp_3d_only,
    "3D + Cameras (horizontal)":     _bp_3d_plus_cameras_horizontal,
    "3D + Cameras (vertical)":       _bp_3d_plus_cameras_vertical,
    "3D + Cameras (tabs)":           _bp_3d_plus_cameras_tabs,
}


def _intrinsics_from_model(model_name, params):
    p = params
    n = model_name
    if n in ("SIMPLE_PINHOLE", "SIMPLE_RADIAL", "SIMPLE_RADIAL_FISHEYE",
             "SIMPLE_DIVISION", "SIMPLE_FISHEYE"):
        return (p[0], p[0], p[1], p[2])
    if n in ("RADIAL", "RADIAL_FISHEYE", "DIVISION"):
        return (p[0], p[0], p[1], p[2])
    if n in ("PINHOLE", "OPENCV", "OPENCV_FISHEYE", "FULL_OPENCV",
             "FOV", "THIN_PRISM_FISHEYE", "RAD_TAN_THIN_PRISM_FISHEYE"):
        return (p[0], p[1], p[2], p[3])
    return None


def _intrinsics_for_camera(camera):
    if camera is None:
        return None
    cm = getattr(camera, "calibration_matrix", None)
    if callable(cm):
        try:
            K = np.asarray(cm(), dtype=np.float64)
            if K.shape == (3, 3):
                return (float(K[0, 0]), float(K[1, 1]),
                        float(K[0, 2]), float(K[1, 2]))
        except Exception:
            pass
    try:
        return _intrinsics_from_model(camera.model_name, list(camera.params))
    except Exception:
        return None


def _camera_K_dist(camera):
    model = getattr(camera, "model_name", "")
    if model not in _SUPPORTED_PINHOLE_MODELS:
        return None, None
    try:
        p = list(camera.params)
    except Exception:
        return None, None
    if not p:
        return None, None

    k1 = k2 = p1 = p2 = 0.0
    if model in ("SIMPLE_PINHOLE", "SIMPLE_RADIAL"):
        fx = fy = p[0]; cx, cy = p[1], p[2]
        if len(p) > 3: k1 = p[3]
    elif model == "RADIAL":
        fx = fy = p[0]; cx, cy = p[1], p[2]
        if len(p) > 3: k1 = p[3]
        if len(p) > 4: k2 = p[4]
    elif model == "PINHOLE":
        fx, fy, cx, cy = p[0], p[1], p[2], p[3]
    elif model in ("OPENCV", "FULL_OPENCV"):
        fx, fy, cx, cy = p[0], p[1], p[2], p[3]
        if len(p) > 4: k1 = p[4]
        if len(p) > 5: k2 = p[5]
        if len(p) > 6: p1 = p[6]
        if len(p) > 7: p2 = p[7]
    else:
        return None, None
    K = np.array([[fx, 0, cx], [0, fy, cy], [0, 0, 1]], dtype=np.float64)
    dist = np.array([k1, k2, p1, p2], dtype=np.float64)
    return K, dist


def _native_project(camera, p_cam):
    """Project a camera-frame point using pycolmap's native camera
    model. Returns (u, v) in pixels or None when the API is not
    available or fails.

    Native projection is preferred because it uses the same camera
    model as pycolmap itself, including models the manual pinhole
    path does not implement (for example FULL_OPENCV with higher-
    order radial terms).
    """
    fn = getattr(camera, "img_from_cam", None)
    if not callable(fn):
        return None
    try:
        vec = np.asarray(p_cam, dtype=np.float64).reshape(3, 1)
        result = fn(vec)
        arr = np.asarray(result, dtype=np.float64).reshape(-1)
        if arr.size < 2:
            return None
        u = float(arr[0])
        v = float(arr[1])
        if math.isfinite(u) and math.isfinite(v):
            return (u, v)
    except Exception:
        return None
    return None


def _native_undistort_to_normalized(camera, u, v):
    """Undistort a pixel observation to normalized camera coordinates
    using pycolmap's native camera model. Returns (un, vn) or None.
    """
    fn = getattr(camera, "cam_from_img", None)
    if not callable(fn):
        return None
    try:
        vec = np.asarray([float(u), float(v)],
                         dtype=np.float64).reshape(2, 1)
        result = fn(vec)
        arr = np.asarray(result, dtype=np.float64).reshape(-1)
        if arr.size < 2:
            return None
        un = float(arr[0])
        vn = float(arr[1])
        if math.isfinite(un) and math.isfinite(vn):
            return (un, vn)
    except Exception:
        return None
    return None


def _project_world_point(camera, image, X):
    try:
        cfw = _cam_from_world_of(image)
        R = np.asarray(cfw.rotation.matrix(), dtype=np.float64)
        t = np.asarray(cfw.translation, dtype=np.float64)
    except Exception:
        return None

    X = np.asarray(X, dtype=np.float64).reshape(3)
    p_cam = R @ X + t
    if p_cam[2] <= 1e-8:
        return None

    # Preferred: pycolmap's native camera model. Correct for every
    # model the installed pycolmap supports, including FULL_OPENCV
    # with higher-order radial terms.
    native = _native_project(camera, p_cam)
    if native is not None:
        return native

    # Manual fallback. Valid only for the pinhole family with up to
    # two radial and two tangential terms (the OpenCV model).
    model = getattr(camera, "model_name", "")
    if model not in _MANUAL_PINHOLE_MODELS:
        return None

    xn = p_cam[0] / p_cam[2]
    yn = p_cam[1] / p_cam[2]

    K, dist = _camera_K_dist(camera)
    if K is None:
        return None
    k1, k2, p1, p2 = dist
    r2 = xn * xn + yn * yn
    radial = 1.0 + k1 * r2 + k2 * r2 * r2
    xd = xn * radial + 2.0 * p1 * xn * yn + p2 * (r2 + 2.0 * xn * xn)
    yd = yn * radial + p1 * (r2 + 2.0 * yn * yn) + 2.0 * p2 * xn * yn

    return (K[0, 0] * xd + K[0, 2], K[1, 1] * yd + K[1, 2])


def _multiview_triangulate(
    observations, reconstruction,
    min_tri_angle_rad=_MIN_TRI_ANGLE_RAD,
    max_reproj_px=_MAX_ACCEPTABLE_REPROJ_PX,
):
    """Triangulate one 3D point from N 2D observations across images.

    pycolmap.estimate_triangulation expects image measurements in
    pixel coordinates together with the camera models that carry the
    intrinsics. The normalized (undistorted) coordinates are computed
    separately and used only by the DLT fallback, so the two paths
    keep their correct input conventions.

    Quality gates applied to both paths:
      * at least two observations from distinct images,
      * duplicate observations from the same image are dropped,
      * finite inputs and finite output,
      * positive depth in at least two contributing cameras,
      * minimum pairwise viewing angle,
      * at least two observations with finite pixel reprojection
        residuals, and mean residual below max_reproj_px.

    Returns (xyz, residuals) on success or None on rejection.
    """
    if len(observations) < 2:
        return None

    # Deduplicate by image. Repeated observations from the same image
    # do not add an independent constraint and can bias the estimator.
    seen_images = set()
    deduped = []
    for obs in observations:
        name = obs[0]
        if name in seen_images:
            print(f"DEBUG: triangulation: duplicate observation "
                  f"in {name}; skipping")
            continue
        seen_images.add(name)
        deduped.append(obs)

    if len(deduped) < 2:
        print("DEBUG: triangulation: fewer than 2 distinct images "
              "after deduplication")
        return None

    pixels_list = []
    norm_list = []
    cams_from_world = []
    cameras_list = []
    valid_obs = []

    for name, u, v in deduped:
        if not (_is_finite(u) and _is_finite(v)):
            print(f"DEBUG: triangulation: non-finite observation "
                  f"for {name}")
            return None
        img = reconstruction.find_image_with_name(name)
        if img is None:
            print(f"DEBUG: triangulation: image not found: {name}")
            return None
        cam = _get_camera(reconstruction, img.camera_id)
        if cam is None:
            print(f"DEBUG: triangulation: no camera for image {name}")
            return None

        # Prefer native pycolmap unprojection; fall back to OpenCV
        # undistortPoints for the OpenCV-compatible pinhole family.
        native_uv = _native_undistort_to_normalized(cam, u, v)
        if native_uv is not None:
            un, vn = native_uv
        else:
            model = getattr(cam, "model_name", "")
            if model not in _MANUAL_PINHOLE_MODELS:
                print(f"DEBUG: triangulation: no native unprojection "
                      f"for camera model {model!r} on {name}")
                return None
            K, dist = _camera_K_dist(cam)
            if K is None:
                print(f"DEBUG: triangulation: unsupported camera "
                      f"model for image {name}")
                return None
            pts = np.array([[[float(u), float(v)]]],
                           dtype=np.float64)
            try:
                nrm = cv2.undistortPoints(pts, K, dist)
            except cv2.error as e:
                print(f"DEBUG: triangulation: undistortPoints failed "
                      f"for {name}: {e}")
                return None
            un = float(nrm[0, 0, 0])
            vn = float(nrm[0, 0, 1])

        try:
            cfw = _cam_from_world_of(img)
        except Exception as e:
            print(f"DEBUG: triangulation: cam_from_world failed "
                  f"for {name}: {e}")
            return None

        pixels_list.append([float(u), float(v)])
        norm_list.append([un, vn])
        cams_from_world.append(cfw)
        cameras_list.append(cam)
        valid_obs.append((name, u, v))

    if len(pixels_list) < 2:
        return None

    n_obs = len(pixels_list)
    print(f"DEBUG: triangulation: {n_obs} observations across "
          f"{len(seen_images)} images.")

    pixels_arr = np.asarray(pixels_list, dtype=np.float64)
    norm_arr = np.asarray(norm_list, dtype=np.float64)

    xyz = None
    if hasattr(pycolmap, "estimate_triangulation"):
        try:
            options = None
            try:
                options = pycolmap.EstimateTriangulationOptions()
                try:
                    options.min_tri_angle = float(min_tri_angle_rad)
                except Exception:
                    pass
            except Exception:
                options = None

            # Pixel coordinates: this is the interface pycolmap
            # expects. Passing normalized coordinates here would
            # cause a second unprojection with the wrong units.
            if options is not None:
                result = pycolmap.estimate_triangulation(
                    pixels_arr, cams_from_world, cameras_list,
                    options=options)
            else:
                result = pycolmap.estimate_triangulation(
                    pixels_arr, cams_from_world, cameras_list)

            if result is not None:
                if isinstance(result, dict):
                    if "xyz" in result:
                        v = np.asarray(result["xyz"],
                                       dtype=np.float64)
                        if v.size == 3 and np.all(np.isfinite(v)):
                            xyz = v.reshape(3)
                else:
                    try:
                        v = np.asarray(result, dtype=np.float64)
                        if v.size == 3 and np.all(np.isfinite(v)):
                            xyz = v.reshape(3)
                    except Exception:
                        xyz = None
        except TypeError as e:
            print(f"DEBUG: pycolmap.estimate_triangulation "
                  f"TypeError: {e}; using DLT fallback.")
            xyz = None
        except Exception as e:
            print(f"DEBUG: pycolmap.estimate_triangulation raised: "
                  f"{e}; using DLT fallback.")
            xyz = None
    else:
        print("DEBUG: pycolmap.estimate_triangulation not exposed "
              "in this version; using DLT fallback.")

    if xyz is None:
        # DLT uses normalized (undistorted) observations.
        A_rows = []
        b_rows = []
        for (un, vn), cfw in zip(norm_arr, cams_from_world):
            R = np.asarray(cfw.rotation.matrix(), dtype=np.float64)
            t = np.asarray(cfw.translation, dtype=np.float64)
            A_rows.append(un * R[2] - R[0])
            b_rows.append(t[0] - un * t[2])
            A_rows.append(vn * R[2] - R[1])
            b_rows.append(t[1] - vn * t[2])
        A = np.asarray(A_rows, dtype=np.float64)
        b = np.asarray(b_rows, dtype=np.float64)
        try:
            X, _res, rank, _sv = np.linalg.lstsq(A, b, rcond=None)
        except np.linalg.LinAlgError as e:
            print(f"DEBUG: DLT lstsq failed: {e}")
            return None
        if rank < 3 or not np.all(np.isfinite(X)):
            print(f"DEBUG: DLT rank deficient (rank={rank}).")
            return None
        xyz = X.reshape(3)

    xyz = np.asarray(xyz, dtype=np.float64).reshape(3)
    if not np.all(np.isfinite(xyz)):
        return None

    # Positive-depth gate.
    in_front = 0
    for cfw in cams_from_world:
        R = np.asarray(cfw.rotation.matrix(), dtype=np.float64)
        t = np.asarray(cfw.translation, dtype=np.float64)
        p_cam = R @ xyz + t
        if p_cam[2] > 1e-6:
            in_front += 1
    if in_front < 2:
        print(f"DEBUG: triangulated point is in front of only "
              f"{in_front} camera(s); rejecting.")
        return None

    # Minimum-parallax gate.
    rays = []
    for cfw in cams_from_world:
        R = np.asarray(cfw.rotation.matrix(), dtype=np.float64)
        t = np.asarray(cfw.translation, dtype=np.float64)
        cam_center = -R.T @ t
        d = xyz - cam_center
        dn = float(np.linalg.norm(d))
        if dn > 1e-9:
            rays.append(d / dn)
    min_angle = math.pi
    if len(rays) >= 2:
        for i in range(len(rays)):
            for j in range(i + 1, len(rays)):
                cosang = float(np.clip(np.dot(rays[i], rays[j]),
                                       -1.0, 1.0))
                ang = math.acos(cosang)
                if ang < min_angle:
                    min_angle = ang
        if (min_tri_angle_rad > 0
                and min_angle < min_tri_angle_rad):
            print(f"DEBUG: triangulation rejected: min parallax "
                  f"{math.degrees(min_angle):.2f}° < "
                  f"{math.degrees(min_tri_angle_rad):.2f}°")
            return None

    # Pixel-space reprojection residuals.
    residuals = []
    for name, u, v in valid_obs:
        img = reconstruction.find_image_with_name(name)
        cam = _get_camera(reconstruction, img.camera_id) if img else None
        if img is None or cam is None:
            residuals.append(None)
            continue
        uv = _project_world_point(cam, img, xyz)
        if uv is None:
            residuals.append(None)
        else:
            r = float(math.hypot(uv[0] - u, uv[1] - v))
            residuals.append(r if math.isfinite(r) else None)

    good = [r for r in residuals if r is not None]
    if len(good) < 2:
        print(f"DEBUG: only {len(good)} observation(s) reproject "
              f"successfully; rejecting.")
        return None
    mean_res = float(np.mean(good))
    if max_reproj_px > 0 and mean_res > max_reproj_px:
        print(f"DEBUG: triangulation rejected: mean reprojection "
              f"{mean_res:.2f} px > {max_reproj_px:.2f} px")
        return None

    min_angle_deg = (math.degrees(min_angle)
                     if len(rays) >= 2 else 0.0)
    print(f"DEBUG: triangulation succeeded; xyz={xyz.tolist()}, "
          f"mean reprojection residual = {mean_res:.3f} px, "
          f"min parallax = {min_angle_deg:.2f}°")
    return xyz, residuals


def _ply_has_faces(path, max_header_lines=512):
    if not path.lower().endswith(".ply"):
        return None
    try:
        with open(path, "rb") as f:
            for _ in range(max_header_lines):
                raw = f.readline()
                if not raw:
                    return None
                line = raw.decode("ascii", errors="ignore").strip()
                if line.startswith("element face"):
                    return True
                if line.startswith("end_header"):
                    return False
    except OSError:
        return None
    return None


def _safe_rerun_init(app_id="COLMAP Viewer"):
    global _recording_stream

    try:
        rr.disconnect()
    except Exception:
        pass

    try:
        _recording_stream = rr.init(app_id, spawn=True)
        return True
    except RuntimeError as e:
        msg = str(e)
        if "gRPC" not in msg and "connection" not in msg.lower():
            print(f"FATAL: rerun init failed: {e}")
            return False
        print(f"WARNING: rerun spawn failed ({msg}); retrying without spawn.")

    time.sleep(0.5)

    try:
        rr.disconnect()
    except Exception:
        pass

    try:
        _recording_stream = rr.init(app_id, spawn=False)
        return True
    except Exception as e2:
        print(f"FATAL: rerun init failed (both spawn and no-spawn): {e2}")
        return False


def _natural_sort_key(value):
    normalized = str(value).replace("\\", "/").casefold()
    return tuple(
        int(part) if part.isdigit() else part
        for part in re.split(r"(\d+)", normalized)
    )


def _sanitize_entity_token(name):
    return name.replace("\\", "/").replace("/", "_").replace(" ", "_")


def _track_length(track):
    length = getattr(track, "length", None)
    if callable(length):
        try:
            return int(length())
        except Exception:
            pass
    elements = getattr(track, "elements", None)
    if elements is not None:
        try:
            return len(elements)
        except TypeError:
            pass
    try:
        return len(track)
    except TypeError:
        return 0


def _keypoint_3d_id(keypoint):
    pid = getattr(keypoint, "point3D_id", None)
    if pid is None:
        pid = getattr(keypoint, "point3DId", None)
    try:
        pid = int(pid)
    except (TypeError, ValueError):
        return None
    if pid < 0 or pid == _COLMAP_INVALID_PID:
        return None
    return pid


def _rotation_matrix_to_quaternion_wxyz(R):
    R = np.asarray(R, dtype=np.float64)
    trace = R[0, 0] + R[1, 1] + R[2, 2]
    if trace > 0.0:
        s = math.sqrt(trace + 1.0) * 2.0
        w = 0.25 * s
        x = (R[2, 1] - R[1, 2]) / s
        y = (R[0, 2] - R[2, 0]) / s
        z = (R[1, 0] - R[0, 1]) / s
    elif R[0, 0] > R[1, 1] and R[0, 0] > R[2, 2]:
        s = math.sqrt(1.0 + R[0, 0] - R[1, 1] - R[2, 2]) * 2.0
        w = (R[2, 1] - R[1, 2]) / s
        x = 0.25 * s
        y = (R[0, 1] + R[1, 0]) / s
        z = (R[0, 2] + R[2, 0]) / s
    elif R[1, 1] > R[2, 2]:
        s = math.sqrt(1.0 + R[1, 1] - R[0, 0] - R[2, 2]) * 2.0
        w = (R[0, 2] - R[2, 0]) / s
        x = (R[0, 1] + R[1, 0]) / s
        y = 0.25 * s
        z = (R[1, 2] + R[2, 1]) / s
    else:
        s = math.sqrt(1.0 + R[2, 2] - R[0, 0] - R[1, 1]) * 2.0
        w = (R[1, 0] - R[0, 1]) / s
        x = (R[0, 2] + R[2, 0]) / s
        y = (R[1, 2] + R[2, 1]) / s
        z = 0.25 * s
    return w, x, y, z


def _find_database_db(sparse_path, images_dir):
    candidates = []
    if sparse_path is not None:
        sp = Path(sparse_path)
        candidates.append(sp / "database.db")
        candidates.append(sp.parent / "database.db")
        candidates.append(sp.parent.parent / "database.db")
    if images_dir is not None:
        ip = Path(images_dir)
        candidates.append(ip / "database.db")
        candidates.append(ip.parent / "database.db")
    for c in candidates:
        try:
            if c.is_file():
                return c
        except Exception:
            continue
    return None


def _write_metric_colmap_text(reconstruction, scale, out_dir):
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    errors = []

    try:
        with open(out_dir / "cameras.txt", "w", encoding="utf-8") as f:
            f.write("# Camera list with one line of data per camera:\n")
            f.write("#   CAMERA_ID, MODEL, WIDTH, HEIGHT, PARAMS[]\n")
            f.write(f"# Number of cameras: "
                    f"{len(reconstruction.cameras)}\n")
            for cam_id in sorted(reconstruction.cameras.keys()):
                cam = reconstruction.cameras[cam_id]
                try:
                    params = list(cam.params)
                except Exception:
                    params = []
                params_str = " ".join(
                    f"{float(p):.17g}" for p in params)
                model = getattr(cam, "model_name", "PINHOLE")
                f.write(
                    f"{cam_id} {model} "
                    f"{int(cam.width)} {int(cam.height)} "
                    f"{params_str}\n")
    except Exception as e:
        errors.append(("cameras.txt", str(e)))

    try:
        with open(out_dir / "images.txt", "w", encoding="utf-8") as f:
            f.write("# Image list with two lines of data per image:\n")
            f.write("#   IMAGE_ID, QW, QX, QY, QZ, TX, TY, TZ, "
                    "CAMERA_ID, NAME\n")
            f.write("#   POINTS2D[] as (X, Y, POINT3D_ID)\n")
            f.write(f"# Number of images: "
                    f"{len(reconstruction.images)}\n")
            for img_id in sorted(reconstruction.images.keys()):
                img = reconstruction.images[img_id]
                try:
                    cfw = _cam_from_world_of(img)
                    R = np.asarray(
                        cfw.rotation.matrix(), dtype=np.float64)
                    t = np.asarray(
                        cfw.translation, dtype=np.float64)
                except Exception as e:
                    errors.append(
                        (f"images.txt[{img_id}]",
                         f"extrinsics: {e}"))
                    continue
                qw, qx, qy, qz = \
                    _rotation_matrix_to_quaternion_wxyz(R)
                tx, ty, tz = t * scale
                f.write(
                    f"{img_id} "
                    f"{qw:.17g} {qx:.17g} {qy:.17g} {qz:.17g} "
                    f"{tx:.17g} {ty:.17g} {tz:.17g} "
                    f"{img.camera_id} {img.name}\n")

                pts2d = getattr(img, "points2D", None) or []
                parts = []
                for kp in pts2d:
                    try:
                        x = float(kp.xy[0])
                        y = float(kp.xy[1])
                    except (TypeError, IndexError, ValueError):
                        continue
                    pid = _keypoint_3d_id(kp)
                    if pid is None:
                        pid = -1
                    parts.append(f"{x:.17g} {y:.17g} {pid}")
                f.write(" ".join(parts) + "\n")
    except Exception as e:
        errors.append(("images.txt", str(e)))

    try:
        with open(out_dir / "points3D.txt", "w", encoding="utf-8") as f:
            f.write("# 3D point list with one line of data per point:\n")
            f.write("#   POINT3D_ID, X, Y, Z, R, G, B, ERROR, "
                    "TRACK[] as (IMAGE_ID, POINT2D_IDX)\n")
            f.write(
                f"# Number of points: "
                f"{len(reconstruction.points3D)}\n")
            for pid in sorted(reconstruction.points3D.keys()):
                p = reconstruction.points3D[pid]
                x = float(p.xyz[0]) * scale
                y = float(p.xyz[1]) * scale
                z = float(p.xyz[2]) * scale
                try:
                    r = int(p.color[0])
                    g = int(p.color[1])
                    b = int(p.color[2])
                except Exception:
                    r = g = b = 255
                try:
                    err = float(getattr(p, "error", 0.0))
                except Exception:
                    err = 0.0

                track_str = ""
                track = getattr(p, "track", None)
                if track is not None:
                    elems = getattr(track, "elements", None)
                    if elems is None:
                        try:
                            elems = list(track)
                        except TypeError:
                            elems = None
                    if elems:
                        pairs = []
                        for e in elems:
                            try:
                                img_id_e = int(e.image_id)
                                idx = int(e.point2D_idx)
                            except Exception:
                                continue
                            pairs.append(f"{img_id_e} {idx}")
                        if pairs:
                            track_str = " " + " ".join(pairs)

                f.write(
                    f"{pid} {x:.17g} {y:.17g} {z:.17g} "
                    f"{r} {g} {b} {err:.17g}{track_str}\n")
    except Exception as e:
        errors.append(("points3D.txt", str(e)))

    return errors


def _write_metric_colmap_model(reconstruction, scale, out_dir, fmt='bin'):
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    if fmt == 'txt':
        return _write_metric_colmap_text(reconstruction, scale, out_dir)

    errors = []
    with tempfile.TemporaryDirectory(prefix="colmap_metric_") as tmp:
        tmp_path = Path(tmp)
        errs_text = _write_metric_colmap_text(
            reconstruction, scale, tmp_path)
        # Any serialization error, including per-image errors, is
        # fatal. A partial sparse model must not be presented as a
        # usable export.
        if errs_text:
            return errs_text

        try:
            rec_scaled = pycolmap.Reconstruction(str(tmp_path))
        except Exception as e:
            return errs_text + [
                ("sparse/0",
                 f"reload for binary write failed: {e}")
            ]

        try:
            rec_scaled.write(str(out_dir))
        except Exception as e:
            return errs_text + [
                ("sparse/0", f"binary write failed: {e}")
            ]

    return errors


def launch_visualization(
    sparse_path, images_dir, downscale_factor, point_radii,
    load_features, only_triangulated, max_error, min_track,
    draw_trajectory, mesh_path, blueprint_key,
    on_reconstruction_committed=None,
):
    global _current_reconstruction, _current_reconstruction_path

    ok = True

    print(f"Loading COLMAP reconstruction from: {sparse_path}")
    try:
        reconstruction = pycolmap.Reconstruction(sparse_path)
    except Exception as e:
        print(f"FATAL: could not load reconstruction: {e}")
        traceback.print_exc()
        return False

    if not reconstruction.images:
        print("FATAL: reconstruction contains no images.")
        return False

    _current_reconstruction = reconstruction
    _current_reconstruction_path = sparse_path

    # Signal the main thread immediately: the candidate has been
    # loaded and is now the active reconstruction. The main thread
    # will reset calibration state on its own event loop. Firing
    # here (rather than after the rest of the visualization work
    # finishes) removes the window in which the new model is active
    # but the previous calibration state is still displayed.
    if on_reconstruction_committed is not None:
        try:
            on_reconstruction_committed(sparse_path)
        except Exception as e:
            print(f"WARNING: on_reconstruction_committed raised: "
                  f"{e}")

    unsupported_models = sorted({
        getattr(cam, "model_name", "")
        for cam in reconstruction.cameras.values()
        if getattr(cam, "model_name", "")
        not in _SUPPORTED_PINHOLE_MODELS
    })
    if unsupported_models:
        print("WARNING: unsupported camera model(s) present; "
              "geometry-dependent measurement (triangulation, "
              "reprojection, overlays) will be skipped for these "
              "cameras:")
        for m in unsupported_models:
            print(f"         - {m}")

    total_kp = 0
    total_tri = 0
    for img in reconstruction.images.values():
        pts = getattr(img, "points2D", None)
        if pts is None:
            continue
        for kp in pts:
            total_kp += 1
            if _keypoint_3d_id(kp) is not None:
                total_tri += 1
    if total_kp:
        pct = 100.0 * total_tri / total_kp
        print(f"Triangulated keypoints: {total_tri}/{total_kp} "
              f"({pct:.1f}%).")
    print(f"Loaded {len(reconstruction.images)} images, "
          f"{len(reconstruction.points3D)} 3D points, "
          f"{len(reconstruction.cameras)} cameras.")

    if not _safe_rerun_init("COLMAP Viewer"):
        return False

    bp_func = BLUEPRINT_PRESETS.get(blueprint_key) or _bp_heuristic
    bp = bp_func()
    if bp is not None:
        try:
            rr.send_blueprint(bp)
            print(f"Applied blueprint: {blueprint_key}")
        except Exception as e:
            print(f"WARNING: blueprint setup failed (continuing): {e}")
    else:
        print("Blueprint: heuristic auto-layout (Rerun decides).")

    if mesh_path and os.path.exists(mesh_path):
        try:
            has_faces = _ply_has_faces(mesh_path)
            if has_faces is False:
                print(f"WARNING: {mesh_path} is a point-cloud PLY "
                      f"(no faces). Skipping mesh load.")
            else:
                print(f"Loading dense mesh: {mesh_path}")
                rr.log("reconstruction/dense_mesh",
                       rr.Asset3D(path=mesh_path))
        except Exception as e:
            print(f"WARNING: mesh load failed (continuing): {e}")
            ok = False

    try:
        points_3d = []
        colors_3d = []
        for pid, p in reconstruction.points3D.items():
            tl = _track_length(p.track)
            if p.error <= max_error and tl >= min_track:
                points_3d.append(np.asarray(p.xyz, dtype=np.float32))
                colors_3d.append(
                    np.asarray(p.color, dtype=np.float32) / 255.0
                )

        if points_3d:
            rr.log("reconstruction/points",
                   rr.Points3D(points_3d, colors=colors_3d,
                               radii=point_radii))
            print(f"Logged {len(points_3d)} points.")
        else:
            print("WARNING: no 3D points passed the filter.")
    except Exception as e:
        print(f"WARNING: 3D point cloud logging failed: {e}")
        traceback.print_exc()
        ok = False

    trajectory_positions = []
    sorted_images = sorted(reconstruction.images.values(),
                           key=lambda img: img.name)

    print("Processing cameras and images...")
    n_cameras_logged = 0
    n_images_logged = 0
    n_features_logged = 0
    n_kp_skipped_untri = 0
    n_intrinsics_failed = 0

    for image in sorted_images:
        camera = _get_camera(reconstruction, image.camera_id)
        if camera is None:
            print(f"WARNING: image '{image.name}' references missing "
                  f"camera {image.camera_id}.")
            continue

        try:
            cam_from_world = _cam_from_world_of(image)
            world_from_cam = cam_from_world.inverse()
            translation = np.asarray(world_from_cam.translation,
                                     dtype=np.float32)
            rotation_matrix = np.asarray(
                world_from_cam.rotation.matrix(), dtype=np.float32
            )
            trajectory_positions.append(translation)
        except Exception as e:
            print(f"WARNING: extrinsics failed for '{image.name}': {e}")
            continue

        token = _sanitize_entity_token(image.name)
        entity = f"reconstruction/cameras/{token}"

        try:
            rr.log(entity, rr.Transform3D(
                translation=translation, mat3x3=rotation_matrix
            ))
        except Exception as e:
            print(f"WARNING: Transform3D failed for '{image.name}': {e}")

        intr = _intrinsics_for_camera(camera)
        if intr is None:
            n_intrinsics_failed += 1
            continue

        fx, fy, cx, cy = intr
        fx *= downscale_factor
        fy *= downscale_factor
        cx *= downscale_factor
        cy *= downscale_factor
        width = max(1, int(round(camera.width * downscale_factor)))
        height = max(1, int(round(camera.height * downscale_factor)))

        try:
            intrinsic_matrix = np.array(
                [[fx, 0, cx], [0, fy, cy], [0, 0, 1]],
                dtype=np.float32
            )
            rr.log(entity, rr.Pinhole(
                image_from_camera=intrinsic_matrix,
                resolution=[width, height]
            ))
            n_cameras_logged += 1
        except Exception as e:
            print(f"WARNING: Pinhole failed for '{image.name}': {e}")
            continue

        full_image_path = os.path.join(images_dir, image.name)
        if os.path.exists(full_image_path):
            try:
                img_mat = cv2.imread(full_image_path)
                if img_mat is not None:
                    if downscale_factor != 1.0:
                        img_mat = cv2.resize(
                            img_mat, (width, height),
                            interpolation=cv2.INTER_AREA
                        )
                    img_rgb = cv2.cvtColor(img_mat, cv2.COLOR_BGR2RGB)
                    rr.log(entity, rr.Image(img_rgb))
                    n_images_logged += 1
            except Exception as e:
                print(f"WARNING: image load/log failed for "
                      f"'{image.name}': {e}")

        if load_features:
            try:
                pts2d = getattr(image, "points2D", None)
                if pts2d:
                    kp_positions = []
                    for kp in pts2d:
                        if only_triangulated and \
                                _keypoint_3d_id(kp) is None:
                            n_kp_skipped_untri += 1
                            continue
                        try:
                            x, y = float(kp.xy[0]), float(kp.xy[1])
                        except (TypeError, IndexError, ValueError):
                            continue
                        kp_positions.append(
                            (x * downscale_factor,
                             y * downscale_factor)
                        )
                    if kp_positions:
                        rr.log(f"{entity}/features",
                               rr.Points2D(kp_positions, radii=2.0,
                                           colors=[0, 255, 0]))
                        n_features_logged += 1
            except Exception as e:
                print(f"WARNING: feature log failed for "
                      f"'{image.name}': {e}")

    if n_intrinsics_failed:
        print(f"WARNING: {n_intrinsics_failed} camera(s) skipped.")

    if draw_trajectory and len(trajectory_positions) >= 2:
        try:
            rr.log("reconstruction/trajectory",
                   rr.LineStrips3D([trajectory_positions],
                                   colors=[[255, 165, 0]]))
            print(f"Trajectory: {len(trajectory_positions)} "
                  f"camera centres.")
        except Exception as e:
            print(f"WARNING: trajectory log failed: {e}")

    print(f"Summary: cameras={n_cameras_logged} "
          f"images={n_images_logged} "
          f"feature-sets={n_features_logged} "
          f"trajectory={len(trajectory_positions)}")
    if only_triangulated and n_kp_skipped_untri:
        print(f"         skipped {n_kp_skipped_untri} untriangulated "
              f"keypoints (Only triangulated keypoints is ON).")

    _safe_flush()
    print("Processing complete. Data sent to Rerun.")
    return ok


class MetricExportOptionsDialog(tk.Toplevel):

    def __init__(self, parent, can_copy_images, can_copy_db):
        super().__init__(parent)
        self.title("Metric export options")
        self.transient(parent)
        self.grab_set()
        self.resizable(False, False)

        self.result = None
        self.format_var = tk.StringVar(value="bin")
        self.images_var = tk.BooleanVar(value=can_copy_images)
        self.db_var = tk.BooleanVar(value=can_copy_db)

        frame = ttk.Frame(self, padding=14)
        frame.pack(fill="both", expand=True)

        ttk.Label(frame, text="Sparse model format:",
                  font=("TkDefaultFont", 9, "bold")).grid(
            row=0, column=0, sticky="w", pady=(0, 4))
        fmt_frame = ttk.Frame(frame)
        fmt_frame.grid(row=0, column=1, sticky="w", pady=(0, 4))
        ttk.Radiobutton(fmt_frame, text="Binary (.bin)",
                        variable=self.format_var, value="bin").pack(
            side="left")
        ttk.Radiobutton(fmt_frame, text="Text (.txt)",
                        variable=self.format_var, value="txt").pack(
            side="left", padx=14)

        ttk.Separator(frame, orient="horizontal").grid(
            row=1, column=0, columnspan=3, sticky="ew", pady=8)

        ttk.Label(frame, text="Additional content:",
                  font=("TkDefaultFont", 9, "bold")).grid(
            row=2, column=0, columnspan=3, sticky="w", pady=(0, 4))

        cb_img = ttk.Checkbutton(
            frame, text="Copy images/ folder",
            variable=self.images_var)
        cb_img.grid(row=3, column=0, columnspan=2, sticky="w", pady=3)
        if not can_copy_images:
            cb_img.config(state="disabled")
            ttk.Label(frame, text="(not found)",
                      foreground="gray",
                      font=("TkDefaultFont", 8)).grid(
                row=3, column=2, sticky="w", padx=6)

        cb_db = ttk.Checkbutton(
            frame, text="Copy database.db",
            variable=self.db_var)
        cb_db.grid(row=4, column=0, columnspan=2, sticky="w", pady=3)
        if not can_copy_db:
            cb_db.config(state="disabled")
            ttk.Label(frame, text="(not found)",
                      foreground="gray",
                      font=("TkDefaultFont", 8)).grid(
                row=4, column=2, sticky="w", padx=6)

        ttk.Label(
            frame,
            text=("The output is a COLMAP project folder:\n"
                  "  sparse/0/  cameras, images, points3D (metric)\n"
                  "  images/    (optional)\n"
                  "  database.db (optional)\n"
                  "  rescale_info.txt"),
            foreground="gray",
            font=("TkDefaultFont", 8),
            justify="left").grid(
            row=5, column=0, columnspan=3, sticky="w", pady=(10, 0))

        btn = ttk.Frame(frame)
        btn.grid(row=6, column=0, columnspan=3, pady=(12, 0))
        ttk.Button(btn, text="Continue",
                   command=self._ok).pack(side="left", padx=4)
        ttk.Button(btn, text="Cancel",
                   command=self._cancel).pack(side="left", padx=4)

        self.protocol("WM_DELETE_WINDOW", self._cancel)
        self.after(50, self._center)

    def _center(self):
        try:
            self.update_idletasks()
            x = (self.winfo_screenwidth() - self.winfo_width()) // 2
            y = (self.winfo_screenheight() - self.winfo_height()) // 2
            self.geometry(f"+{x}+{y}")
        except tk.TclError:
            pass

    def _ok(self):
        self.result = {
            'format': self.format_var.get(),
            'include_images': bool(self.images_var.get()),
            'include_db': bool(self.db_var.get()),
        }
        self.destroy()

    def _cancel(self):
        self.result = None
        self.destroy()


class EditTargetDialog(tk.Toplevel):

    def __init__(self, parent, entry, image_names):
        super().__init__(parent)
        self.title("Edit target point")
        self.transient(parent)
        self.grab_set()
        self.resizable(False, False)

        self.result = None
        self.slot_var = tk.StringVar(value=entry.get('slot', 'A'))
        self.image_var = tk.StringVar(value=entry.get('image', ''))
        self.group_var = tk.StringVar(value=str(entry.get('group', 1)))
        u, v = entry.get('xy', (0.0, 0.0))
        self.u_var = tk.StringVar(value=f"{u:.2f}")
        self.v_var = tk.StringVar(value=f"{v:.2f}")

        frame = ttk.Frame(self, padding=14)
        frame.pack(fill="both", expand=True)

        ttk.Label(frame, text="Slot:").grid(row=0, column=0, sticky="e")
        ttk.Radiobutton(frame, text="A", variable=self.slot_var,
                        value='A').grid(row=0, column=1, sticky="w")
        ttk.Radiobutton(frame, text="B", variable=self.slot_var,
                        value='B').grid(row=0, column=2, sticky="w")
        ttk.Label(frame, text="Group:").grid(
            row=0, column=3, sticky="e", padx=(12, 4))
        ttk.Spinbox(frame, from_=1, to=999, textvariable=self.group_var,
                    width=6).grid(row=0, column=4, sticky="w")

        ttk.Label(frame, text="Image:").grid(
            row=1, column=0, sticky="e", pady=(6, 0))
        ttk.Combobox(frame, textvariable=self.image_var,
                     values=image_names, state="readonly",
                     width=40).grid(row=1, column=1, columnspan=4,
                                     sticky="w", pady=(6, 0))

        ttk.Label(frame, text="Pixel u:").grid(
            row=2, column=0, sticky="e", pady=(6, 0))
        ttk.Entry(frame, textvariable=self.u_var, width=12).grid(
            row=2, column=1, sticky="w", pady=(6, 0))
        ttk.Label(frame, text="Pixel v:").grid(
            row=2, column=2, sticky="e", pady=(6, 0))
        ttk.Entry(frame, textvariable=self.v_var, width=12).grid(
            row=2, column=3, columnspan=2, sticky="w", pady=(6, 0))

        btn = ttk.Frame(frame)
        btn.grid(row=4, column=0, columnspan=5, pady=(12, 0))
        ttk.Button(btn, text="OK", command=self._ok).pack(
            side="left", padx=4)
        ttk.Button(btn, text="Cancel", command=self._cancel).pack(
            side="left", padx=4)

        self.protocol("WM_DELETE_WINDOW", self._cancel)

    def _ok(self):
        try:
            u = float(self.u_var.get())
            v = float(self.v_var.get())
            grp = int(self.group_var.get())
            if grp < 1:
                raise ValueError("group must be >= 1")
        except ValueError:
            messagebox.showerror("Invalid input",
                                 "Pixel coordinates must be numeric, "
                                 "group must be a positive integer.",
                                 parent=self)
            return
        self.result = {
            'slot': self.slot_var.get(),
            'image': self.image_var.get(),
            'xy': (u, v),
            'group': grp,
        }
        self.destroy()

    def _cancel(self):
        self.result = None
        self.destroy()


class EditAnchorDialog(tk.Toplevel):

    def __init__(self, parent, anchor):
        super().__init__(parent)
        self.title("Edit scale anchor")
        self.transient(parent)
        self.grab_set()
        self.resizable(False, False)

        self.result = None
        self.known_var = tk.StringVar(
            value=f"{anchor.get('metric', 0.0):.6f}")
        self.sfm_label = f"{anchor.get('sfm', 0.0):.6f}"

        frame = ttk.Frame(self, padding=14)
        frame.pack(fill="both", expand=True)

        ttk.Label(frame, text="Anchor A:",
                  foreground="gray").grid(
            row=0, column=0, sticky="e", padx=4, pady=3)
        ttk.Label(frame,
                  text=f"{anchor.get('a_kind','?')}:"
                       f"{anchor.get('a_ref','?')}").grid(
            row=0, column=1, sticky="w", pady=3)
        ttk.Label(frame, text="Anchor B:",
                  foreground="gray").grid(
            row=1, column=0, sticky="e", padx=4, pady=3)
        ttk.Label(frame,
                  text=f"{anchor.get('b_kind','?')}:"
                       f"{anchor.get('b_ref','?')}").grid(
            row=1, column=1, sticky="w", pady=3)

        ttk.Label(frame, text="d (SfM):").grid(
            row=2, column=0, sticky="e", padx=4, pady=3)
        ttk.Label(frame, text=self.sfm_label).grid(
            row=2, column=1, sticky="w", pady=3)

        ttk.Label(frame, text="d (known metric):").grid(
            row=3, column=0, sticky="e", padx=4, pady=3)
        ttk.Entry(frame, textvariable=self.known_var, width=16).grid(
            row=3, column=1, sticky="w", pady=3)

        btn = ttk.Frame(frame)
        btn.grid(row=4, column=0, columnspan=2, pady=(12, 0))
        ttk.Button(btn, text="OK", command=self._ok).pack(
            side="left", padx=4)
        ttk.Button(btn, text="Cancel", command=self._cancel).pack(
            side="left", padx=4)

        self.protocol("WM_DELETE_WINDOW", self._cancel)

    def _ok(self):
        try:
            known = float(self.known_var.get())
            if not math.isfinite(known) or known <= 0:
                raise ValueError("must be finite and positive")
        except ValueError:
            messagebox.showerror("Invalid input",
                                 "Known distance must be a finite "
                                 "positive number.", parent=self)
            return
        self.result = {'metric': known}
        self.destroy()

    def _cancel(self):
        self.result = None
        self.destroy()


# =============================================================================
# Popup dialog
# =============================================================================

class KeypointSelectionDialog(tk.Toplevel):
    """Unified keypoint selection dialog.

    A single target list serves both anchor types. Columns are the same
    for anchor=pid and anchor=target; the anchor type only changes the
    aggregation policy:

      anchor=pid     -> per-row xyz comes from the pid's stored 3D
                        point; the pluggable target value script is
                        used to combine the per-row points.

      anchor=target  -> per-row xyz is left blank; the target value is
                        computed by multiview triangulation over all
                        observations of each slot.

    The "Target value" table below the list shows the resolved A and B
    points, each with its source image, keypoint index, pixel
    coordinate, 3D coordinate, and the current scale.
    """

    SLOT_EMPTY = "empty"
    SLOT_FILLED = "filled"

    SLOT_COLORS = {
        'A': "#1e90ff",
        'B': "#cc88ff",
    }

    OVERLAY_COLOR_FULL = "#ffbf00"
    OVERLAY_COLOR_NEAR = "#ff0000"

    FILTER_DEBOUNCE_MS = 150
    RESIZE_DEBOUNCE_MS = 80

    def __init__(self, app, reconstruction, images_dir, pid_index,
                 slot_a_init, slot_b_init, default_slot='A',
                 on_apply_callback=None, purpose_callback=None):
        super().__init__(master=app.root)
        self.app = app
        self.reconstruction = reconstruction
        self.images_dir = images_dir
        self.pid_index = pid_index
        self.on_apply_callback = on_apply_callback
        self.purpose_callback = purpose_callback

        self.anchor_type_var = tk.StringVar(value='pid')
        self.anchor_pid = None
        self.group_var = tk.StringVar(value="1")
        self.active_target_slot = (default_slot
                                    if default_slot in ('A', 'B')
                                    else 'A')

        self.target_lists = {}
        self.pending_point = None

        self.image_names = sorted(
            (im.name for im in reconstruction.images.values()),
            key=_natural_sort_key)
        initial_image = self.image_names[0] if self.image_names else ""
        self.current_image_name = tk.StringVar(value=initial_image)

        self.current_image_obj = None
        self.current_camera = None
        self.source_image = None
        self.img_w = 0
        self.img_h = 0
        self.all_matches = []
        self.visible_indices = []

        self.zoom = 1.0
        self.pan_x = 0.0
        self.pan_y = 0.0
        self.base_scale = 1.0
        self.current_scale = 0.0
        self.current_x_off = 0.0
        self.current_y_off = 0.0
        self.photo = None
        self.thumb_photos = []
        self.drag_anchor = None

        self.result = None

        self.overlay_cloud_var = tk.BooleanVar(value=False)
        self.overlay_radius_var = tk.DoubleVar(value=0.5)
        self.show_feature_overlay_var = tk.BooleanVar(value=True)
        self.snap_to_keypoint_var = tk.BooleanVar(value=True)
        self.refine_corner_var = tk.BooleanVar(value=True)

        self.near_target_pid_var = tk.BooleanVar(value=True)
        self.near_target_target_var = tk.BooleanVar(value=True)

        self.cloud_pids = None
        self.cloud_xyz = None
        self.cloud_colors = None
        self._overlay_cache = None
        self._overlay_projection_cache = ((None,) * 4, (None,) * 4)
        self._overlay_projection_cache_key = None
        self._overlay_subsample_cap = 5000

        self._refresh_after_id = None
        self._resize_after_id = None

        self._build_cloud_arrays()

        # Seed the (purpose, pid) list from the main window's current
        # A/B slots so the popup is not blank when reopened.
        self._seed_target_list_from_main(slot_a_init, slot_b_init)

        self.title("Point Selection")
        self.resizable(True, True)
        self.geometry("1440x1000")
        self.minsize(1180, 800)
        self.protocol("WM_DELETE_WINDOW", self._on_cancel)

        try:
            from PIL import Image as PILImage, ImageTk
            self.PILImage = PILImage
            self.ImageTk = ImageTk
            self.have_pil = True
        except ImportError:
            self.have_pil = False

        self._build_ui()

        try:
            self.main_paned.add(self.bottom_frame, weight=1)
            self._bottom_attached = True
        except tk.TclError:
            self._bottom_attached = False

        self.kp_filter.trace_add("write", self._on_filter_changed)
        self.pid_filter.trace_add("write", self._on_filter_changed)
        self.overlay_radius_var.trace_add(
            "write", self._on_filter_changed)

        self._load_current_image()
        self._apply_filter_and_refresh()
        self._refresh_target_panel()
        self._render_target_list()
        self._refresh_bottom_strip()
        self._refresh_mode_anchor_widgets()
        self._refresh_slot_buttons()
        self._refresh_scale_info()
        self._refresh_target_panel_title()
        self._refresh_target_value_display()
        self.after_idle(self._set_bottom_sash)
        self.status_var.set(self._status_message())

    # --------------------------------------------------------------- seeding

    def _seed_target_list_from_main(self, slot_a, slot_b):
        """If the main window already has pid-backed A/B, seed the
        (purpose, pid) list so the dialog shows the current selection."""
        key = (self._get_purpose(), 'pid')
        tlist = self.target_lists.setdefault(key, [])
        if tlist:
            return
        group = 1
        for name, s in (('A', slot_a), ('B', slot_b)):
            if not s or s.get('state') != self.SLOT_FILLED:
                continue
            if s.get('pid') is None:
                continue
            if s.get('image') is None or s.get('xy') is None:
                continue
            try:
                xy = tuple(np.asarray(s['xy'],
                                       dtype=np.float64).tolist())
            except Exception:
                continue
            tlist.append({
                'slot': name,
                'image': s['image'],
                'xy': xy,
                'pid': int(s['pid']),
                'xyz': (np.asarray(s['xyz'], dtype=np.float64).copy()
                        if s.get('xyz') is not None else None),
                'kp_index': s.get('kp_index'),
                'group': group,
            })

    def _build_cloud_arrays(self):
        try:
            n = len(self.reconstruction.points3D)
        except Exception:
            n = 0
        if n == 0:
            return
        pids = np.empty(n, dtype=np.int64)
        xyz = np.empty((n, 3), dtype=np.float64)
        colors = np.empty((n, 3), dtype=np.float64)
        i = 0
        for pid, p in self.reconstruction.points3D.items():
            pids[i] = pid
            xyz[i] = p.xyz
            try:
                colors[i] = np.asarray(p.color,
                                       dtype=np.float64) / 255.0
            except Exception:
                colors[i] = 1.0
            i += 1
        self.cloud_pids = pids
        self.cloud_xyz = xyz
        self.cloud_colors = colors

    # --------------------------------------------------------------- helpers

    def _get_purpose(self):
        if self.purpose_callback is not None:
            try:
                p = self.purpose_callback()
                if p in ('rescale', 'measure'):
                    return p
            except Exception:
                pass
        return 'measure'

    def _current_target_key(self):
        return (self._get_purpose(), self.anchor_type_var.get())

    def _current_target_list(self):
        key = self._current_target_key()
        return self.target_lists.setdefault(key, [])

    def _effective_group(self):
        tlist = self._current_target_list()
        if not tlist:
            return 1
        cur = self._current_group()
        if any(t.get('group', 1) == cur for t in tlist):
            return cur
        per_group = {}
        for t in tlist:
            per_group.setdefault(t.get('group', 1), set()).add(t['slot'])
        groups_with_both = {
            g for g, slots in per_group.items() if {'A', 'B'} <= slots
        }
        if groups_with_both:
            return max(groups_with_both)
        return max(per_group)

    def _current_near_var(self):
        if self.anchor_type_var.get() == 'pid':
            return self.near_target_pid_var
        return self.near_target_target_var

    def _refresh_mode_anchor_widgets(self):
        at = self.anchor_type_var.get()
        for cb in (self.near_target_pid_cb,
                   self.near_target_target_cb):
            try:
                cb.grid_remove()
            except (tk.TclError, AttributeError):
                pass
        if at == 'pid':
            try:
                self.near_target_pid_cb.grid()
            except (tk.TclError, AttributeError):
                pass
        else:
            try:
                self.near_target_target_cb.grid()
            except (tk.TclError, AttributeError):
                pass

    def _status_message(self):
        purpose = self._get_purpose()
        at = self.anchor_type_var.get()
        if at == 'pid':
            near_on = self.near_target_pid_var.get()
        else:
            near_on = self.near_target_target_var.get()
        n_targets = len(self._current_target_list())
        return (f"Purpose: {purpose} · anchor: {at} · "
                f"effective group: {self._effective_group()} · "
                f"near: {near_on} · targets: {n_targets}")

    def _refresh_scale_info(self):
        try:
            scale = _mean_scale()
        except Exception:
            scale = None
        if scale is None:
            self.scale_info_var.set(
                "(not set) — coordinates shown in SfM units")
        else:
            self.scale_info_var.set(
                f"{scale:.6f} metric units per SfM unit "
                f"(coordinates below are rescaled)")

    def _refresh_target_panel_title(self):
        # The script buttons are usable in both anchor modes. In
        # pid mode the script replaces the built-in mean aggregation;
        # in target mode it is an optional override applied after the
        # standard multiview triangulation.
        self.target_bottom_panel.config(text="Target list")
        self.tv_select_script_btn.config(state="normal")
        self.tv_reset_script_btn.config(state="normal")

    def _collect_slot_observations(self, slot_name):
        tlist = self._current_target_list()
        obs = []
        for t in tlist:
            if t['slot'] != slot_name:
                continue
            try:
                u = float(t['xy'][0])
                v = float(t['xy'][1])
            except (TypeError, IndexError, ValueError):
                continue
            obs.append((t['image'], u, v))
        return obs

    def _compute_target_values(self):
        tlist = self._current_target_list()
        if not tlist:
            return None, None, [], 0, 0

        at = self.anchor_type_var.get()
        groups = sorted({t.get('group', 1) for t in tlist})

        if at == 'target':
            obs_a = self._collect_slot_observations('A')
            obs_b = self._collect_slot_observations('B')

            xa = None
            xb = None
            na = 0
            nb = 0

            if len(obs_a) >= 2:
                tri = _multiview_triangulate(obs_a, self.reconstruction)
                if tri is not None:
                    xa = np.asarray(tri[0], dtype=np.float64)
                    na = len(obs_a)
            if len(obs_b) >= 2:
                tri = _multiview_triangulate(obs_b, self.reconstruction)
                if tri is not None:
                    xb = np.asarray(tri[0], dtype=np.float64)
                    nb = len(obs_b)

            # Optional custom override. When a script is loaded it
            # receives the standard triangulation result as single-
            # element lists and may return replacements. When no
            # script is loaded, the standard triangulation result is
            # used unchanged.
            if _target_value_fn is not None and (xa is not None
                                                 or xb is not None):
                try:
                    sa = [xa] if xa is not None else []
                    sb = [xb] if xb is not None else []
                    ra, rb = _target_value_fn(sa, sb)
                    if ra is not None:
                        ra_arr = np.asarray(ra, dtype=np.float64)
                        if ra_arr.size == 3 and np.all(np.isfinite(ra_arr)):
                            xa = ra_arr.reshape(3)
                    if rb is not None:
                        rb_arr = np.asarray(rb, dtype=np.float64)
                        if rb_arr.size == 3 and np.all(np.isfinite(rb_arr)):
                            xb = rb_arr.reshape(3)
                except Exception as e:
                    print(f"WARNING: target value script failed in "
                          f"target mode: {e}")

            # No fallback to an unrelated existing XYZ when target
            # triangulation fails. Substituting the first available
            # XYZ would silently attach a different physical point to
            # the slot. Leave it as None so the UI can report the
            # failure and the user can correct the selection.
            return xa, xb, groups, na, nb

        slot_a_list = []
        slot_b_list = []
        for t in tlist:
            if t['slot'] == 'A' and t.get('xyz') is not None:
                slot_a_list.append(
                    np.asarray(t['xyz'], dtype=np.float64))
            elif t['slot'] == 'B' and t.get('xyz') is not None:
                slot_b_list.append(
                    np.asarray(t['xyz'], dtype=np.float64))

        xa, xb = _compute_target_value(slot_a_list, slot_b_list)
        if xa is not None:
            xa = np.asarray(xa, dtype=np.float64)
        if xb is not None:
            xb = np.asarray(xb, dtype=np.float64)
        return xa, xb, groups, len(slot_a_list), len(slot_b_list)

    def _refresh_target_value_display(self):
        at = self.anchor_type_var.get()
        try:
            xa, xb, groups, na, nb = self._compute_target_values()
        except Exception as e:
            self.tv_method_var.set(f"computation failed ({e})")
            return

        if _target_value_script_path:
            self.tv_method_var.set(
                f"custom: {os.path.basename(_target_value_script_path)}")
        elif at == 'target':
            self.tv_method_var.set(
                "standard multiview triangulation")
        else:
            self.tv_method_var.set("mean (built-in)")

        for item in self.tv_tree.get_children():
            self.tv_tree.delete(item)

        scale = _mean_scale()
        scale_str = (f"{scale:.6f} metric/SfM" if scale is not None
                     else "SfM (unscaled)")

        tlist = self._current_target_list()
        for slot_name, xyz in (('A', xa), ('B', xb)):
            slot_entries = [t for t in tlist
                            if t['slot'] == slot_name]
            if not slot_entries:
                self.tv_tree.insert(
                    "", "end",
                    values=(slot_name, "—", "—", "—", "—",
                            scale_str))
                continue

            # All distinct images for this slot, in first-seen order.
            images = []
            seen_imgs = set()
            for e in slot_entries:
                im = e.get('image')
                if im and im not in seen_imgs:
                    seen_imgs.add(im)
                    images.append(im)
            img_str = ", ".join(images) if images else "—"

            # All distinct kp indices for this slot.
            kps = []
            seen_kps = set()
            for e in slot_entries:
                kp = e.get('kp_index')
                if kp is not None and kp not in seen_kps:
                    seen_kps.add(kp)
                    kps.append(kp)
            kp_str = (", ".join(f"#{k}" for k in kps)
                      if kps else "—")

            # xy of the first entry remains the "primary" display.
            first = slot_entries[0]
            try:
                u = float(first['xy'][0])
                v = float(first['xy'][1])
                xy_str = f"({u:.1f}, {v:.1f})"
            except (TypeError, IndexError, ValueError):
                xy_str = "—"

            if xyz is not None:
                xyz_str = (f"({xyz[0]:.4f}, {xyz[1]:.4f}, "
                           f"{xyz[2]:.4f}) [SfM]")
            else:
                xyz_str = "—  (no 3D estimate)"

            self.tv_tree.insert(
                "", "end",
                values=(slot_name, img_str, kp_str, xy_str,
                        xyz_str, scale_str))

    def _select_target_value_script(self):
        path = filedialog.askopenfilename(
            title="Select target value calculation script",
            filetypes=[("Python scripts", "*.py"),
                       ("All files", "*.*")],
            parent=self)
        if not path:
            return
        if _set_target_value_script(path):
            self.status_var.set(
                f"Target value script set: {path}")
        else:
            messagebox.showerror(
                "Script error",
                "Could not load the target value script. It must "
                "define a callable named compute_target_value(a, b). "
                "Falling back to built-in mean.",
                parent=self)
            _set_target_value_script(None)
        self._refresh_target_value_display()
        self._render_target_list()

    def _reset_target_value_script(self):
        _set_target_value_script(None)
        at = self.anchor_type_var.get()
        if at == 'target':
            self.status_var.set(
                "Target value method reset to standard multiview "
                "triangulation.")
        else:
            self.status_var.set("Target value method reset to mean.")
        self._refresh_target_value_display()
        self._render_target_list()

    def _clear_slot_targets(self, slot_name):
        key = self._current_target_key()
        tlist = self.target_lists.get(key, [])
        n_before = len(tlist)
        new_list = [t for t in tlist if t['slot'] != slot_name]
        self.target_lists[key] = new_list
        n_after = len(new_list)
        if n_before == n_after:
            self.status_var.set(
                f"Slot {slot_name} already empty.")
            return
        self._render_target_list()
        self._refresh_bottom_strip()
        self._overlay_cache = None
        self._overlay_projection_cache = ((None,) * 4, (None,) * 4)
        self._overlay_projection_cache_key = None
        self._render_canvas()
        self.status_var.set(
            f"Cleared slot {slot_name} "
            f"({n_before - n_after} row(s) removed).")

    # --------------------------------------------------------------- UI build

    def _build_ui(self):
        menubar = tk.Menu(self)
        view_menu = tk.Menu(menubar, tearoff=0)
        view_menu.add_command(label="Fit to window",
                              command=self._reset_view,
                              accelerator="Ctrl+0")
        view_menu.add_command(label="Zoom in",
                              command=lambda: self._apply_zoom(1.25),
                              accelerator="Ctrl++")
        view_menu.add_command(label="Zoom out",
                              command=lambda: self._apply_zoom(1 / 1.25),
                              accelerator="Ctrl+-")
        view_menu.add_separator()
        view_menu.add_command(label="Close", command=self._on_cancel)
        menubar.add_cascade(label="View", menu=view_menu)
        self.config(menu=menubar)

        self.bind("<Control-0>", lambda e: self._reset_view())
        self.bind("<Control-equal>", lambda e: self._apply_zoom(1.25))
        self.bind("<Control-plus>", lambda e: self._apply_zoom(1.25))
        self.bind("<Control-KP_Add>", lambda e: self._apply_zoom(1.25))
        self.bind("<Control-minus>", lambda e: self._apply_zoom(1 / 1.25))
        self.bind("<Control-KP_Subtract>",
                  lambda e: self._apply_zoom(1 / 1.25))

        # Outer scroll wrapper. The scrollable content is the whole
        # paned body (top_frame / top_paned + the bottom pane that
        # holds target_bottom_panel). The status label and the
        # Apply / Commit / Cancel row stay fixed at the bottom of
        # the popup, outside this scroll area.
        scroll_outer = ttk.Frame(self)
        scroll_outer.pack(fill="both", expand=True)

        self.scroll_canvas = tk.Canvas(
            scroll_outer, highlightthickness=0)
        self.scroll_vscroll = ttk.Scrollbar(
            scroll_outer, orient="vertical",
            command=self.scroll_canvas.yview)
        self.scroll_canvas.configure(
            yscrollcommand=self.scroll_vscroll.set)

        self.scroll_vscroll.pack(side="right", fill="y")
        self.scroll_canvas.pack(side="left", fill="both", expand=True)

        self.scroll_frame = ttk.Frame(self.scroll_canvas)
        self._scroll_window = self.scroll_canvas.create_window(
            (0, 0), window=self.scroll_frame, anchor="nw")

        self._last_content_h = 0
        self._height_update_id = None

        def _on_scroll_frame_configure(event=None):
            try:
                bbox = self.scroll_canvas.bbox("all")
                if bbox is not None:
                    self.scroll_canvas.configure(scrollregion=bbox)
            except tk.TclError:
                pass

        def _on_scroll_canvas_configure(event):
            # Width: match the viewport so the paned body fills.
            try:
                self.scroll_canvas.itemconfigure(
                    self._scroll_window, width=event.width)
            except tk.TclError:
                pass
            # Height: deferred, because at the very first <Configure>
            # the bottom pane may not be attached yet and
            # top_frame.winfo_reqheight() is unreliable.
            if self._height_update_id is not None:
                try:
                    self.after_cancel(self._height_update_id)
                except tk.TclError:
                    pass
            try:
                self._height_update_id = self.after(
                    30, self._update_scroll_height)
            except tk.TclError:
                self._height_update_id = None

        self.scroll_frame.bind(
            "<Configure>", _on_scroll_frame_configure)
        self.scroll_canvas.bind(
            "<Configure>", _on_scroll_canvas_configure)

        self.main_paned = ttk.PanedWindow(
            self.scroll_frame, orient="vertical")
        self.main_paned.pack(fill="both", expand=True,
                             padx=6, pady=(6, 0))

        self.top_frame = ttk.Frame(self.main_paned)
        self.main_paned.add(self.top_frame, weight=4)

        self.top_paned = ttk.PanedWindow(self.top_frame,
                                         orient="horizontal")
        self.top_paned.pack(fill="both", expand=True)

        left_outer = ttk.Frame(self.top_paned)
        self.top_paned.add(left_outer, weight=2)

        left_canvas = tk.Canvas(left_outer, highlightthickness=0)
        left_vscroll = ttk.Scrollbar(left_outer, orient="vertical",
                                     command=left_canvas.yview)
        left_canvas.configure(yscrollcommand=left_vscroll.set)

        self.left_pane = ttk.Frame(left_canvas)
        left_canvas_window = left_canvas.create_window(
            (0, 0), window=self.left_pane, anchor="nw")

        def _on_left_pane_configure(event):
            left_canvas.configure(scrollregion=left_canvas.bbox("all"))
        self.left_pane.bind("<Configure>", _on_left_pane_configure)

        def _on_left_canvas_configure(event):
            # Width: match the viewport so left_pane fills horizontally.
            # Height: at least the viewport height, but never smaller
            # than left_pane's natural height (so the fixed header
            # sections are never clipped, and the existing
            # left_vscroll scrollbar engages if the pane is short).
            try:
                req_h = self.left_pane.winfo_reqheight()
            except tk.TclError:
                req_h = event.height
            target_h = max(event.height, req_h)
            try:
                left_canvas.itemconfigure(
                    left_canvas_window,
                    width=event.width,
                    height=target_h)
            except tk.TclError:
                pass
        left_canvas.bind("<Configure>", _on_left_canvas_configure)

        left_canvas.pack(side="left", fill="both", expand=True)
        left_vscroll.pack(side="right", fill="y")

        self.right_pane = ttk.Frame(self.top_paned)
        self.top_paned.add(self.right_pane, weight=3)

        self.bottom_frame = ttk.Frame(self.main_paned)
        self._bottom_attached = False

        # Scale indicator
        scale_row = ttk.Frame(self.left_pane)
        scale_row.pack(fill="x", pady=(0, 4))
        ttk.Label(scale_row, text="Scale:",
                  font=("TkDefaultFont", 9, "bold")).pack(side="left")
        self.scale_info_var = tk.StringVar(value="")
        ttk.Label(scale_row, textvariable=self.scale_info_var,
                  foreground="#008800",
                  wraplength=430, justify="left").pack(
            side="left", padx=6, anchor="w")

        # Anchor type panel
        self.target_panel = ttk.LabelFrame(
            self.left_pane,
            text="Target — anchor type and current state")
        self.target_panel.pack(fill="x", pady=(0, 4))

        ttk.Label(self.target_panel, text="Anchor type:",
                  font=("TkDefaultFont", 9, "bold")).grid(
            row=0, column=0, sticky="w", padx=6, pady=4)
        ttk.Radiobutton(self.target_panel, text="pid",
                        variable=self.anchor_type_var, value='pid',
                        command=self._on_anchor_type_change).grid(
            row=0, column=1, sticky="w", padx=4)
        ttk.Radiobutton(self.target_panel, text="target",
                        variable=self.anchor_type_var, value='target',
                        command=self._on_anchor_type_change).grid(
            row=0, column=2, sticky="w", padx=4)
        ttk.Label(self.target_panel, text="Group:",
                  font=("TkDefaultFont", 9, "bold")).grid(
            row=0, column=3, sticky="e", padx=(12, 4))
        ttk.Spinbox(self.target_panel, from_=1, to=999,
                    textvariable=self.group_var, width=6).grid(
            row=0, column=4, sticky="w", padx=4)

        self.anchor_info_var = tk.StringVar(value="")
        ttk.Label(self.target_panel, textvariable=self.anchor_info_var,
                  foreground="#004488",
                  font=("TkDefaultFont", 9),
                  wraplength=420, justify="left").grid(
            row=1, column=0, columnspan=5, sticky="w", padx=6, pady=2)

        self.pending_info_var = tk.StringVar(value="")
        ttk.Label(self.target_panel, textvariable=self.pending_info_var,
                  foreground="#aa4400",
                  font=("TkDefaultFont", 9),
                  wraplength=420, justify="left").grid(
            row=2, column=0, columnspan=5, sticky="w", padx=6,
            pady=(0, 4))

        # Filter / lookup — compact 2-column x 6-row layout.
        # Both near-active checkbuttons share the same cell (row 4,
        # col 1); _refresh_mode_anchor_widgets swaps them by
        # calling grid_remove() / grid() on that same position.
        filt = ttk.LabelFrame(self.left_pane, text="Filter and lookup")
        filt.pack(fill="x", pady=(0, 4))

        self.show_tri_only = tk.BooleanVar(value=True)
        self.kp_filter = tk.StringVar(value="")
        self.pid_filter = tk.StringVar(value="")
        self.find_pid_var = tk.StringVar(value="")

        CELL = {"padx": 6, "pady": 3, "sticky": "w"}

        # Row 0
        ttk.Checkbutton(
            filt,
            text="Show only 3D-backed keypoints in list",
            variable=self.show_tri_only,
            command=self._apply_filter_and_refresh).grid(
            row=0, column=0, **CELL)
        ttk.Checkbutton(
            filt,
            text="Overlay features on image",
            variable=self.show_feature_overlay_var,
            command=self._render_canvas).grid(
            row=0, column=1, **CELL)

        # Row 1
        ttk.Checkbutton(
            filt,
            text="Snap to keypoints",
            variable=self.snap_to_keypoint_var).grid(
            row=1, column=0, **CELL)
        ttk.Checkbutton(
            filt,
            text="Refine cornerSubPix",
            variable=self.refine_corner_var).grid(
            row=1, column=1, **CELL)

        # Row 2 — kp index and pid filters
        kp_cell = ttk.Frame(filt)
        kp_cell.grid(row=2, column=0, **CELL)
        ttk.Label(kp_cell, text="kp index contains:").pack(side="left")
        ttk.Entry(kp_cell, textvariable=self.kp_filter,
                  width=8).pack(side="left", padx=(4, 0))

        pid_cell = ttk.Frame(filt)
        pid_cell.grid(row=2, column=1, **CELL)
        ttk.Label(pid_cell, text="pid contains:").pack(side="left")
        ttk.Entry(pid_cell, textvariable=self.pid_filter,
                  width=8).pack(side="left", padx=(4, 0))

        # Row 3 — find pid and clear filters
        find_cell = ttk.Frame(filt)
        find_cell.grid(row=3, column=0, **CELL)
        ttk.Label(find_cell, text="Find pid:").pack(side="left")
        ttk.Entry(find_cell, textvariable=self.find_pid_var,
                  width=10).pack(side="left", padx=4)
        ttk.Button(find_cell, text="Find",
                   command=self._find_pid).pack(side="left")

        ttk.Button(filt, text="Clear filters",
                   command=self._clear_filters).grid(
            row=3, column=1, **CELL)

        # Row 4 — overlay cloud and near-active
        ttk.Checkbutton(
            filt,
            text="Overlay full 3D cloud (amber)",
            variable=self.overlay_cloud_var,
            command=self._on_overlay_changed).grid(
            row=4, column=0, **CELL)

        self.near_target_pid_cb = ttk.Checkbutton(
            filt, text="Near active (anchor=pid)",
            variable=self.near_target_pid_var,
            command=self._on_overlay_changed)
        self.near_target_pid_cb.grid(row=4, column=1, **CELL)

        self.near_target_target_cb = ttk.Checkbutton(
            filt, text="Near active (anchor=target)",
            variable=self.near_target_target_var,
            command=self._on_overlay_changed)
        self.near_target_target_cb.grid(row=4, column=1, **CELL)
        self.near_target_target_cb.grid_remove()

        # Row 5 — radius
        radius_cell = ttk.Frame(filt)
        radius_cell.grid(row=4, column=2, **CELL)
        ttk.Label(radius_cell, text="Radius (SfM):").pack(side="left")
        ttk.Spinbox(radius_cell, from_=0.01, to=1000.0, increment=0.05,
                    textvariable=self.overlay_radius_var,
                    width=8).pack(side="left", padx=(4, 0))

        ttk.Label(self.left_pane,
                  text="Keypoints in current image").pack(anchor="w")
        lf = ttk.Frame(self.left_pane)
        lf.pack(fill="both", expand=True)
        # Natural height is a request only; the listbox is packed with
        # fill="both", expand=True, so it grows to fill whatever room
        # the pane has left after the fixed header sections. A small
        # natural height keeps left_pane.winfo_reqheight() small, which
        # is what allows the pane to expand into the canvas viewport.
        self.listbox = tk.Listbox(lf, font=("Consolas", 9), height=8)
        self.listbox.pack(side="left", fill="both", expand=True)
        sb = ttk.Scrollbar(lf, orient="vertical",
                           command=self.listbox.yview)
        sb.pack(side="right", fill="y")
        self.listbox.config(yscrollcommand=sb.set)
        self.listbox.bind("<<ListboxSelect>>", self._on_list_select)

        # Right pane
        img_bar = ttk.Frame(self.right_pane)
        img_bar.pack(fill="x", pady=(0, 4))
        ttk.Label(img_bar, text="Image:").pack(side="left")
        self.image_combo = ttk.Combobox(
            img_bar, textvariable=self.current_image_name,
            values=self.image_names, state="readonly", width=50)
        self.image_combo.pack(side="left", padx=4, fill="x", expand=True)
        self.image_combo.bind("<<ComboboxSelected>>",
                              lambda e: self._on_image_change())
        ttk.Button(img_bar, text="◀", width=3,
                   command=lambda: self._step_image(-1)).pack(side="left")
        ttk.Button(img_bar, text="▶", width=3,
                   command=lambda: self._step_image(1)).pack(side="left")

        toolbar = ttk.Frame(self.right_pane)
        toolbar.pack(fill="x")
        ttk.Button(toolbar, text="+", width=3,
                   command=lambda: self._apply_zoom(1.25)).pack(
            side="left")
        ttk.Button(toolbar, text="-", width=3,
                   command=lambda: self._apply_zoom(1 / 1.25)).pack(
            side="left", padx=2)
        ttk.Button(toolbar, text="Fit",
                   command=self._reset_view).pack(side="left", padx=2)
        self.zoom_label = tk.StringVar(value="zoom 1.00x")
        ttk.Label(toolbar, textvariable=self.zoom_label,
                  foreground="#444").pack(side="left", padx=8)
        ttk.Label(toolbar,
                  text="(wheel zoom, middle/right drag pan)",
                  foreground="gray",
                  font=("TkDefaultFont", 8)).pack(side="left", padx=8)

        self.canvas_container = tk.Frame(self.right_pane, bg="#1e1e1e",
                                         highlightthickness=0)
        self.canvas_container.pack(fill="both", expand=True)
        self.canvas_container.pack_propagate(False)

        self.canvas = tk.Canvas(self.canvas_container,
                                width=800, height=520,
                                bg="#1e1e1e", highlightthickness=0)
        self.canvas.place(relx=0.5, rely=0.5, anchor="center")

        self.canvas.bind("<Button-1>", self._on_canvas_click)
        self.canvas.bind("<MouseWheel>", self._on_wheel)
        self.canvas.bind("<Button-4>", self._on_wheel)
        self.canvas.bind("<Button-5>", self._on_wheel)
        self.canvas.bind("<ButtonPress-2>", self._on_drag_start)
        self.canvas.bind("<B2-Motion>", self._on_drag_motion)
        self.canvas.bind("<ButtonRelease-2>", self._on_drag_end)
        self.canvas.bind("<ButtonPress-3>", self._on_drag_start)
        self.canvas.bind("<B3-Motion>", self._on_drag_motion)
        self.canvas.bind("<ButtonRelease-3>", self._on_drag_end)

        self.canvas_container.bind("<Configure>",
                                   self._on_container_configure)

        self.thumb_label_var = tk.StringVar(value="Co-visible cross images")
        self.thumb_label = ttk.Label(
            self.right_pane, textvariable=self.thumb_label_var,
            font=("TkDefaultFont", 9, "bold"))
        self.thumb_label.pack(anchor="w", pady=(4, 0))

        thumb_wrap = ttk.Frame(self.right_pane)
        thumb_wrap.pack(fill="x", pady=(2, 4))
        self.thumb_canvas = tk.Canvas(thumb_wrap, height=110,
                                      bg="#2a2a2a",
                                      highlightthickness=0)
        self.thumb_hscroll = ttk.Scrollbar(
            thumb_wrap, orient="horizontal",
            command=self.thumb_canvas.xview)
        self.thumb_canvas.configure(xscrollcommand=self.thumb_hscroll.set)
        self.thumb_canvas.pack(side="top", fill="x", expand=True)
        self.thumb_hscroll.pack(side="bottom", fill="x")

        # Bottom pane: target list + aggregated target value table.
        self.target_bottom_panel = ttk.LabelFrame(
            self.bottom_frame, text="Target list")
        self.target_bottom_panel.pack(fill="both", expand=True,
                                      padx=4, pady=4)

        tree_wrap = ttk.Frame(self.target_bottom_panel)
        tree_wrap.pack(fill="both", expand=True, padx=6, pady=4)

        cols = ("num", "group", "slot", "image", "xy",
                "xyz", "pid", "intrinsics", "extrinsics")
        # height= is only the natural (minimum) size request. The
        # tree is packed with fill="both", expand=True inside its
        # frame, and that frame is in turn expanded inside the
        # bottom pane. Lowering the natural height here lets the
        # tree shrink further when the user drags the sash upward,
        # while it still grows to fill the pane when there is room.
        self.target_tree = ttk.Treeview(
            tree_wrap, columns=cols, show="headings", height=3)
        for c, w, t in zip(cols,
                           (40, 50, 50, 200, 130, 240, 70, 240, 250),
                           ("#", "Grp", "Slot", "Image", "xy",
                            "xyz", "kp",
                            "intrinsics (fx,fy,cx,cy)",
                            "extrinsics (r|t)")):
            self.target_tree.heading(c, text=t)
            self.target_tree.column(c, width=w, anchor="w")

        tree_vscroll = ttk.Scrollbar(tree_wrap, orient="vertical",
                                     command=self.target_tree.yview)
        self.target_tree.configure(yscrollcommand=tree_vscroll.set)
        self.target_tree.pack(side="left", fill="both", expand=True)
        tree_vscroll.pack(side="right", fill="y")

        self.target_tree.bind("<<TreeviewSelect>>",
                              self._on_target_tree_select)

        btn_row = ttk.Frame(self.target_bottom_panel)
        btn_row.pack(anchor="w", padx=6, pady=(0, 6))

        self.btn_to_slot_a = tk.Button(
            btn_row, text="To Slot A",
            command=lambda: self._toggle_slot_button('A'), width=10)
        self.btn_to_slot_a.pack(side="left", padx=3)
        self.btn_to_slot_b = tk.Button(
            btn_row, text="To Slot B",
            command=lambda: self._toggle_slot_button('B'), width=10)
        self.btn_to_slot_b.pack(side="left", padx=3)

        ttk.Separator(btn_row, orient="vertical").pack(
            side="left", fill="y", padx=10)

        ttk.Button(btn_row, text="Delete",
                   command=self._delete_selected_target).pack(
            side="left", padx=3)
        ttk.Button(btn_row, text="Add",
                   command=self._add_pending_to_list).pack(
            side="left", padx=3)
        ttk.Button(btn_row, text="Edit",
                   command=self._edit_selected_target).pack(
            side="left", padx=3)

        # Target value frame
        tv_frame = ttk.LabelFrame(self.target_bottom_panel,
                                  text="Target value")
        tv_frame.pack(fill="x", padx=6, pady=(4, 6))

        tv_method_row = ttk.Frame(tv_frame)
        tv_method_row.pack(fill="x", padx=6, pady=(4, 2))
        ttk.Label(tv_method_row, text="Method:",
                  font=("TkDefaultFont", 9, "bold")).pack(side="left")
        self.tv_method_var = tk.StringVar(value="mean (built-in)")
        ttk.Label(tv_method_row, textvariable=self.tv_method_var,
                  foreground="#004488").pack(side="left", padx=6)
        self.tv_select_script_btn = ttk.Button(
            tv_method_row, text="Select Script…",
            command=self._select_target_value_script)
        self.tv_select_script_btn.pack(side="left", padx=6)
        self.tv_reset_script_btn = ttk.Button(
            tv_method_row, text="Reset to mean",
            command=self._reset_target_value_script)
        self.tv_reset_script_btn.pack(side="left")

        tv_table_wrap = ttk.Frame(tv_frame)
        tv_table_wrap.pack(fill="x", padx=6, pady=(2, 2))

        tv_cols = ("slot", "image", "kp", "xy", "xyz", "scale")
        self.tv_tree = ttk.Treeview(
            tv_table_wrap, columns=tv_cols, show="headings", height=2)
        for c, w, t in zip(tv_cols,
                           (50, 220, 90, 160, 260, 140),
                           ("Slot", "Image", "kp", "xy",
                            "target value xyz", "scale")):
            self.tv_tree.heading(c, text=t)
            self.tv_tree.column(c, width=w, anchor="w")
        self.tv_tree.pack(side="left", fill="x", expand=True)

        tv_btn_row = ttk.Frame(tv_frame)
        tv_btn_row.pack(fill="x", padx=6, pady=(2, 4))
        ttk.Button(tv_btn_row, text="Clear Slot A",
                   command=lambda: self._clear_slot_targets('A')).pack(
            side="left", padx=3)
        ttk.Button(tv_btn_row, text="Clear Slot B",
                   command=lambda: self._clear_slot_targets('B')).pack(
            side="left", padx=3)

        self.status_var = tk.StringVar(value="")
        self.status_label = ttk.Label(
            self, textvariable=self.status_var, foreground="gray",
            wraplength=1400, justify="left")
        self.status_label.pack(anchor="w", padx=12, pady=(4, 0))

        btn_row2 = ttk.Frame(self)
        btn_row2.pack(pady=8)
        ttk.Button(btn_row2, text="Apply",
                   command=self._on_apply).pack(side="left", padx=6)
        ttk.Button(btn_row2, text="Commit",
                   command=self._on_commit).pack(side="left", padx=6)
        ttk.Button(btn_row2, text="Cancel",
                   command=self._on_cancel).pack(side="left", padx=6)

    # --------------------------------------------------------------- helpers

    def _draw_crosshair(self, cx, cy, r, color, width=2):
        self.canvas.create_oval(cx - r, cy - r, cx + r, cy + r,
                                outline=color, width=width)
        self.canvas.create_line(cx - r - 3, cy, cx + r + 3, cy,
                                fill=color, width=width)
        self.canvas.create_line(cx, cy - r - 3, cx, cy + r + 3,
                                fill=color, width=width)

    def _set_bottom_sash(self):
        try:
            self.update_idletasks()
            h = self.main_paned.winfo_height()
            if h <= 300:
                return
            # Floor for the bottom pane: use the natural height
            # reported by bottom_frame (which contains
            # target_bottom_panel, itself containing the Target
            # list, its button row, and the Target value group).
            # Without this floor the tv_frame at the end of the
            # pack order gets clipped when the sash sits too low.
            try:
                bottom_req = self.bottom_frame.winfo_reqheight()
            except (tk.TclError, AttributeError):
                bottom_req = 320
            MIN_BOTTOM = max(int(bottom_req), 340)
            sash = int(h * 0.68)
            max_sash = h - MIN_BOTTOM
            if sash > max_sash:
                sash = max_sash
            if sash < 100:
                sash = 100
            self.main_paned.sashpos(0, sash)
        except tk.TclError:
            pass

    def _update_scroll_height(self):
        """Size the canvas window so the paned body has enough room.

        The paned window does not report a usable requested height on
        its own, so we give the inner frame an explicit height large
        enough for BOTH panes. We then (re)apply the sash split,
        because _set_bottom_sash already ran once during __init__ at
        a time when main_paned had no meaningful height.
        """
        self._height_update_id = None
        try:
            view_h = self.scroll_canvas.winfo_height()
        except tk.TclError:
            return

        need = 0
        try:
            need += self.top_frame.winfo_reqheight()
        except (tk.TclError, AttributeError):
            pass
        if getattr(self, "_bottom_attached", False):
            try:
                need += self.bottom_frame.winfo_reqheight()
            except (tk.TclError, AttributeError):
                pass
        need += 30  # sash + vertical padding

        # Small safety floor only. The floor exists to prevent the
        # paned body from being laid out at zero height during the
        # first Configure event; it is not meant to force a fixed
        # popup height. With this lower value the paned window simply
        # follows the viewport when the window is tall enough, and
        # the outer scrollbar only engages when the actual content
        # (top panes + bottom pane's fixed sections) exceeds it.
        FLOOR_H = 700
        target = max(view_h, need, FLOOR_H)
        if target != self._last_content_h:
            self._last_content_h = target
            try:
                self.scroll_canvas.itemconfigure(
                    self._scroll_window, height=target)
            except tk.TclError:
                pass
        # Re-apply the sash once the paned window actually has a
        # height. after_idle defers until the geometry manager has
        # propagated the new height down to main_paned.
        self.after_idle(self._set_bottom_sash)

    def _update_thumb_label(self):
        at = self.anchor_type_var.get()
        if at == 'pid':
            self.thumb_label_var.set(
                "Co-visible cross images (observing the anchor pid)")
        else:
            self.thumb_label_var.set(
                "All images in frame order")

    def _on_anchor_type_change(self):
        self.pending_point = None
        self.anchor_pid = None
        self.active_target_slot = 'A'
        self._update_thumb_label()
        self._refresh_mode_anchor_widgets()
        self._refresh_target_panel()
        try:
            self.group_var.set(str(self._next_available_group()))
        except tk.TclError:
            pass
        self._render_target_list()
        self._refresh_bottom_strip()
        self._overlay_cache = None
        self._overlay_projection_cache = ((None,) * 4, (None,) * 4)
        self._overlay_projection_cache_key = None
        self._render_canvas()
        self._refresh_scale_info()
        self._refresh_target_panel_title()
        self._refresh_target_value_display()
        self._refresh_slot_buttons()
        self.status_var.set(self._status_message())

    # --------------------------------------------------------------- target state

    def _toggle_slot_button(self, slot):
        if self.active_target_slot == slot:
            self.active_target_slot = None
        else:
            self.active_target_slot = slot
        self._refresh_slot_buttons()
        self._refresh_target_panel()

    def _refresh_slot_buttons(self):
        default_bg = "SystemButtonFace"
        active_bg = "#b0b0b0"
        for slot, btn in (('A', self.btn_to_slot_a),
                          ('B', self.btn_to_slot_b)):
            try:
                if self.active_target_slot == slot:
                    btn.config(bg=active_bg, relief="sunken")
                else:
                    btn.config(bg=default_bg, relief="raised")
            except tk.TclError:
                pass

    def _refresh_target_panel(self):
        at = self.anchor_type_var.get()
        if at == 'pid':
            if self.anchor_pid is not None:
                self.anchor_info_var.set(
                    f"Anchor pid: {self.anchor_pid}  "
                    f"(bottom strip shows co-visible images)")
            else:
                self.anchor_info_var.set(
                    "Anchor pid: not set. Click a keypoint with a pid "
                    "in the canvas, or use 'Find pid'.")
        else:
            self.anchor_info_var.set(
                "Anchor target: standard multiview triangulation over "
                "all observations of each slot.")

        if self.pending_point is not None:
            p = self.pending_point
            u, v = p['xy']
            pid_str = f"  pid={p['pid']}" if p.get('pid') is not None \
                else ""
            slot_str = (f"  → slot {self.active_target_slot}"
                        if self.active_target_slot else
                        "  (select To Slot A or B)")
            self.pending_info_var.set(
                f"Pending: {p['image']}  ({u:.1f}, {v:.1f})"
                f"{pid_str}{slot_str}")
        else:
            self.pending_info_var.set(
                "Pending: (click in the image to set a pending point)")
        self._refresh_slot_buttons()

    def _set_pending_point(self, image_name, u, v,
                           pid=None, xyz=None, kp_index=None):
        self.pending_point = {
            'image': image_name,
            'xy': (float(u), float(v)),
            'pid': pid,
            'xyz': (np.asarray(xyz, dtype=np.float64).copy()
                    if xyz is not None else None),
            'kp_index': kp_index,
        }
        if self.anchor_type_var.get() == 'pid':
            self.anchor_pid = pid
        self._refresh_target_panel()
        self._refresh_bottom_strip()
        self._overlay_cache = None
        self._overlay_projection_cache = ((None,) * 4, (None,) * 4)
        self._overlay_projection_cache_key = None
        self._render_canvas()

    def _clear_pending_point(self):
        self.pending_point = None
        self._refresh_target_panel()
        self._overlay_cache = None
        self._overlay_projection_cache = ((None,) * 4, (None,) * 4)
        self._overlay_projection_cache_key = None
        self._render_canvas()

    def _current_group(self):
        try:
            g = int(self.group_var.get())
            return g if g >= 1 else 1
        except (TypeError, ValueError, tk.TclError):
            return 1

    def _next_available_group(self):
        groups = {}
        for t in self._current_target_list():
            g = t.get('group', 1)
            groups.setdefault(g, set()).add(t['slot'])
        g = 1
        while True:
            s = groups.get(g, set())
            if not ({'A', 'B'} <= s):
                return g
            g += 1

    def _add_pending_to_list(self):
        if self.pending_point is None:
            self.status_var.set(
                "No pending point. Click in the image first.")
            return
        if self.active_target_slot is None:
            self.status_var.set(
                "Select 'To Slot A' or 'To Slot B' before adding.")
            return
        grp = self._current_group()
        entry = {
            'slot': self.active_target_slot,
            'image': self.pending_point['image'],
            'xy': self.pending_point['xy'],
            'pid': self.pending_point.get('pid'),
            'xyz': self.pending_point.get('xyz'),
            'kp_index': self.pending_point.get('kp_index'),
            'group': grp,
        }
        tlist = self._current_target_list()
        tlist.append(entry)
        n = len(tlist)
        self._clear_pending_point()
        try:
            self._render_target_list()
        except Exception as e:
            print(f"ERROR: _render_target_list raised: {e}")
            traceback.print_exc()
        self._refresh_bottom_strip()
        self._overlay_cache = None
        self._overlay_projection_cache = ((None,) * 4, (None,) * 4)
        self._overlay_projection_cache_key = None
        self._render_canvas()

        slots = {t['slot'] for t in tlist
                 if t.get('group', 1) == grp}
        if {'A', 'B'} <= slots:
            try:
                self.group_var.set(str(self._next_available_group()))
            except tk.TclError:
                pass

        self.status_var.set(
            f"Added target #{n} to slot {entry['slot']} "
            f"(group {grp}).")

    def _delete_selected_target(self):
        sels = self.target_tree.selection()
        if not sels:
            self.status_var.set("No row selected in target list.")
            return
        tlist = self._current_target_list()
        indices = sorted(
            [self.target_tree.index(s) for s in sels], reverse=True)
        for i in indices:
            if 0 <= i < len(tlist):
                del tlist[i]
        self._render_target_list()
        self._refresh_bottom_strip()
        self._overlay_cache = None
        self._overlay_projection_cache = ((None,) * 4, (None,) * 4)
        self._overlay_projection_cache_key = None
        self._render_canvas()
        self.status_var.set(
            f"Deleted {len(indices)} target point(s).")

    def _edit_selected_target(self):
        sels = self.target_tree.selection()
        if not sels:
            self.status_var.set("No row selected in target list.")
            return
        idx = self.target_tree.index(sels[0])
        tlist = self._current_target_list()
        if not (0 <= idx < len(tlist)):
            return

        entry = tlist[idx]
        old_image = entry['image']
        old_xy = (float(entry['xy'][0]), float(entry['xy'][1]))

        dlg = EditTargetDialog(self, entry, self.image_names)
        self.wait_window(dlg)
        if dlg.result is None:
            return

        new_image = dlg.result['image']
        new_xy = dlg.result['xy']
        image_changed = (new_image != old_image)
        # The edit dialog reformats xy to two decimals when it opens,
        # so a "no-op" edit can still produce a few-thousandths
        # difference. Treat sub-pixel deltas as unchanged so that
        # editing only the group does not throw away pid / xyz / kp.
        xy_changed = (abs(new_xy[0] - old_xy[0]) > 0.5
                      or abs(new_xy[1] - old_xy[1]) > 0.5)

        entry['slot'] = dlg.result['slot']
        entry['image'] = new_image
        entry['xy'] = new_xy
        entry['group'] = dlg.result['group']

        if image_changed or xy_changed:
            entry['pid'] = None
            entry['xyz'] = None
            entry['kp_index'] = None

        self._render_target_list()
        self._refresh_bottom_strip()
        self._overlay_cache = None
        self._overlay_projection_cache = ((None,) * 4, (None,) * 4)
        self._overlay_projection_cache_key = None
        self._render_canvas()
        self.status_var.set(f"Edited target #{idx + 1}.")

    def _render_target_list(self):
        for item in self.target_tree.get_children():
            self.target_tree.delete(item)
        tlist = self._current_target_list()

        for i, t in enumerate(tlist):
            g = t.get('group', 1)
            slot = t['slot']
            img_name = t['image']
            try:
                u = float(t['xy'][0])
                v = float(t['xy'][1])
            except (TypeError, IndexError, ValueError):
                u, v = 0.0, 0.0

            pid_str = (str(t['pid']) if t.get('pid') is not None
                       else "—")

            xyz = t.get('xyz')
            if xyz is not None:
                scale = _mean_scale()
                if scale is not None:
                    v_scaled = (np.asarray(xyz, dtype=np.float64)
                                * scale)
                    xyz_str = (f"({v_scaled[0]:.3f}, "
                               f"{v_scaled[1]:.3f}, "
                               f"{v_scaled[2]:.3f}) [m]")
                else:
                    xyz_str = (f"({xyz[0]:.3f}, {xyz[1]:.3f}, "
                               f"{xyz[2]:.3f}) [SfM]")
            else:
                xyz_str = "—"

            intr_str = "—"
            extr_str = "—"

            img_obj = self.reconstruction.find_image_with_name(img_name)
            if img_obj is not None:
                try:
                    cam = _get_camera(self.reconstruction,
                                      img_obj.camera_id)
                    intr = _intrinsics_for_camera(cam)
                    if intr is not None:
                        intr_str = (f"fx={intr[0]:.1f} "
                                    f"fy={intr[1]:.1f} "
                                    f"cx={intr[2]:.1f} "
                                    f"cy={intr[3]:.1f}")
                except Exception:
                    intr_str = "—"

                try:
                    cfw = _cam_from_world_of(img_obj)
                    R = np.asarray(cfw.rotation.matrix(),
                                   dtype=np.float64)
                    tr = np.asarray(cfw.translation,
                                    dtype=np.float64)
                    rvec, _ = cv2.Rodrigues(R)
                    extr_str = (
                        f"r=({rvec[0,0]:.3f},{rvec[1,0]:.3f},"
                        f"{rvec[2,0]:.3f}) "
                        f"t=({tr[0]:.3f},{tr[1]:.3f},{tr[2]:.3f})")
                except Exception:
                    extr_str = "—"

            self.target_tree.insert(
                "", "end",
                values=(i + 1, g, slot, img_name,
                        f"({u:.1f}, {v:.1f})",
                        xyz_str, pid_str,
                        intr_str, extr_str))

        self._refresh_scale_info()
        self._refresh_target_value_display()

    def _on_target_tree_select(self, event):
        sels = self.target_tree.selection()
        if not sels:
            return
        idx = self.target_tree.index(sels[0])
        tlist = self._current_target_list()
        if not (0 <= idx < len(tlist)):
            return
        entry = tlist[idx]
        if entry['image'] != self.current_image_name.get():
            self._jump_to_image(entry['image'])

    # --------------------------------------------------------------- reference positions

    def _compute_group_reference_positions(self, group):
        result = {'A': None, 'B': None}
        at = self.anchor_type_var.get()
        if at == 'target':
            for slot in ('A', 'B'):
                obs = self._collect_slot_observations(slot)
                if len(obs) >= 2:
                    tri = _multiview_triangulate(obs, self.reconstruction)
                    if tri is not None:
                        result[slot] = np.asarray(tri[0],
                                                  dtype=np.float64)
            return result

        tlist = self._current_target_list()
        for slot in ('A', 'B'):
            obs = [t for t in tlist
                   if t.get('group', 1) == group and t['slot'] == slot]
            if not obs:
                continue
            images = {o['image'] for o in obs}
            if len(obs) >= 2 and len(images) >= 2:
                tri = _multiview_triangulate(
                    [(o['image'], o['xy'][0], o['xy'][1]) for o in obs],
                    self.reconstruction)
                if tri is not None:
                    result[slot] = np.asarray(tri[0], dtype=np.float64)
                    continue
            known = next((o for o in obs
                          if o.get('xyz') is not None), None)
            if known is not None:
                result[slot] = np.asarray(known['xyz'],
                                          dtype=np.float64)
        return result

    # --------------------------------------------------------------- events

    def _on_list_select(self, event):
        idxs = self.listbox.curselection()
        if not idxs:
            return
        row = idxs[0]
        if row >= len(self.visible_indices):
            return
        all_idx = self.visible_indices[row]
        m = self.all_matches[all_idx]

        img_name = self.current_image_name.get()
        self._set_pending_point(
            img_name, m['x'], m['y'],
            pid=m['pid'], xyz=m['xyz'],
            kp_index=m['kp_index'])
        self.status_var.set(
            f"Pending: {img_name} kp #{m['kp_index']}")

    def _pick_nearest_keypoint(self, canvas_x, canvas_y, tol_px=25):
        if self.source_image is None:
            return None
        scale = self.current_scale
        if scale <= 0:
            return None
        ix = (canvas_x - self.current_x_off) / scale
        iy = (canvas_y - self.current_y_off) / scale
        tol2 = tol_px * tol_px
        best = None
        best_d2 = float('inf')
        for i in self.visible_indices:
            m = self.all_matches[i]
            dx = (m['x'] - ix) * scale
            dy = (m['y'] - iy) * scale
            d2 = dx * dx + dy * dy
            if d2 < best_d2:
                best_d2 = d2
                best = i
        if best is None or best_d2 > tol2:
            return None
        return self.all_matches[best]

    def _refine_click(self, u, v):
        if self.source_image is None:
            return (u, v)
        try:
            gray = cv2.cvtColor(self.source_image, cv2.COLOR_BGR2GRAY)
        except cv2.error:
            return (u, v)
        H, W = gray.shape[:2]
        u_i = int(round(u))
        v_i = int(round(v))
        if not (5 <= u_i < W - 5 and 5 <= v_i < H - 5):
            return (u, v)
        pts = np.array([[[float(u), float(v)]]], dtype=np.float32)
        try:
            criteria = (cv2.TERM_CRITERIA_EPS
                        + cv2.TERM_CRITERIA_MAX_ITER, 20, 0.01)
            cv2.cornerSubPix(gray, pts, (5, 5), (-1, -1), criteria)
        except cv2.error:
            return (u, v)
        return (float(pts[0, 0, 0]), float(pts[0, 0, 1]))

    def _on_canvas_click(self, event):
        if self.source_image is None:
            return
        scale = self.current_scale
        if scale <= 0:
            return

        img_name = self.current_image_name.get()
        hit = self._pick_nearest_keypoint(event.x, event.y)

        if self.snap_to_keypoint_var.get():
            if hit is not None:
                self._set_pending_point(
                    img_name, hit['x'], hit['y'],
                    pid=hit['pid'], xyz=hit['xyz'],
                    kp_index=hit['kp_index'])
                return

            at = self.anchor_type_var.get()
            if at == 'pid' and self.anchor_pid is not None:
                pid = self.anchor_pid
                entries = self.pid_index.get(pid, [])
                other_imgs = sorted(
                    {e[0] for e in entries if e[0] != img_name})
                if other_imgs:
                    n_show = min(len(other_imgs), 5)
                    joined = ", ".join(other_imgs[:n_show])
                    if len(other_imgs) > n_show:
                        joined += f", +{len(other_imgs) - n_show} more"
                    self.status_var.set(
                        f"No keypoint near the click. The anchor "
                        f"pid {pid} is observed in {len(other_imgs)} "
                        f"other image(s): {joined}. "
                        f"Jump there or disable 'Snap to keypoints' "
                        f"to place a manual point.")
                    return
                else:
                    self.status_var.set(
                        f"No keypoint near the click and the anchor "
                        f"pid {pid} is not observed anywhere else. "
                        f"Disable 'Snap to keypoints' to place a "
                        f"manual point.")
                    return

            self.status_var.set(
                "No keypoint near the click. Disable "
                "'Snap to keypoints' to place a manual point, "
                "or select a different image.")
            return

        ix = (event.x - self.current_x_off) / scale
        iy = (event.y - self.current_y_off) / scale
        u, v = ix, iy
        if self.refine_corner_var.get():
            u2, v2 = self._refine_click(u, v)
            if (abs(u2 - u) > 1e-6 or abs(v2 - v) > 1e-6):
                u, v = u2, v2
        self._set_pending_point(img_name, u, v,
                                pid=None, xyz=None,
                                kp_index=None)

    # --------------------------------------------------------------- canvas containers

    def _on_container_configure(self, event):
        if self._resize_after_id is not None:
            try:
                self.after_cancel(self._resize_after_id)
            except tk.TclError:
                pass
        try:
            self._resize_after_id = self.after(
                self.RESIZE_DEBOUNCE_MS, self._adjust_canvas_size)
        except tk.TclError:
            pass

    def _adjust_canvas_size(self):
        self._resize_after_id = None
        if self.img_w <= 0 or self.img_h <= 0:
            return
        try:
            cw = self.canvas_container.winfo_width()
            ch = self.canvas_container.winfo_height()
        except tk.TclError:
            return
        if cw < 10 or ch < 10:
            return
        aspect = self.img_w / self.img_h
        if cw / ch > aspect:
            new_h = ch
            new_w = max(1, int(round(new_h * aspect)))
        else:
            new_w = cw
            new_h = max(1, int(round(new_w / aspect)))
        try:
            self.canvas.config(width=new_w, height=new_h)
            self.canvas.place(relx=0.5, rely=0.5, anchor="center")
        except tk.TclError:
            pass

    # --------------------------------------------------------------- loading

    def _load_current_image(self):
        name = self.current_image_name.get().strip()
        img = self.reconstruction.find_image_with_name(name)
        if img is None:
            self.current_image_obj = None
            self.current_camera = None
            self.source_image = None
            self.img_w = 0
            self.img_h = 0
            self.all_matches = []
            self.visible_indices = []
            return
        self.current_image_obj = img
        self.current_camera = _get_camera(self.reconstruction,
                                          img.camera_id)

        self.source_image = None
        self.img_w = 0
        self.img_h = 0
        if self.have_pil and self.images_dir:
            path = os.path.join(self.images_dir, name)
            if os.path.isfile(path):
                im = cv2.imread(path)
                if im is not None:
                    self.source_image = im
                    self.img_h, self.img_w = im.shape[:2]

        pts2d = getattr(img, "points2D", None) or []
        matches = []
        for idx, kp in enumerate(pts2d):
            try:
                x, y = float(kp.xy[0]), float(kp.xy[1])
            except (TypeError, IndexError, ValueError):
                continue
            pid = _keypoint_3d_id(kp)
            xyz = None
            res = None
            if pid is not None:
                pt = _get_point3d(self.reconstruction, pid)
                if pt is not None:
                    xyz = np.asarray(pt.xyz, dtype=np.float64)
                    if self.current_camera is not None:
                        uv = _project_world_point(
                            self.current_camera, img, xyz)
                        if uv is not None:
                            res = math.hypot(uv[0] - x, uv[1] - y)
                else:
                    pid = None
            matches.append({'kp_index': idx, 'pid': pid,
                            'x': x, 'y': y, 'xyz': xyz, 'res': res})
        self.all_matches = matches
        self.zoom = 1.0
        self.pan_x = 0.0
        self.pan_y = 0.0

        self.after_idle(self._adjust_canvas_size)

    # --------------------------------------------------------------- filters

    def _on_filter_changed(self, *args):
        if self._refresh_after_id is not None:
            try:
                self.after_cancel(self._refresh_after_id)
            except tk.TclError:
                pass
        try:
            self._refresh_after_id = self.after(
                self.FILTER_DEBOUNCE_MS, self._do_debounced_refresh)
        except tk.TclError:
            pass

    def _do_debounced_refresh(self):
        self._refresh_after_id = None
        try:
            self._apply_filter_and_refresh()
        except tk.TclError:
            pass

    def _clear_filters(self):
        self.kp_filter.set("")
        self.pid_filter.set("")
        self._apply_filter_and_refresh()

    def _apply_filter_and_refresh(self):
        show_only_tri = self.show_tri_only.get()
        kp_f = self.kp_filter.get().strip()
        pid_f = self.pid_filter.get().strip()
        vis = []
        for i, m in enumerate(self.all_matches):
            if show_only_tri and m['pid'] is None:
                continue
            if kp_f and kp_f not in str(m['kp_index']):
                continue
            if pid_f:
                if m['pid'] is None or pid_f not in str(m['pid']):
                    continue
            vis.append(i)
        self.visible_indices = vis

        self.listbox.delete(0, "end")
        for i in vis:
            m = self.all_matches[i]
            res_str = (f"{m['res']:6.2f}"
                       if m['res'] is not None else "  n/a ")
            pid_str = (f"{m['pid']:<8d}"
                       if m['pid'] is not None else "  untri ")
            self.listbox.insert(
                "end",
                f"kp #{m['kp_index']:<6d} pid={pid_str} "
                f"xy=({m['x']:7.1f},{m['y']:7.1f})  "
                f"resid={res_str}px")
        if not self.status_var.get() or \
                self.status_var.get().startswith(
                    ("Purpose:", "Mode:")):
            self.status_var.set(self._status_message())
        self._render_canvas()

    # --------------------------------------------------------------- overlay

    def _on_overlay_changed(self):
        self._overlay_cache = None
        self._overlay_projection_cache = ((None,) * 4, (None,) * 4)
        self._overlay_projection_cache_key = None
        self._render_canvas()
        self.status_var.set(self._status_message())

    def _collect_near_xyz(self):
        refs = []
        grp = self._effective_group()
        group_refs = self._compute_group_reference_positions(grp)
        for sname in ('A', 'B'):
            xyz = group_refs.get(sname)
            if xyz is not None:
                refs.append(xyz)
        if self.pending_point is not None and \
                self.pending_point.get('xyz') is not None:
            refs.append(np.asarray(self.pending_point['xyz'],
                                   dtype=np.float64))
        return refs

    def _overlay_cache_key(self):
        try:
            radius = round(float(self.overlay_radius_var.get()), 6)
        except (tk.TclError, ValueError):
            radius = 0.5

        grp = self._effective_group()
        tlist = self._current_target_list()
        sig = tuple(
            (t['slot'], t['image'],
             round(float(t['xy'][0]), 3),
             round(float(t['xy'][1]), 3),
             (t['xyz'].tobytes()
              if t.get('xyz') is not None else None))
            for t in tlist if t.get('group', 1) == grp)
        pending_key = (
            self.pending_point['xyz'].tobytes()
            if (self.pending_point is not None
                and self.pending_point.get('xyz') is not None)
            else None
        )
        refs_key = (grp, sig, self._current_target_key(),
                    pending_key)

        return (
            self.current_image_name.get(),
            bool(self.overlay_cloud_var.get()),
            bool(self._current_near_var().get()),
            radius,
            refs_key,
        )

    def _compute_overlay_points(self):
        near_on = self._current_near_var().get()
        overlay_on = self.overlay_cloud_var.get()
        empty = (None, None, None, None)

        if not near_on and not overlay_on:
            return empty, empty
        if self.cloud_xyz is None or len(self.cloud_xyz) == 0:
            return empty, empty
        if self.current_camera is None or \
                self.current_image_obj is None:
            return empty, empty

        key = self._overlay_cache_key()
        if key == self._overlay_projection_cache_key:
            return self._overlay_projection_cache

        full_res = empty
        if overlay_on:
            full_res = self._project_cloud_slice(
                self.cloud_xyz, self.cloud_pids, self.cloud_colors)

        near_res = empty
        if near_on:
            refs = self._collect_near_xyz()
            if refs:
                try:
                    r = float(self.overlay_radius_var.get())
                except (tk.TclError, ValueError):
                    r = 0.5
                if r <= 0:
                    r = 0.5
                r2 = r * r
                mask = np.zeros(len(self.cloud_xyz), dtype=bool)
                for ref in refs:
                    d2 = np.sum(
                        (self.cloud_xyz - ref) ** 2, axis=1)
                    mask |= (d2 <= r2)
                if np.any(mask):
                    near_res = self._project_cloud_slice(
                        self.cloud_xyz[mask],
                        self.cloud_pids[mask],
                        self.cloud_colors[mask])

        result = (full_res, near_res)
        self._overlay_projection_cache = result
        self._overlay_projection_cache_key = key
        return result

    def _project_cloud_slice(self, xyz, pids, colors):
        if len(xyz) == 0:
            return (None, None, None, None)

        try:
            cfw = _cam_from_world_of(self.current_image_obj)
            R = np.asarray(cfw.rotation.matrix(), dtype=np.float64)
            t = np.asarray(cfw.translation, dtype=np.float64)
        except Exception:
            return (None, None, None, None)

        # Try native projection for the whole slice first. Fall back
        # to the manual path per-point only for models the manual
        # path supports.
        model = getattr(self.current_camera, "model_name", "")
        use_native = False
        native_fn = getattr(self.current_camera, "img_from_cam", None)
        if callable(native_fn):
            use_native = True
        elif model not in _MANUAL_PINHOLE_MODELS:
            return (None, None, None, None)

        Xc = (R @ xyz.T).T + t
        front = Xc[:, 2] > 1e-6
        if not np.any(front):
            return (None, None, None, None)
        Xc = Xc[front]
        pids = pids[front]
        colors = colors[front]

        if use_native:
            u_list = []
            v_list = []
            keep = []
            for i in range(Xc.shape[0]):
                uv = _native_project(self.current_camera, Xc[i])
                if uv is None:
                    continue
                u_list.append(uv[0])
                v_list.append(uv[1])
                keep.append(i)
            if not keep:
                return (None, None, None, None)
            u = np.asarray(u_list, dtype=np.float64)
            v = np.asarray(v_list, dtype=np.float64)
            keep_idx = np.asarray(keep, dtype=np.int64)
            colors = colors[keep_idx]
            pids = pids[keep_idx]
        else:
            K, dist = _camera_K_dist(self.current_camera)
            if K is None:
                return (None, None, None, None)
            xn = Xc[:, 0] / Xc[:, 2]
            yn = Xc[:, 1] / Xc[:, 2]
            r2 = xn * xn + yn * yn
            k1, k2, p1, p2 = dist
            radial = 1.0 + k1 * r2 + k2 * r2 * r2
            xd = xn * radial + 2.0 * p1 * xn * yn + \
                p2 * (r2 + 2.0 * xn * xn)
            yd = yn * radial + \
                p1 * (r2 + 2.0 * yn * yn) + 2.0 * p2 * xn * yn
            fx = K[0, 0]; fy = K[1, 1]; cx = K[0, 2]; cy = K[1, 2]
            u = fx * xd + cx
            v = fy * yd + cy

        W, H = self.img_w, self.img_h
        if W == 0 or H == 0:
            return (None, None, None, None)
        inb = (u >= 0) & (u < W) & (v >= 0) & (v < H)
        if not np.any(inb):
            return (None, None, None, None)
        u = u[inb]; v = v[inb]
        colors = colors[inb]; pids = pids[inb]

        cap = self._overlay_subsample_cap
        if len(u) > cap:
            idx = np.linspace(0, len(u) - 1, cap).astype(np.int64)
            u = u[idx]; v = v[idx]
            colors = colors[idx]; pids = pids[idx]

        return (u, v, colors, pids)

    # --------------------------------------------------------------- rendering

    def _render_canvas(self):
        self.canvas.delete("all")
        self.photo = None

        if self.source_image is None:
            if self.current_image_obj is not None and not self.have_pil:
                self.canvas.create_text(
                    10, 10, anchor="nw", fill="#cccccc",
                    text=("Install Pillow (pip install Pillow) to "
                          "enable the image preview."))
            elif self.current_image_obj is not None:
                self.canvas.create_text(
                    10, 10, anchor="nw", fill="#cccccc",
                    text=("Set 'Images Directory' to enable the image "
                          "preview."))
            return

        try:
            cw = int(self.canvas['width'])
            ch = int(self.canvas['height'])
        except tk.TclError:
            return
        iw, ih = self.img_w, self.img_h
        if iw == 0 or ih == 0:
            return

        fit = min(cw / iw, ch / ih)
        self.base_scale = fit
        scale = fit * self.zoom
        x_off = (cw - iw * scale) / 2 + self.pan_x
        y_off = (ch - ih * scale) / 2 + self.pan_y

        sx0 = max(0.0, -x_off / scale)
        sy0 = max(0.0, -y_off / scale)
        sx1 = min(float(iw), (cw - x_off) / scale)
        sy1 = min(float(ih), (ch - y_off) / scale)

        if sx1 > sx0 and sy1 > sy0:
            ix0, iy0 = int(math.floor(sx0)), int(math.floor(sy0))
            ix1 = min(iw, int(math.ceil(sx1)))
            iy1 = min(ih, int(math.ceil(sy1)))
            crop = self.source_image[iy0:iy1, ix0:ix1]
            dw = max(1, int(round((ix1 - ix0) * scale)))
            dh = max(1, int(round((iy1 - iy0) * scale)))
            if scale > 4.0:
                interp = cv2.INTER_NEAREST
            elif scale < 1.0:
                interp = cv2.INTER_AREA
            else:
                interp = cv2.INTER_LINEAR
            crop_r = cv2.resize(crop, (dw, dh), interpolation=interp)
            crop_rgb = cv2.cvtColor(crop_r, cv2.COLOR_BGR2RGB)
            pil = self.PILImage.fromarray(crop_rgb)
            self.photo = self.ImageTk.PhotoImage(pil)
            px = int(round(x_off + ix0 * scale))
            py = int(round(y_off + iy0 * scale))
            self.canvas.create_image(px, py, anchor="nw",
                                     image=self.photo)

        self.current_scale = scale
        self.current_x_off = x_off
        self.current_y_off = y_off

        kp_r = 2 if scale < 4 else 3
        show_features = self.show_feature_overlay_var.get()

        if show_features:
            full_res, near_res = self._compute_overlay_points()

            us, vs, _full_cols, _full_pids = full_res
            if us is not None and len(us) > 0:
                for i in range(len(us)):
                    ov_x = x_off + us[i] * scale
                    ov_y = y_off + vs[i] * scale
                    if ov_x < -8 or ov_y < -8 or \
                            ov_x > cw + 8 or ov_y > ch + 8:
                        continue
                    self.canvas.create_oval(
                        ov_x - kp_r, ov_y - kp_r,
                        ov_x + kp_r, ov_y + kp_r,
                        fill=self.OVERLAY_COLOR_FULL, outline="",
                        tags="overlay_full")

            n_us, n_vs, _n_cols, _n_pids = near_res
            if n_us is not None and len(n_us) > 0:
                for i in range(len(n_us)):
                    ov_x = x_off + n_us[i] * scale
                    ov_y = y_off + n_vs[i] * scale
                    if ov_x < -8 or ov_y < -8 or \
                            ov_x > cw + 8 or ov_y > ch + 8:
                        continue
                    self.canvas.create_oval(
                        ov_x - kp_r, ov_y - kp_r,
                        ov_x + kp_r, ov_y + kp_r,
                        fill=self.OVERLAY_COLOR_NEAR, outline="",
                        tags="overlay_near")

            if n_us is not None and len(n_us) > 0:
                self._overlay_cache = near_res
            elif us is not None and len(us) > 0:
                self._overlay_cache = full_res
            else:
                self._overlay_cache = None

            for i in self.visible_indices:
                m = self.all_matches[i]
                cx = x_off + m['x'] * scale
                cy = y_off + m['y'] * scale
                if cx < -8 or cy < -8 or cx > cw + 8 or cy > ch + 8:
                    continue
                color = "#00dd00" if m['pid'] is not None else "#888888"
                self.canvas.create_oval(cx - kp_r, cy - kp_r,
                                        cx + kp_r, cy + kp_r,
                                        fill=color, outline="")
        else:
            self._overlay_cache = None

        cur_name = self.current_image_name.get()
        tlist = self._current_target_list()

        groups = {}
        for entry in tlist:
            if entry['image'] != cur_name:
                continue
            g = entry.get('group', 1)
            groups.setdefault(g, {'A': [], 'B': []})
            groups[g][entry['slot']].append(entry)

        for g, pair in groups.items():
            for a in pair['A']:
                for b in pair['B']:
                    ax = x_off + a['xy'][0] * scale
                    ay = y_off + a['xy'][1] * scale
                    bx = x_off + b['xy'][0] * scale
                    by = y_off + b['xy'][1] * scale
                    self.canvas.create_line(
                        ax, ay, bx, by,
                        fill="#ffff00", width=1, dash=(4, 3))

        for entry in tlist:
            if entry['image'] != cur_name:
                continue
            u, v = entry['xy']
            ox = x_off + u * scale
            oy = y_off + v * scale
            color = (self.SLOT_COLORS['A']
                     if entry['slot'] == 'A'
                     else self.SLOT_COLORS['B'])
            self._draw_crosshair(ox, oy, 7, color, 2)
            grp = entry.get('group', 1)
            self.canvas.create_text(
                ox + 10, oy - 10,
                text=f"{entry['slot']}{grp}",
                fill=color,
                font=("TkDefaultFont", 8, "bold"),
                anchor="w")

        if self.pending_point is not None and \
                self.pending_point['image'] == cur_name:
            u, v = self.pending_point['xy']
            px = x_off + u * scale
            py = y_off + v * scale
            color = "#ffff00"
            self.canvas.create_line(px - 14, py, px - 4, py,
                                    fill=color, width=2)
            self.canvas.create_line(px + 4, py, px + 14, py,
                                    fill=color, width=2)
            self.canvas.create_line(px, py - 14, px, py - 4,
                                    fill=color, width=2)
            self.canvas.create_line(px, py + 4, px, py + 14,
                                    fill=color, width=2)
            self.canvas.create_oval(px - 4, py - 4, px + 4, py + 4,
                                    outline=color, width=2)

        self.zoom_label.set(f"zoom {self.zoom:.2f}x")

    # --------------------------------------------------------------- events (cont.)

    def _on_wheel(self, event):
        d = getattr(event, 'delta', 0)
        if d > 0:
            self._apply_zoom(1.25, anchor=(event.x, event.y))
        elif d < 0:
            self._apply_zoom(1 / 1.25, anchor=(event.x, event.y))
        elif getattr(event, 'num', 0) == 4:
            self._apply_zoom(1.25, anchor=(event.x, event.y))
        elif getattr(event, 'num', 0) == 5:
            self._apply_zoom(1 / 1.25, anchor=(event.x, event.y))
        return "break"

    def _on_drag_start(self, event):
        self.drag_anchor = (event.x, event.y, self.pan_x, self.pan_y)

    def _on_drag_motion(self, event):
        if self.drag_anchor is None:
            return
        x0, y0, px0, py0 = self.drag_anchor
        self.pan_x = px0 + (event.x - x0)
        self.pan_y = py0 + (event.y - y0)
        self._render_canvas()

    def _on_drag_end(self, event):
        self.drag_anchor = None

    def _apply_zoom(self, factor, anchor=None):
        cw = int(self.canvas['width'])
        ch = int(self.canvas['height'])
        iw, ih = self.img_w, self.img_h
        if iw == 0 or ih == 0:
            return
        new_zoom = max(0.25, min(80.0, self.zoom * factor))
        if new_zoom == self.zoom:
            return
        if anchor is None:
            anchor = (cw / 2.0, ch / 2.0)
        ax, ay = anchor
        scale = self.current_scale
        x_off = self.current_x_off
        y_off = self.current_y_off
        if scale > 0:
            ix = (ax - x_off) / scale
            iy = (ay - y_off) / scale
        else:
            ix, iy = iw / 2.0, ih / 2.0
        self.zoom = new_zoom
        ns = self.base_scale * new_zoom
        self.pan_x = ax - (cw - iw * ns) / 2.0 - ix * ns
        self.pan_y = ay - (ch - ih * ns) / 2.0 - iy * ns
        self._render_canvas()

    def _reset_view(self):
        self.zoom = 1.0
        self.pan_x = 0.0
        self.pan_y = 0.0
        self._render_canvas()

    def _step_image(self, delta):
        if not self.image_names:
            return
        try:
            cur = self.image_names.index(
                self.current_image_name.get())
        except ValueError:
            cur = 0
        new = max(0, min(len(self.image_names) - 1, cur + delta))
        if new == cur:
            return
        self.current_image_name.set(self.image_names[new])
        self._on_image_change()

    def _on_image_change(self):
        self._load_current_image()
        self.pending_point = None
        self._apply_filter_and_refresh()
        self._refresh_target_panel()
        self._refresh_bottom_strip()

    # --------------------------------------------------------------- lookup

    def _find_pid(self):
        s = self.find_pid_var.get().strip()
        if not s:
            return
        try:
            pid = int(s)
        except ValueError:
            messagebox.showerror("Invalid pid",
                                 "Enter an integer pid.", parent=self)
            return
        self._show_pid_dialog(pid, self.pid_index.get(pid, []))

    def _show_pid_dialog(self, pid, entries):
        if not entries:
            messagebox.showinfo(
                "No observations",
                f"pid {pid} has no recorded observations.",
                parent=self)
            return

        dlg = tk.Toplevel(self)
        dlg.title(f"pid {pid} — observed in {len(entries)} images")
        dlg.transient(self)
        dlg.geometry("620x460")

        ttk.Label(
            dlg,
            text=(f"pid {pid} appears in {len(entries)} image(s). "
                  f"Click a row to jump the preview to that image."),
            wraplength=580).pack(anchor="w", padx=10, pady=(8, 4))

        cols = ("image", "kp_index", "resid")
        tree = ttk.Treeview(dlg, columns=cols, show="headings",
                            height=16)
        for c, w in zip(cols, (380, 90, 100)):
            tree.heading(c, text=c)
            tree.column(c, width=w, anchor="w")

        rows = []
        for img_name, kp_idx in entries:
            img_obj = self.reconstruction.find_image_with_name(img_name)
            res = None
            if img_obj is not None and kp_idx < len(img_obj.points2D):
                kp = img_obj.points2D[kp_idx]
                if _keypoint_3d_id(kp) == pid:
                    pt = _get_point3d(self.reconstruction, pid)
                    cam = _get_camera(self.reconstruction,
                                      img_obj.camera_id)
                    if pt is not None and cam is not None:
                        uv = _project_world_point(cam, img_obj, pt.xyz)
                        if uv is not None:
                            try:
                                px = float(kp.xy[0])
                                py = float(kp.xy[1])
                                res = math.hypot(uv[0] - px,
                                                 uv[1] - py)
                            except Exception:
                                pass
            rows.append((res, img_name, kp_idx))

        rows.sort(key=lambda r: (r[0] is None,
                                 r[0] if r[0] is not None else 0.0))
        for res, img_name, kp_idx in rows:
            res_str = f"{res:.2f}" if res is not None else "n/a"
            tree.insert("", "end", values=(img_name, kp_idx, res_str))
        tree.pack(fill="both", expand=True, padx=10, pady=4)

        def _on_select(event):
            sel = tree.selection()
            if not sel:
                return
            vals = tree.item(sel[0], "values")
            if self.anchor_type_var.get() == 'pid':
                self.anchor_pid = pid
                self._refresh_target_panel()
                self._refresh_bottom_strip()
            self._jump_to_image(vals[0])

        tree.bind("<<TreeviewSelect>>", _on_select)
        ttk.Button(dlg, text="Close",
                   command=dlg.destroy).pack(pady=6)

    def _jump_to_image(self, name):
        if name not in self.image_names:
            return
        self.current_image_name.set(name)
        self._on_image_change()

    def _jump_to_best_view_for_pid(self, pid):
        entries = self.pid_index.get(pid, [])
        if not entries:
            return

        best = None
        for img_name, kp_idx in entries:
            img_obj = self.reconstruction.find_image_with_name(img_name)
            if img_obj is None or kp_idx >= len(img_obj.points2D):
                continue
            kp = img_obj.points2D[kp_idx]
            if _keypoint_3d_id(kp) != pid:
                continue
            cam = _get_camera(self.reconstruction, img_obj.camera_id)
            pt = _get_point3d(self.reconstruction, pid)
            if cam is None or pt is None:
                continue
            uv = _project_world_point(cam, img_obj, pt.xyz)
            if uv is None:
                continue
            try:
                px = float(kp.xy[0]); py = float(kp.xy[1])
            except Exception:
                continue
            res = math.hypot(uv[0] - px, uv[1] - py)
            if best is None or res < best[0]:
                best = (res, img_name, kp_idx)

        if best is None:
            img_name, kp_idx = entries[0]
        else:
            _, img_name, kp_idx = best

        if img_name not in self.image_names:
            return
        self.current_image_name.set(img_name)
        self._load_current_image()
        self.pending_point = None
        self._apply_filter_and_refresh()
        self._refresh_bottom_strip()

        for m in self.all_matches:
            if m['kp_index'] == kp_idx:
                self._set_pending_point(
                    img_name, m['x'], m['y'],
                    pid=m['pid'], xyz=m['xyz'],
                    kp_index=m['kp_index'])
                return

    # --------------------------------------------------------------- bottom strip

    def _refresh_bottom_strip(self):
        at = self.anchor_type_var.get()
        if at == 'pid':
            if self.anchor_pid is not None:
                self._render_pid_strip(self.anchor_pid)
            else:
                self.thumb_canvas.delete("all")
                self.thumb_photos.clear()
                self.thumb_canvas.create_text(
                    10, 55, anchor="w", fill="#888888",
                    text=("No anchor pid set. Click a keypoint with a "
                          "pid, or use 'Find pid'."))
                self._reset_thumb_scrollregion()
        else:
            self._render_target_strip()

    def _reset_thumb_scrollregion(self):
        try:
            self.thumb_canvas.configure(
                scrollregion=self.thumb_canvas.bbox("all"))
        except tk.TclError:
            pass

    def _overlay_target_markers_on_thumbnail(self, small, img_name,
                                             nw, nh, cam):
        tlist = self._current_target_list()
        if not tlist or cam is None:
            return
        full_w = int(cam.width)
        full_h = int(cam.height)
        if full_w <= 0 or full_h <= 0:
            return
        fsx = nw / full_w
        fsy = nh / full_h
        for entry in tlist:
            if entry['image'] != img_name:
                continue
            px = int(round(entry['xy'][0] * fsx))
            py = int(round(entry['xy'][1] * fsy))
            color = (255, 130, 200) if entry['slot'] == 'A' \
                else (200, 130, 255)
            cv2.circle(small, (px, py), 5, color, 2,
                       lineType=cv2.LINE_AA)
            grp = entry.get('group', 1)
            cv2.putText(small, f"{entry['slot']}{grp}",
                        (px + 6, py - 6),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.4, color, 1,
                        lineType=cv2.LINE_AA)

    def _render_pid_strip(self, pid):
        self.thumb_canvas.delete("all")
        self.thumb_photos.clear()
        entries = self.pid_index.get(pid, [])
        if not entries:
            self.thumb_canvas.create_text(
                10, 55, anchor="w", fill="#888888",
                text=f"pid {pid} has no recorded observations.")
            self._reset_thumb_scrollregion()
            return
        if not self.have_pil:
            self.thumb_canvas.create_text(
                10, 55, anchor="w", fill="#888888",
                text="Install Pillow to see thumbnails.")
            self._reset_thumb_scrollregion()
            return

        THUMB_W, THUMB_H = 140, 90
        PAD = 6
        MAX_THUMBS = 60
        x = PAD
        shown = 0
        cur_name = self.current_image_name.get()
        for img_name, kp_idx in entries[:MAX_THUMBS]:
            path = os.path.join(self.images_dir, img_name)
            if not os.path.isfile(path):
                continue
            try:
                im = cv2.imread(path, cv2.IMREAD_REDUCED_COLOR_4)
            except cv2.error:
                im = None
            if im is None:
                im = cv2.imread(path)
                if im is None:
                    continue
            h, w = im.shape[:2]
            s = min(THUMB_W / w, THUMB_H / h)
            nw = max(1, int(w * s))
            nh = max(1, int(h * s))
            small = cv2.resize(im, (nw, nh),
                               interpolation=cv2.INTER_AREA)

            img_obj = self.reconstruction.find_image_with_name(img_name)
            cam = None
            if img_obj is not None and kp_idx < len(img_obj.points2D):
                cam = _get_camera(self.reconstruction,
                                  img_obj.camera_id)
                kp = img_obj.points2D[kp_idx]
                try:
                    if cam is not None:
                        full_w = int(cam.width)
                        full_h = int(cam.height)
                        if full_w > 0 and full_h > 0:
                            fsx = nw / full_w
                            fsy = nh / full_h
                            px = int(round(float(kp.xy[0]) * fsx))
                            py = int(round(float(kp.xy[1]) * fsy))
                            cv2.circle(small, (px, py), 6,
                                       (0, 215, 255), 2,
                                       lineType=cv2.LINE_AA)
                except Exception:
                    pass

            self._overlay_target_markers_on_thumbnail(
                small, img_name, nw, nh, cam)

            small_rgb = cv2.cvtColor(small, cv2.COLOR_BGR2RGB)
            pil = self.PILImage.fromarray(small_rgb)
            photo = self.ImageTk.PhotoImage(pil)
            self.thumb_photos.append(photo)

            y = 10
            tag = f"pid_thumb_{shown}"
            is_current = (img_name == cur_name)
            outline = "#ffcc00" if is_current else "#666666"
            self.thumb_canvas.create_image(x, y, anchor="nw",
                                           image=photo, tags=tag)
            self.thumb_canvas.create_rectangle(
                x, y, x + nw, y + nh, outline=outline,
                width=3 if is_current else 1, tags=tag)
            label = (img_name if len(img_name) <= 18
                     else img_name[:16] + "…")
            self.thumb_canvas.create_text(
                x + 2, y + nh + 4, anchor="nw", fill="#dddddd",
                font=("TkDefaultFont", 7), text=label, tags=tag)
            self.thumb_canvas.tag_bind(
                tag, "<Button-1>",
                lambda e, n=img_name: self._jump_to_image(n))

            x += THUMB_W + PAD
            shown += 1

        if shown == 0:
            self.thumb_canvas.create_text(
                10, 55, anchor="w", fill="#888888",
                text=f"pid {pid} observed but no images loaded.")
        self._reset_thumb_scrollregion()

    def _render_target_strip(self):
        self.thumb_canvas.delete("all")
        self.thumb_photos.clear()

        names = list(self.image_names)

        if not names:
            self.thumb_canvas.create_text(
                10, 55, anchor="w", fill="#888888",
                text="No images are available in the reconstruction.")
            self._reset_thumb_scrollregion()
            return
        if not self.have_pil:
            self.thumb_canvas.create_text(
                10, 55, anchor="w", fill="#888888",
                text="Install Pillow to see thumbnails.")
            self._reset_thumb_scrollregion()
            return

        cur_name = self.current_image_name.get()
        THUMB_W, THUMB_H = 140, 90
        PAD = 6
        x = PAD
        shown = 0
        for img_name in names:
            path = os.path.join(self.images_dir, img_name)
            if not os.path.isfile(path):
                continue
            try:
                im = cv2.imread(path, cv2.IMREAD_REDUCED_COLOR_4)
            except cv2.error:
                im = None
            if im is None:
                im = cv2.imread(path)
                if im is None:
                    continue

            h, w = im.shape[:2]
            factor = min(THUMB_W / w, THUMB_H / h)
            nw = max(1, int(w * factor))
            nh = max(1, int(h * factor))
            small = cv2.resize(im, (nw, nh),
                               interpolation=cv2.INTER_AREA)

            img_obj = self.reconstruction.find_image_with_name(img_name)
            cam = (_get_camera(self.reconstruction, img_obj.camera_id)
                   if img_obj is not None else None)
            self._overlay_target_markers_on_thumbnail(
                small, img_name, nw, nh, cam)

            small_rgb = cv2.cvtColor(small, cv2.COLOR_BGR2RGB)
            pil = self.PILImage.fromarray(small_rgb)
            photo = self.ImageTk.PhotoImage(pil)
            self.thumb_photos.append(photo)

            y = 10
            tag = f"target_thumb_{shown}"
            is_current = (img_name == cur_name)
            outline = "#ffcc00" if is_current else "#666666"
            self.thumb_canvas.create_image(x, y, anchor="nw",
                                           image=photo, tags=tag)
            self.thumb_canvas.create_rectangle(
                x, y, x + nw, y + nh, outline=outline,
                width=3 if is_current else 1, tags=tag)
            label = (img_name if len(img_name) <= 18
                     else img_name[:16] + "…")
            self.thumb_canvas.create_text(
                x + 2, y + nh + 4, anchor="nw", fill="#dddddd",
                font=("TkDefaultFont", 7), text=label, tags=tag)
            self.thumb_canvas.tag_bind(
                tag, "<Button-1>",
                lambda e, n=img_name: self._jump_to_image(n))

            x += THUMB_W + PAD
            shown += 1

        if shown == 0:
            self.thumb_canvas.create_text(
                10, 55, anchor="w", fill="#888888",
                text=("No source images could be loaded. Check the "
                      "Images Directory and image filenames."))
        self._reset_thumb_scrollregion()

    # --------------------------------------------------------------- commit / apply

    def _get_current_slots(self):
        slot_a = self._compute_slot_from_targets('A')
        slot_b = self._compute_slot_from_targets('B')
        return slot_a, slot_b

    def _on_apply(self):
        slot_a, slot_b = self._get_current_slots()
        if self.on_apply_callback is not None:
            try:
                self.on_apply_callback(slot_a, slot_b)
            except Exception as e:
                self.status_var.set(f"Apply failed: {e}")
                return
        self.status_var.set(
            "Applied to main window. Dialog stays open.")

    def _on_commit(self):
        slot_a, slot_b = self._get_current_slots()
        self.result = (slot_a, slot_b)
        self.destroy()

    def _on_cancel(self):
        self.result = None
        self.destroy()

    def _compute_slot_from_targets(self, slot_name):
        tlist = self._current_target_list()
        observations = [{
            'image': t['image'],
            'xy': np.asarray(t['xy'], dtype=np.float64),
            'pid': t.get('pid'),
            'kp_index': t.get('kp_index'),
            'xyz': (np.asarray(t['xyz'], dtype=np.float64)
                    if t.get('xyz') is not None else None),
        } for t in tlist if t['slot'] == slot_name]

        if not observations:
            return {
                'state': self.SLOT_EMPTY,
                'image': None, 'kp_index': None,
                'xy': None, 'pid': None, 'xyz': None,
                'reproj_residual': None,
                'from_target': None,
                'observations': [],
            }

        xa, xb, _groups, _na, _nb = self._compute_target_values()
        xyz = xa if slot_name == 'A' else xb

        first = next((t for t in tlist if t['slot'] == slot_name),
                     None)

        return {
            'state': self.SLOT_FILLED,
            'image': first['image'] if first else None,
            'kp_index': (first.get('kp_index')
                         if first else None),
            'xy': (np.array(first['xy'], dtype=np.float64)
                   if first else None),
            'pid': None,
            'xyz': (np.asarray(xyz, dtype=np.float64)
                    if xyz is not None else None),
            'reproj_residual': None,
            'from_target': (
                f"triangulated_{slot_name}"
                if self.anchor_type_var.get() == 'target'
                else f"target_value_{slot_name}"),
            'observations': observations,
        }


# =============================================================================
# Main application
# =============================================================================

class ColmapViewerApp:
    SLOT_EMPTY = "empty"
    SLOT_FILLED = "filled"

    def __init__(self, root):
        self.root = root
        self.root.title("SFM Metric Calibrator")
        self.root.geometry("1100x850")
        self.root.resizable(True, True)
        self.root.minsize(850, 600)

        self.main_canvas = tk.Canvas(self.root, highlightthickness=0)
        self.main_vscroll = ttk.Scrollbar(
            self.root, orient="vertical", command=self.main_canvas.yview)
        self.main_canvas.configure(yscrollcommand=self.main_vscroll.set)
        self.main_vscroll.pack(side="right", fill="y")
        self.main_canvas.pack(side="left", fill="both", expand=True)

        self.content_frame = ttk.Frame(self.main_canvas)
        self._content_window = self.main_canvas.create_window(
            (0, 0), window=self.content_frame, anchor="nw")
        self.content_frame.bind(
            "<Configure>", self._on_main_content_configure)
        self.main_canvas.bind(
            "<Configure>", self._on_main_canvas_configure)
        self.root.bind_all("<MouseWheel>", self._on_main_mousewheel)
        self.root.bind_all("<Button-4>", self._on_main_mousewheel)
        self.root.bind_all("<Button-5>", self._on_main_mousewheel)

        self.sparse_path_var = tk.StringVar(value="")
        self.images_path_var = tk.StringVar(value="")
        self.mesh_path_var = tk.StringVar(value="")

        self.downscale_var = tk.DoubleVar(value=0.5)
        self.point_radii_var = tk.DoubleVar(value=0.01)
        self.load_features_var = tk.BooleanVar(value=True)
        self.only_triangulated_var = tk.BooleanVar(value=True)
        self.max_error_var = tk.DoubleVar(value=2.0)
        self.min_track_var = tk.IntVar(value=3)
        self.draw_traj_var = tk.BooleanVar(value=True)
        self.blueprint_var = tk.StringVar(
            value="Heuristic (auto-layout)")

        self.purpose_var = tk.StringVar(value='measure')

        self.slot_a = self._empty_slot()
        self.slot_b = self._empty_slot()

        self.point_a_var = tk.StringVar(value="(empty)")
        self.point_b_var = tk.StringVar(value="(empty)")
        self.slot_summary_var = tk.StringVar(
            value="A: (empty)   B: (empty)")
        self.distance_var = tk.StringVar(value="—")
        self.distance_3d_var = tk.StringVar(value="")
        self.distance_scale_var = tk.StringVar(value="")
        self.known_var = tk.StringVar(value="")
        self.scale_var = tk.StringVar(value="(no scale set)")
        self.model_units_var = tk.StringVar(
            value="Model units: SfM (unscaled).")
        self.ref_var = tk.StringVar(value="Reference: (not loaded)")
        self.status_var = tk.StringVar(value="Ready.")

        self._measure_entries = {}

        self._last_seen_recon_path = None
        self._pid_index = None
        self._pid_index_recon = None
        self._selection_dialog = None

        self.root.protocol("WM_DELETE_WINDOW", self.on_close)
        self.create_widgets()

        self.root.after(500, self._poll_reconstruction)
        self._refresh_slots()
        self._refresh_scale_display()
        self._refresh_measure_button_state()

    def _on_main_content_configure(self, _event=None):
        try:
            self.main_canvas.configure(
                scrollregion=self.main_canvas.bbox("all"))
        except tk.TclError:
            pass

    def _on_main_canvas_configure(self, event):
        try:
            self.main_canvas.itemconfigure(
                self._content_window, width=event.width)
        except tk.TclError:
            pass

    def _on_main_mousewheel(self, event):
        try:
            widget_path = str(getattr(event, "widget", ""))
            content_path = str(self.content_frame)
            canvas_path = str(self.main_canvas)
            if not (
                widget_path == canvas_path
                or widget_path == content_path
                or widget_path.startswith(content_path + ".")
            ):
                return
            if getattr(event, "num", None) == 4:
                delta = -1
            elif getattr(event, "num", None) == 5:
                delta = 1
            else:
                delta = -int(event.delta / 120) if event.delta else 0
                if delta == 0 and event.delta:
                    delta = -1 if event.delta > 0 else 1
            if delta:
                self.main_canvas.yview_scroll(delta, "units")
        except (tk.TclError, AttributeError):
            pass

    def _empty_slot(self):
        return {'state': self.SLOT_EMPTY,
                'image': None, 'kp_index': None,
                'xy': None, 'pid': None, 'xyz': None,
                'reproj_residual': None, 'from_target': None,
                'observations': []}

    def _reset_calibration_state(self):
        """Clear all calibration and measurement state tied to the
        currently loaded reconstruction.

        Called whenever the active reconstruction is replaced, so
        anchors, slot selections, and measurement entries from a
        previous model cannot silently contribute to the scale of, or
        to an export from, a new model.
        """
        global _scale_anchors
        _scale_anchors.clear()

        self.slot_a = self._empty_slot()
        self.slot_b = self._empty_slot()
        self._measure_entries.clear()
        self._pid_index = None
        self._pid_index_recon = None

        # Mirror the cleared state in the UI tables.
        try:
            for iid in self.anchor_tree.get_children():
                self.anchor_tree.delete(iid)
        except (tk.TclError, AttributeError):
            pass
        try:
            for iid in self.measure_tree.get_children():
                self.measure_tree.delete(iid)
        except (tk.TclError, AttributeError):
            pass

        # Close an open keypoint-selection popup; its target lists
        # are also model-specific.
        if self._selection_dialog is not None:
            try:
                if self._selection_dialog.winfo_exists():
                    self._selection_dialog.destroy()
            except tk.TclError:
                pass
            self._selection_dialog = None

        self.distance_var.set("—")
        self.distance_3d_var.set("")
        self.distance_scale_var.set("")
        self._refresh_slots()
        self._refresh_scale_display()
        self._refresh_measure_button_state()

    def _on_new_reconstruction_committed(self, new_path):
        """Called on the Tk main thread as soon as launch_
        visualization has committed a new reconstruction.

        Calibration state is reset only on this signal, which fires
        exactly once per successful load and before the rest of the
        visualization work runs. A failure later in the worker (mesh
        load, point cloud logging) does not undo the reset, because
        the new model is already active and valid.
        """
        global _current_reconstruction_path
        try:
            self._reset_calibration_state()
        except Exception as e:
            print(f"WARNING: calibration reset failed: {e}")
            traceback.print_exc()
        self._last_seen_recon_path = (
            new_path or _current_reconstruction_path)
        self._refresh_reference_line()
        self.status_var.set(
            "Loaded new reconstruction; calibration state reset.")

    def on_close(self):
        global _recording_stream
        _safe_flush()
        try:
            rr.disconnect()
        except Exception:
            pass
        _recording_stream = None
        self.root.destroy()

    def create_widgets(self):
        pad = {'padx': 10, 'pady': 4}

        path_frame = ttk.LabelFrame(
            self.content_frame, text="1. Required Directories (Sparse SfM)")
        path_frame.pack(fill="x", padx=10, pady=6)

        ttk.Label(path_frame, text="Sparse Model Path:").grid(
            row=0, column=0, sticky="w", **pad)
        ttk.Entry(path_frame, textvariable=self.sparse_path_var,
                  width=55).grid(row=0, column=1, **pad)
        ttk.Button(path_frame, text="Browse",
                   command=self.browse_sparse).grid(
            row=0, column=2, **pad)

        ttk.Label(path_frame, text="Images Directory:").grid(
            row=1, column=0, sticky="w", **pad)
        ttk.Entry(path_frame, textvariable=self.images_path_var,
                  width=55).grid(row=1, column=1, **pad)
        ttk.Button(path_frame, text="Browse",
                   command=self.browse_images).grid(
            row=1, column=2, **pad)

        ttk.Button(path_frame,
                   text="Load Reconstruction (standalone)",
                   command=self.load_reconstruction_manually).grid(
            row=2, column=1, sticky="w", **pad)
        ttk.Label(path_frame,
                  text=("Loads the sparse model without launching Rerun. "
                        "Enables measurement on its own."),
                  foreground="gray",
                  font=("TkDefaultFont", 8)).grid(
            row=3, column=1, columnspan=2, sticky="w",
            padx=10, pady=(0, 6))

        mesh_frame = ttk.LabelFrame(
            self.content_frame,
            text="2. Optional Dense Mesh (mesh PLY or OBJ)")
        mesh_frame.pack(fill="x", padx=10, pady=4)

        ttk.Label(mesh_frame, text="Mesh file:").grid(
            row=0, column=0, sticky="w", **pad)
        ttk.Entry(mesh_frame, textvariable=self.mesh_path_var,
                  width=55).grid(row=0, column=1, **pad)
        ttk.Button(mesh_frame, text="Browse",
                   command=self.browse_mesh).grid(
            row=0, column=2, **pad)

        filter_frame = ttk.LabelFrame(
            self.content_frame, text="3. Point Cloud Filtering")
        filter_frame.pack(fill="x", padx=10, pady=4)

        ttk.Label(filter_frame,
                  text="Max Reprojection Error (pixels):").grid(
            row=0, column=0, sticky="w", **pad)
        ttk.Spinbox(filter_frame, from_=0.1, to=10.0, increment=0.1,
                    textvariable=self.max_error_var, width=8).grid(
            row=0, column=1, sticky="w", **pad)

        ttk.Label(filter_frame,
                  text="Min Camera Observations:").grid(
            row=1, column=0, sticky="w", **pad)
        ttk.Spinbox(filter_frame, from_=2, to=20, increment=1,
                    textvariable=self.min_track_var, width=8).grid(
            row=1, column=1, sticky="w", **pad)

        vis_frame = ttk.LabelFrame(
            self.content_frame,
            text="4. Visualization Settings (Rerun side)")
        vis_frame.pack(fill="x", padx=10, pady=4)

        ttk.Label(vis_frame,
                  text="Image Downscale (1.0 = Max):").grid(
            row=0, column=0, sticky="w", **pad)
        ttk.Spinbox(vis_frame, from_=0.1, to=1.0, increment=0.1,
                    textvariable=self.downscale_var, width=8).grid(
            row=0, column=1, sticky="w", **pad)

        ttk.Label(vis_frame, text="3D Point Radii:").grid(
            row=0, column=2, sticky="e", **pad)
        ttk.Entry(vis_frame, textvariable=self.point_radii_var,
                  width=8).grid(row=0, column=3, sticky="w", **pad)

        ttk.Checkbutton(vis_frame,
                        text="Rerun: show 2D keypoints",
                        variable=self.load_features_var).grid(
            row=1, column=0, sticky="w", **pad)
        ttk.Checkbutton(vis_frame,
                        text="Rerun: only 3D-backed keypoints (pid ≥ 0)",
                        variable=self.only_triangulated_var).grid(
            row=1, column=1, columnspan=2, sticky="w", **pad)
        ttk.Checkbutton(vis_frame,
                        text="Draw Camera Trajectory in Rerun 3D view",
                        variable=self.draw_traj_var).grid(
            row=2, column=0, columnspan=3, sticky="w", **pad)

        ttk.Label(vis_frame, text="Blueprint Layout:").grid(
            row=3, column=0, sticky="w", **pad)
        ttk.Combobox(vis_frame, textvariable=self.blueprint_var,
                     values=list(BLUEPRINT_PRESETS.keys()),
                     state="readonly", width=32).grid(
            row=3, column=1, columnspan=3, sticky="w", **pad)

        meas_frame = ttk.LabelFrame(
            self.content_frame, text="5. Measurement")
        meas_frame.pack(fill="x", padx=10, pady=4)

        ttk.Label(meas_frame, textvariable=self.ref_var,
                  foreground="gray",
                  font=("TkDefaultFont", 8)).grid(
            row=0, column=0, columnspan=6, sticky="w", **pad)

        # Model-units label and A/B point-summary label removed;
        # the Select Point button is kept.
        ttk.Button(meas_frame, text="Select Point",
                   command=lambda: self.open_selection_dialog('A')).grid(
            row=2, column=0, sticky="w", **pad)

        purpose_row = ttk.Frame(meas_frame)
        purpose_row.grid(row=4, column=0, columnspan=6, sticky="w",
                         padx=10, pady=(8, 2))
        ttk.Label(purpose_row, text="Purpose:",
                  font=("TkDefaultFont", 9, "bold")).pack(side="left")
        ttk.Radiobutton(purpose_row, text="Rescale",
                        variable=self.purpose_var, value='rescale',
                        command=self._on_purpose_change).pack(
            side="left", padx=6)
        ttk.Radiobutton(purpose_row, text="Measure",
                        variable=self.purpose_var, value='measure',
                        command=self._on_purpose_change).pack(
            side="left", padx=6)

        self.rescale_panel = ttk.Frame(meas_frame)
        self.rescale_panel.grid(row=5, column=0, columnspan=6,
                                sticky="w", padx=10, pady=(2, 2))
        ttk.Label(self.rescale_panel,
                  text="Known metric distance:").pack(side="left")
        ttk.Entry(self.rescale_panel, textvariable=self.known_var,
                  width=14).pack(side="left", padx=6)
        self.btn_set_scale = ttk.Button(
            self.rescale_panel, text="Add Scale Anchor",
            command=self.do_set_scale)
        self.btn_set_scale.pack(side="left", padx=4)
        ttk.Button(self.rescale_panel, text="Clear Anchors",
                   command=self.do_clear_scale).pack(side="left", padx=4)
        ttk.Label(self.rescale_panel, text="Scale:",
                  foreground="gray").pack(side="left", padx=(12, 4))
        ttk.Label(self.rescale_panel, textvariable=self.scale_var,
                  foreground="#008800").pack(side="left")

        self.measure_panel = ttk.Frame(meas_frame)
        self.measure_panel.grid(row=6, column=0, columnspan=6,
                                sticky="w", padx=10, pady=(2, 2))
        self.btn_add_point = ttk.Button(
            self.measure_panel, text="Add Point",
            command=self._on_add_point_clicked, state="disabled")
        self.btn_add_point.pack(side="left")
        ttk.Label(self.measure_panel,
                  text="Distance:").pack(side="left", padx=(12, 4))
        ttk.Label(self.measure_panel, textvariable=self.distance_var,
                  foreground="#0055bb",
                  font=("TkDefaultFont", 11, "bold")).pack(side="left")
        ttk.Label(self.measure_panel,
                  textvariable=self.distance_3d_var,
                  foreground="#0055bb").pack(side="left", padx=8)

        ttk.Label(meas_frame, textvariable=self.distance_scale_var,
                  foreground="#008800").grid(
            row=7, column=0, columnspan=6, sticky="w", **pad)

        export_row = ttk.Frame(meas_frame)
        export_row.grid(row=8, column=0, columnspan=6, sticky="w",
                        padx=10, pady=(6, 2))
        ttk.Button(export_row,
                   text="Export Metric COLMAP Project…",
                   command=self.export_metric_sparse_model).pack(
            side="left")
        ttk.Button(export_row, text="Export Metric Points (PLY)…",
                   command=self.export_metric_points_ply).pack(
            side="left", padx=8)
        ttk.Label(export_row,
                  text="(both require at least one scale anchor)",
                  foreground="gray",
                  font=("TkDefaultFont", 8)).pack(side="left", padx=4)

        anchor_ctrl = ttk.Frame(meas_frame)
        anchor_ctrl.grid(row=9, column=0, columnspan=6, sticky="ew",
                         padx=10, pady=(6, 0))
        ttk.Label(anchor_ctrl, text="Scale anchors:",
                  font=("TkDefaultFont", 9, "bold")).pack(side="left")
        ttk.Button(anchor_ctrl, text="Edit",
                   command=self._edit_selected_anchor).pack(
            side="right", padx=4)
        ttk.Button(anchor_ctrl, text="Remove Selected",
                   command=self.remove_selected_anchor).pack(
            side="right", padx=4)
        ttk.Button(anchor_ctrl, text="Clear All",
                   command=self.clear_anchors).pack(
            side="right", padx=4)

        anchor_cols = ("time", "a", "b", "sfm", "metric", "ratio")
        self.anchor_tree = ttk.Treeview(
            meas_frame, columns=anchor_cols, show="headings", height=3)
        for c, t, w in zip(anchor_cols,
                           ("Time", "Anchor A", "Anchor B",
                            "d (SfM)", "d (known)", "ratio"),
                           (60, 220, 220, 90, 90, 90)):
            self.anchor_tree.heading(c, text=t)
            self.anchor_tree.column(c, width=w, anchor="w")
        self.anchor_tree.grid(row=10, column=0, columnspan=6,
                              sticky="ew", padx=10, pady=(0, 4))

        scale_value_frame = ttk.LabelFrame(
            meas_frame, text="Scale value (aggregated)")
        scale_value_frame.grid(row=11, column=0, columnspan=6,
                               sticky="ew", padx=10, pady=(0, 6))

        sv_method_row = ttk.Frame(scale_value_frame)
        sv_method_row.pack(fill="x", padx=6, pady=(4, 2))
        ttk.Label(sv_method_row, text="Method:",
                  font=("TkDefaultFont", 9, "bold")).pack(side="left")
        self.sv_method_var = tk.StringVar(value="mean (built-in)")
        ttk.Label(sv_method_row, textvariable=self.sv_method_var,
                  foreground="#004488").pack(side="left", padx=6)
        ttk.Button(sv_method_row, text="Select Script…",
                   command=self._select_scale_value_script).pack(
            side="left", padx=6)
        ttk.Button(sv_method_row, text="Reset to mean",
                   command=self._reset_scale_value_script).pack(
            side="left")

        self.sv_value_var = tk.StringVar(value="Value: —")
        ttk.Label(scale_value_frame, textvariable=self.sv_value_var,
                  foreground="#008800",
                  font=("TkDefaultFont", 10, "bold")).pack(
            fill="x", padx=6, pady=(0, 4))

        meas_ctrl = ttk.Frame(meas_frame)
        meas_ctrl.grid(row=12, column=0, columnspan=6, sticky="ew",
                       padx=10, pady=(6, 0))
        ttk.Label(meas_ctrl, text="Measurements:",
                  font=("TkDefaultFont", 9, "bold")).pack(side="left")
        ttk.Button(meas_ctrl, text="Measure",
                   command=self._on_measure_run_clicked).pack(
            side="left", padx=(12, 4))
        ttk.Button(meas_ctrl, text="Remove Selected",
                   command=self.remove_selected_measure).pack(
            side="right", padx=4)
        ttk.Button(meas_ctrl, text="Clear All",
                   command=self.clear_measurements).pack(
            side="right", padx=4)
        ttk.Button(meas_ctrl, text="Export Annotated…",
                   command=self.export_annotated_measurements).pack(
            side="right", padx=4)
        ttk.Button(meas_ctrl, text="Export CSV",
                   command=self.export_history_csv).pack(
            side="right", padx=4)

        meas_cols = ("time", "a", "b",
                     "px_image", "d_value", "scale", "metric")
        self.measure_tree = ttk.Treeview(
            meas_frame, columns=meas_cols, show="headings", height=4)
        for c, t, w in zip(meas_cols,
                           ("Time", "Point A", "Point B",
                            "px image", "d_value (x,y,z)", "scale",
                            "d (metric)"),
                           (60, 240, 240, 200, 140, 90, 110)):
            self.measure_tree.heading(c, text=t)
            self.measure_tree.column(c, width=w, anchor="w")
        self.measure_tree.grid(row=13, column=0, columnspan=6,
                               sticky="ew", padx=10, pady=(0, 6))

        ttk.Label(meas_frame, textvariable=self.status_var,
                  foreground="gray",
                  font=("TkDefaultFont", 8),
                  wraplength=1000, justify="left").grid(
            row=14, column=0, columnspan=6, sticky="w", **pad)

        ttk.Button(self.content_frame, text="Launch Rerun Viewer",
                   command=self.run_script).pack(
            pady=12, ipadx=10, ipady=5)

        self._on_purpose_change()

    def _on_purpose_change(self):
        if self.purpose_var.get() == 'rescale':
            self.rescale_panel.grid()
            self.measure_panel.grid_remove()
        else:
            self.rescale_panel.grid_remove()
            self.measure_panel.grid()

    def browse_sparse(self):
        p = filedialog.askdirectory(title="Select Sparse Directory")
        if p:
            self.sparse_path_var.set(p)

    def browse_images(self):
        p = filedialog.askdirectory(title="Select Images Directory")
        if p:
            self.images_path_var.set(p)

    def browse_mesh(self):
        p = filedialog.askopenfilename(
            title="Select Dense Mesh",
            filetypes=[("PLY / OBJ files", "*.ply *.obj"),
                       ("All files", "*.*")])
        if p:
            self.mesh_path_var.set(p)

    def load_reconstruction_manually(self):
        global _current_reconstruction, _current_reconstruction_path

        sparse = self.sparse_path_var.get().strip()
        if not sparse or not os.path.isdir(sparse):
            messagebox.showerror(
                "Error", "Valid Sparse Model Path is required.")
            return

        try:
            rec = pycolmap.Reconstruction(sparse)
        except Exception as e:
            messagebox.showerror(
                "Load failed",
                f"Could not load reconstruction:\n{e}")
            return

        if not rec.images:
            messagebox.showerror(
                "Load failed",
                "Reconstruction contains no images.")
            return

        _current_reconstruction = rec
        _current_reconstruction_path = sparse

        # Any prior calibration state belongs to a different model.
        self._reset_calibration_state()

        self._last_seen_recon_path = sparse

        unsupported_models = sorted({
            getattr(cam, "model_name", "")
            for cam in rec.cameras.values()
            if getattr(cam, "model_name", "")
            not in _SUPPORTED_PINHOLE_MODELS
        })
        warn_suffix = ""
        if unsupported_models:
            warn_suffix = ("  (WARNING: unsupported camera model(s) "
                           f"present: {', '.join(unsupported_models)}; "
                           "geometry-dependent measurement is disabled "
                           "for those cameras.)")

        self._refresh_reference_line()
        self.status_var.set(
            f"Loaded reconstruction: {len(rec.images)} images, "
            f"{len(rec.points3D)} 3D points, "
            f"{len(rec.cameras)} cameras.{warn_suffix}")

    def _poll_reconstruction(self):
        global _current_reconstruction_path
        if _current_reconstruction_path != self._last_seen_recon_path:
            self._last_seen_recon_path = _current_reconstruction_path
            self._refresh_reference_line()
        self.root.after(500, self._poll_reconstruction)

    def _refresh_reference_line(self):
        global _current_reconstruction, _current_reconstruction_path
        if _current_reconstruction is None:
            self.ref_var.set("Reference: (not loaded)")
            return
        self.ref_var.set(
            f"Reference: {_current_reconstruction_path} "
            f"({len(_current_reconstruction.points3D)} points, "
            f"{len(_current_reconstruction.images)} images)")

    def clear_slot(self, slot):
        if slot == 'A':
            self.slot_a = self._empty_slot()
        else:
            self.slot_b = self._empty_slot()
        self.distance_var.set("—")
        self.distance_3d_var.set("")
        self.distance_scale_var.set("")
        self._refresh_slots()
        self._refresh_scale_button_state()
        self._refresh_measure_button_state()
        self.status_var.set(f"Slot {slot} cleared.")

    def _slot_short(self, slot_name, d):
        if d['state'] == self.SLOT_EMPTY:
            return "(empty)"
        xyz = d.get('xyz')
        if xyz is not None:
            scale = _mean_scale()
            if scale is not None:
                v = np.asarray(xyz, dtype=np.float64) * scale
                return (f"{d['image']} · xyz=({v[0]:.3f}, "
                        f"{v[1]:.3f}, {v[2]:.3f}) [m]")
            return (f"{d['image']} · xyz=({xyz[0]:.3f}, "
                    f"{xyz[1]:.3f}, {xyz[2]:.3f}) [SfM]")
        return f"{d['image']} · no 3D point"

    def _slot_display(self, slot_name, d):
        if d['state'] == self.SLOT_EMPTY:
            return "(empty)"

        x, y = d['xy']
        base = (f"{d['image']} · kp #{d['kp_index']} · "
                f"xy=({x:.1f}, {y:.1f})")
        if d['xyz'] is None:
            return base + " · no 3D point"

        res = d['reproj_residual']
        res_str = f"{res:.2f}px" if res is not None else "n/a"
        scale = _mean_scale()
        if scale is not None:
            xm = d['xyz'] * scale
            xyz_str = (f" · xyz=({xm[0]:.3f}, {xm[1]:.3f}, "
                       f"{xm[2]:.3f}) [metric]")
        else:
            xyz_str = (f" · xyz=({d['xyz'][0]:.3f}, "
                       f"{d['xyz'][1]:.3f}, "
                       f"{d['xyz'][2]:.3f}) [SfM]")
        if d['pid'] is not None:
            src = f"pid={d['pid']}"
        elif d.get('from_target'):
            src = f"{d['from_target']}"
        else:
            src = "3D"
        return base + f" · {src} · resid={res_str}" + xyz_str

    def _format_point_cell(self, slot):
        """Compact cell text for the Point A / Point B columns.

        Format: ``kp=<kp_index>  xyz=(x, y, z)`` in SfM units.
        Non-applicable values are shown as em dashes.
        """
        if slot is None:
            return "—"
        kp = slot.get('kp_index')
        kp_str = f"kp={kp}" if kp is not None else "kp=—"
        xyz = slot.get('xyz')
        if xyz is not None:
            try:
                xyz_str = (f"xyz=({float(xyz[0]):.3f}, "
                           f"{float(xyz[1]):.3f}, "
                           f"{float(xyz[2]):.3f})")
            except Exception:
                xyz_str = "xyz=—"
        else:
            xyz_str = "xyz=—"
        return f"{kp_str}  {xyz_str}"

    def _slot_image_names(self, slot):
        """Distinct image names referenced by a slot's observations.

        Falls back to the slot's single 'image' field if the
        observations list is empty (2D-only measurement).
        """
        names = []
        seen = set()
        for o in (slot.get('observations') or []):
            name = o.get('image')
            if name and name not in seen:
                seen.add(name)
                names.append(name)
        if not names:
            name = slot.get('image')
            if name:
                names.append(name)
        return names

    def _format_px_image_cell(self, slot_a, slot_b):
        """Image names for the px image column.

        Collects every distinct image from either slot's
        observations. Duplicates are removed; order of appearance
        follows A first, then B.
        """
        seen = set()
        ordered = []
        for slot in (slot_a, slot_b):
            if not slot:
                continue
            for name in self._slot_image_names(slot):
                if name and name not in seen:
                    seen.add(name)
                    ordered.append(name)
        if not ordered:
            return "—"
        return ", ".join(ordered)

    def _format_d_value_cell(self, slot_a, slot_b):
        """Vector difference of the two target values, in SfM units.

        Computed directly from the same xyz values the popup shows in
        its Target value list, so the main-window and popup-window
        views of the measurement are always consistent.
        """
        xyz_a = slot_a.get('xyz') if slot_a else None
        xyz_b = slot_b.get('xyz') if slot_b else None
        if xyz_a is None or xyz_b is None:
            return "—"
        try:
            dx = float(xyz_b[0]) - float(xyz_a[0])
            dy = float(xyz_b[1]) - float(xyz_a[1])
            dz = float(xyz_b[2]) - float(xyz_a[2])
            if not (math.isfinite(dx) and math.isfinite(dy)
                    and math.isfinite(dz)):
                return "—"
            return f"({dx:.4f}, {dy:.4f}, {dz:.4f})"
        except Exception:
            return "—"

    def _refresh_slots(self):
        self.point_a_var.set(self._slot_display("A", self.slot_a))
        self.point_b_var.set(self._slot_display("B", self.slot_b))
        a_short = self._slot_short("A", self.slot_a)
        b_short = self._slot_short("B", self.slot_b)
        self.slot_summary_var.set(f"A: {a_short}    B: {b_short}")

    def _refresh_measure_button_state(self):
        both_filled = (self.slot_a['state'] == self.SLOT_FILLED
                       and self.slot_b['state'] == self.SLOT_FILLED)
        self.btn_add_point.config(
            state="normal" if both_filled else "disabled")

    def _refresh_scale_button_state(self):
        a = self.slot_a
        b = self.slot_b
        a_ok = (a['state'] == self.SLOT_FILLED
                and _slot_has_xyz(a))
        b_ok = (b['state'] == self.SLOT_FILLED
                and _slot_has_xyz(b))
        different = False
        if a_ok and b_ok:
            try:
                d = float(np.linalg.norm(a['xyz'] - b['xyz']))
                different = d > 1e-9
            except Exception:
                different = False
        self.btn_set_scale.config(
            state="normal" if (a_ok and b_ok and different)
            else "disabled")

    def _ensure_pid_index(self):
        global _current_reconstruction
        if _current_reconstruction is None:
            return None
        if (self._pid_index is not None
                and self._pid_index_recon is _current_reconstruction):
            return self._pid_index
        idx = {}
        for img in _current_reconstruction.images.values():
            pts = getattr(img, "points2D", None) or []
            for i, kp in enumerate(pts):
                pid = _keypoint_3d_id(kp)
                if pid is None:
                    continue
                idx.setdefault(pid, []).append((img.name, i))
        self._pid_index = idx
        self._pid_index_recon = _current_reconstruction
        return idx

    def on_selection_applied(self, slot_a, slot_b):
        self.slot_a = slot_a
        self.slot_b = slot_b
        self.distance_var.set("—")
        self.distance_3d_var.set("")
        self.distance_scale_var.set("")
        self._refresh_slots()
        self._refresh_scale_button_state()
        self._refresh_measure_button_state()
        self.status_var.set("Selection applied to main window.")

    def open_selection_dialog(self, default_slot='A'):
        global _current_reconstruction

        if self._selection_dialog is not None:
            try:
                if self._selection_dialog.winfo_exists():
                    self._selection_dialog.lift()
                    self._selection_dialog.focus_set()
                    return
            except tk.TclError:
                pass
            self._selection_dialog = None

        if _current_reconstruction is None:
            messagebox.showwarning(
                "No model",
                "Load a reconstruction first (either 'Load "
                "Reconstruction' or 'Launch Rerun Viewer').")
            return
        img_dir = self.images_path_var.get().strip()
        if not img_dir or not os.path.isdir(img_dir):
            messagebox.showwarning(
                "Images directory required",
                "Set a valid 'Images Directory' in the main window "
                "first.")
            return
        pid_index = self._ensure_pid_index()
        if pid_index is None:
            messagebox.showerror("Error",
                                 "Could not build pid index.")
            return

        dlg = KeypointSelectionDialog(
            self, _current_reconstruction, img_dir, pid_index,
            self.slot_a, self.slot_b, default_slot,
            on_apply_callback=self.on_selection_applied,
            purpose_callback=lambda: self.purpose_var.get())
        self._selection_dialog = dlg
        self.root.wait_window(dlg)
        self._selection_dialog = None

        if dlg.result is not None:
            self.on_selection_applied(*dlg.result)
            self.status_var.set("Selection committed.")

    def _compute_distance_for_pair(self, a, b):
        d_px = None
        px_image = None
        d_sfm = None
        d_metric = None

        obs_a = a.get('observations') or [{
            'image': a['image'],
            'xy': (np.asarray(a['xy'])
                   if a.get('xy') is not None else None),
        }]
        obs_b = b.get('observations') or [{
            'image': b['image'],
            'xy': (np.asarray(b['xy'])
                   if b.get('xy') is not None else None),
        }]

        for oa in obs_a:
            if oa.get('xy') is None:
                continue
            for ob in obs_b:
                if ob.get('xy') is None:
                    continue
                if oa['image'] == ob['image']:
                    d_px = float(np.linalg.norm(
                        np.asarray(oa['xy'])
                        - np.asarray(ob['xy'])))
                    px_image = oa['image']
                    break
            if d_px is not None:
                break

        if a.get('xyz') is not None and b.get('xyz') is not None:
            d_sfm = float(np.linalg.norm(a['xyz'] - b['xyz']))
            scale = _mean_scale()
            if scale is not None:
                d_metric = d_sfm * scale

        return d_px, px_image, d_sfm, d_metric

    def _on_add_point_clicked(self):
        if (self.slot_a['state'] != self.SLOT_FILLED
                or self.slot_b['state'] != self.SLOT_FILLED):
            self.status_var.set(
                "Both slots must be filled before Add Point can run.")
            return

        a = self.slot_a
        b = self.slot_b
        if (a['xyz'] is not None and b['xyz'] is not None
                and float(np.linalg.norm(a['xyz'] - b['xyz'])) < 1e-9):
            self.status_var.set(
                "Same 3D point in both slots — nothing to add.")
            return

        ts = _dt.datetime.now().strftime("%H:%M:%S")

        # Compute the derived cells now so the row is complete the
        # moment it appears. Measure still re-runs the same
        # computation for all rows, so nothing here is authoritative;
        # it just avoids a row that visibly has no values until the
        # user clicks Measure.
        scale = _mean_scale()
        _d_px, _px_image, _d_sfm, d_metric = \
            self._compute_distance_for_pair(a, b)

        try:
            values = (
                ts,
                self._format_point_cell(a),
                self._format_point_cell(b),
                self._format_px_image_cell(a, b),
                self._format_d_value_cell(a, b),
                f"{scale:.6f}" if scale is not None else "—",
                f"{d_metric:.6f}" if d_metric is not None else "—",
            )
        except Exception as e:
            self.status_var.set(
                f"Could not build measurement row: {e}")
            traceback.print_exc()
            return

        n_cols = len(self.measure_tree["columns"])
        if len(values) != n_cols:
            self.status_var.set(
                f"Internal error: {len(values)} values for "
                f"{n_cols} columns.")
            traceback.print_stack()
            return

        try:
            iid = self.measure_tree.insert(
                "", "end", values=values)
        except Exception as e:
            self.status_var.set(
                f"Could not insert measurement row: {e}")
            traceback.print_exc()
            return
        self.measure_tree.see(iid)

        self._measure_entries[iid] = {
            'timestamp': ts,
            'slot_a': {
                'image': a['image'], 'kp_index': a['kp_index'],
                'xy': np.asarray(a['xy'], dtype=np.float64).copy(),
                'pid': a['pid'],
                'xyz': (np.asarray(a['xyz'], dtype=np.float64).copy()
                        if a['xyz'] is not None else None),
                'reproj_residual': a['reproj_residual'],
                'observations': list(a.get('observations', [])),
            },
            'slot_b': {
                'image': b['image'], 'kp_index': b['kp_index'],
                'xy': np.asarray(b['xy'], dtype=np.float64).copy(),
                'pid': b['pid'],
                'xyz': (np.asarray(b['xyz'], dtype=np.float64).copy()
                        if b['xyz'] is not None else None),
                'reproj_residual': b['reproj_residual'],
                'observations': list(b.get('observations', [])),
            },
            'distance_px': _d_px,
            'px_image': _px_image,
            'scale': scale,
            'metric': d_metric,
            'reference_model': _current_reconstruction_path or "",
        }
        if a.get('xyz') is None or b.get('xyz') is None:
            self.status_var.set(
                "Added 2D-only measurement (no 3D coordinates for one "
                "or both slots). Pixel distance will be computed "
                "where A and B share an image; metric distance is "
                "unavailable.")
        elif _d_px is None:
            self.status_var.set(
                "Point pair added to Measurements. Note: Slot A and "
                "Slot B share no image, so the pixel distance is "
                "unavailable. Click Measure to compute 3D distances.")
        else:
            self.status_var.set(
                "Point pair added to Measurements. Click Measure to "
                "compute distances.")

    def _on_measure_run_clicked(self):
        if not self._measure_entries:
            self.status_var.set(
                "No entries in the Measurements list. Add points first.")
            return
        scale = _mean_scale()
        n_updated = 0
        for iid, entry in list(self._measure_entries.items()):
            a = entry['slot_a']
            b = entry['slot_b']
            d_px, px_image, d_sfm, d_metric = \
                self._compute_distance_for_pair(a, b)
            entry['distance_px'] = d_px
            entry['px_image'] = px_image
            entry['scale'] = scale
            entry['metric'] = d_metric
            try:
                a_str = self._format_point_cell(entry['slot_a'])
                b_str = self._format_point_cell(entry['slot_b'])
                px_str = self._format_px_image_cell(
                    entry['slot_a'], entry['slot_b'])
                self.measure_tree.item(
                    iid, values=(
                        entry['timestamp'],
                        a_str, b_str,
                        px_str,
                        f"{d_sfm:.6f}" if d_sfm is not None else "—",
                        f"{scale:.6f}" if scale is not None else "—",
                        f"{d_metric:.6f}" if d_metric is not None
                        else "—",
                    ))
                n_updated += 1
            except tk.TclError:
                continue

        if scale is None:
            self.status_var.set(
                f"Re-measured {n_updated} entries in SfM units "
                f"(no scale set). Pixel distances shown where A and B "
                f"share an image.")
        else:
            self.status_var.set(
                f"Re-measured {n_updated} entries with scale "
                f"{scale:.6f}.")

    def remove_selected_measure(self):
        for iid in self.measure_tree.selection():
            self._measure_entries.pop(iid, None)
            self.measure_tree.delete(iid)

    def clear_measurements(self):
        self._measure_entries.clear()
        for iid in self.measure_tree.get_children():
            self.measure_tree.delete(iid)

    def _edit_selected_anchor(self):
        sels = self.anchor_tree.selection()
        if not sels:
            self.status_var.set("Select an anchor row first.")
            return
        iid = sels[0]
        children = list(self.anchor_tree.get_children())
        try:
            idx = children.index(iid)
        except ValueError:
            return
        if not (0 <= idx < len(_scale_anchors)):
            return
        anchor = _scale_anchors[idx]
        dlg = EditAnchorDialog(self.root, anchor)
        self.root.wait_window(dlg)
        if dlg.result is None:
            return
        old_metric = anchor['metric']
        new_metric = dlg.result['metric']
        if not (math.isfinite(new_metric) and new_metric > 0):
            self.status_var.set(
                "Anchor metric value must be finite and positive.")
            return
        sfm = anchor.get('sfm', 0.0)
        if not (math.isfinite(sfm) and sfm > 0):
            self.status_var.set(
                "Anchor SfM distance is invalid; cannot recompute "
                "scale.")
            return
        new_scale = new_metric / sfm
        if not math.isfinite(new_scale) or new_scale <= 0:
            self.status_var.set(
                "Computed anchor scale is not finite and positive.")
            return
        anchor['metric'] = new_metric
        anchor['scale'] = new_scale
        try:
            vals = list(self.anchor_tree.item(iid, "values"))
            vals[4] = f"{anchor['metric']:.6f}"
            vals[5] = f"{anchor['scale']:.6f}"
            self.anchor_tree.item(iid, values=tuple(vals))
        except tk.TclError:
            pass
        self._refresh_scale_display()
        self._refresh_slots()
        self._refresh_measure_button_state()
        self.status_var.set(
            f"Anchor updated: {old_metric:.6f} → "
            f"{anchor['metric']:.6f} metric. Mean scale "
            f"{_mean_scale():.6f}.")

    def remove_selected_anchor(self):
        sels = self.anchor_tree.selection()
        if not sels:
            return
        children = list(self.anchor_tree.get_children())
        to_remove_indices = []
        for iid in sels:
            try:
                idx = children.index(iid)
                to_remove_indices.append(idx)
            except ValueError:
                continue
            self.anchor_tree.delete(iid)
        for idx in sorted(to_remove_indices, reverse=True):
            if 0 <= idx < len(_scale_anchors):
                del _scale_anchors[idx]
        self._refresh_scale_display()
        self._refresh_slots()
        self._refresh_measure_button_state()
        self.status_var.set("Anchor(s) removed.")

    def clear_anchors(self):
        _scale_anchors.clear()
        self._refresh_scale_display()
        for iid in self.anchor_tree.get_children():
            self.anchor_tree.delete(iid)
        self._refresh_slots()
        self._refresh_measure_button_state()
        self.status_var.set("Scale anchors cleared.")

    def export_history_csv(self):
        if not self._measure_entries:
            messagebox.showinfo("Nothing to export",
                                "No measurements yet.")
            return
        path = filedialog.asksaveasfilename(
            title="Export measurement history",
            defaultextension=".csv",
            filetypes=[("CSV", "*.csv"), ("All files", "*.*")])
        if not path:
            return
        try:
            import csv as _csv
            with open(path, "w", newline="",
                      encoding="utf-8") as f:
                w = _csv.writer(f)
                w.writerow(["time", "point_a", "point_b",
                            "distance_px", "px_image", "scale",
                            "metric_distance", "reference_model"])
                for iid in self.measure_tree.get_children():
                    e = self._measure_entries.get(iid)
                    if e is None:
                        continue
                    a, b = e['slot_a'], e['slot_b']
                    w.writerow([
                        e['timestamp'],
                        f"{a['image']}:kp={a['kp_index']} "
                        f"pid={a['pid']}",
                        f"{b['image']}:kp={b['kp_index']} "
                        f"pid={b['pid']}",
                        (f"{e['distance_px']:.3f}"
                         if e.get('distance_px') is not None else ""),
                        e.get('px_image') or "",
                        (f"{e['scale']:.6f}"
                         if e.get('scale') is not None else ""),
                        (f"{e['metric']:.4f}"
                         if e.get('metric') is not None else ""),
                        e['reference_model'],
                    ])
            self.status_var.set(
                f"Exported {len(self._measure_entries)} entries.")
        except Exception as e:
            messagebox.showerror("Export failed", str(e))

    def export_annotated_measurements(self):
        if not self._measure_entries:
            messagebox.showinfo(
                "Nothing to export",
                "The measurement history is empty.")
            return

        img_dir = self.images_path_var.get().strip()
        if not img_dir or not os.path.isdir(img_dir):
            messagebox.showwarning(
                "Images directory required",
                "Set a valid 'Images Directory' in the main window "
                "first.")
            return

        dst_root = filedialog.askdirectory(
            title="Choose destination for annotated measurements")
        if not dst_root:
            return

        ts = _dt.datetime.now().strftime("%Y%m%d_%H%M%S")
        export_root = Path(dst_root) / f"measurements_{ts}"
        try:
            export_root.mkdir(parents=True, exist_ok=True)
        except Exception as e:
            messagebox.showerror(
                "Export failed",
                f"Could not create destination directory:\n{e}")
            return

        written = 0
        skipped = []
        errors = []

        for iid in self.measure_tree.get_children():
            entry = self._measure_entries.get(iid)
            if entry is None:
                continue

            a, b = entry['slot_a'], entry['slot_b']
            a_part = f"{Path(a['image']).stem}_kp{a['kp_index']}"
            b_part = f"{Path(b['image']).stem}_kp{b['kp_index']}"
            folder_name = f"{written + 1:03d}_{a_part}__{b_part}"
            folder = export_root / folder_name

            try:
                folder.mkdir(parents=True, exist_ok=True)
            except Exception as e:
                errors.append(f"{folder_name}: mkdir failed ({e})")
                continue

            ok = self._annotate_pair(
                a, b, folder / "annotated.png", img_dir)
            if not ok:
                skipped.append(f"{folder_name}: annotated.png")

            self._annotate_image(
                image_name=a['image'], kp_index=a['kp_index'],
                pid=a['pid'], xy=a['xy'],
                out_path=folder / "image_A.png",
                tag="A", images_dir=img_dir, scale=entry['scale'])
            self._annotate_image(
                image_name=b['image'], kp_index=b['kp_index'],
                pid=b['pid'], xy=b['xy'],
                out_path=folder / "image_B.png",
                tag="B", images_dir=img_dir, scale=entry['scale'])

            try:
                with open(folder / "info.txt", "w",
                          encoding="utf-8") as f:
                    f.write(f"Measurement {written + 1}\n")
                    f.write("=" * 60 + "\n")
                    f.write(f"Timestamp: {entry['timestamp']}\n")
                    f.write(
                        f"Reference model: "
                        f"{entry['reference_model']}\n\n")
                    f.write("Point A\n-------\n")
                    f.write(f"  image: {a['image']}\n")
                    f.write(f"  kp_index: {a['kp_index']}\n")
                    f.write(f"  pixel_xy: ({a['xy'][0]:.2f}, "
                            f"{a['xy'][1]:.2f})\n")
                    f.write(f"  point3D_id: {a['pid']}\n")
                    if a['xyz'] is not None:
                        f.write(f"  xyz_sfm: ({a['xyz'][0]:.6f}, "
                                f"{a['xyz'][1]:.6f}, "
                                f"{a['xyz'][2]:.6f})\n")
                        if entry['scale'] is not None:
                            xm = a['xyz'] * entry['scale']
                            f.write(f"  xyz_metric: "
                                    f"({xm[0]:.6f}, {xm[1]:.6f}, "
                                    f"{xm[2]:.6f})\n")
                    f.write(f"  reprojection_residual_px: "
                            f"{a['reproj_residual']}\n\n")
                    f.write("Point B\n-------\n")
                    f.write(f"  image: {b['image']}\n")
                    f.write(f"  kp_index: {b['kp_index']}\n")
                    f.write(f"  pixel_xy: ({b['xy'][0]:.2f}, "
                            f"{b['xy'][1]:.2f})\n")
                    f.write(f"  point3D_id: {b['pid']}\n")
                    if b['xyz'] is not None:
                        f.write(f"  xyz_sfm: ({b['xyz'][0]:.6f}, "
                                f"{b['xyz'][1]:.6f}, "
                                f"{b['xyz'][2]:.6f})\n")
                        if entry['scale'] is not None:
                            xm = b['xyz'] * entry['scale']
                            f.write(f"  xyz_metric: "
                                    f"({xm[0]:.6f}, {xm[1]:.6f}, "
                                    f"{xm[2]:.6f})\n")
                    f.write(f"  reprojection_residual_px: "
                            f"{b['reproj_residual']}\n\n")
                    f.write("Distance\n--------\n")
                    if entry['distance_px'] is not None:
                        f.write(f"  pixel_distance: "
                                f"{entry['distance_px']:.3f}\n")
                        if entry.get('px_image'):
                            f.write(f"  pixel_pair_image: "
                                    f"{entry['px_image']}\n")
                    if entry['scale'] is not None:
                        f.write(f"  scale_used: "
                                f"{entry['scale']:.6f} metric/SfM\n")
                    if entry['metric'] is not None:
                        f.write(f"  metric_distance: "
                                f"{entry['metric']:.6f}\n")
            except Exception as e:
                errors.append(f"{folder_name}: info.txt ({e})")

            written += 1

        msg = [f"Exported {written} measurement folder(s) to:",
               str(export_root)]
        if skipped:
            msg.append("")
            msg.append(f"{len(skipped)} image(s) were not annotated:")
            msg.extend(f"  - {s}" for s in skipped[:10])
        if errors:
            msg.append("")
            msg.append("Errors:")
            msg.extend(f"  - {s}" for s in errors[:10])
        messagebox.showinfo("Export complete", "\n".join(msg))
        self.status_var.set(
            f"Exported {written} annotated measurement folder(s).")

    def _draw_marker_on_image(self, img, xy, tag, color):
        x = int(round(float(xy[0])))
        y = int(round(float(xy[1])))
        cv2.circle(img, (x, y), 18, color, 3, lineType=cv2.LINE_AA)
        cv2.circle(img, (x, y), 4, (0, 0, 255), -1,
                   lineType=cv2.LINE_AA)
        cv2.line(img, (x - 26, y), (x - 6, y), color, 2,
                 lineType=cv2.LINE_AA)
        cv2.line(img, (x + 6, y), (x + 26, y), color, 2,
                 lineType=cv2.LINE_AA)
        cv2.line(img, (x, y - 26), (x, y - 6), color, 2,
                 lineType=cv2.LINE_AA)
        cv2.line(img, (x, y + 6), (x, y + 26), color, 2,
                 lineType=cv2.LINE_AA)
        cv2.putText(img, tag, (x + 22, y - 22),
                    cv2.FONT_HERSHEY_SIMPLEX, 1.0, color, 2,
                    lineType=cv2.LINE_AA)

    def _annotate_pair(self, a, b, out_path, images_dir):
        path_a = os.path.join(images_dir, a['image'])
        path_b = os.path.join(images_dir, b['image'])
        if not (os.path.isfile(path_a) and os.path.isfile(path_b)):
            return False
        img_a = cv2.imread(path_a)
        img_b = cv2.imread(path_b) if a['image'] != b['image'] else img_a
        if img_a is None or img_b is None:
            return False

        color_a = (30, 150, 255)
        color_b = (255, 130, 200)

        if a['image'] == b['image']:
            img = img_a.copy()
            self._draw_marker_on_image(img, a['xy'], 'A', color_a)
            self._draw_marker_on_image(img, b['xy'], 'B', color_b)
            try:
                cv2.imwrite(str(out_path), img)
                return True
            except Exception:
                return False

        img_a = img_a.copy()
        img_b = img_b.copy()
        self._draw_marker_on_image(img_a, a['xy'], 'A', color_a)
        self._draw_marker_on_image(img_b, b['xy'], 'B', color_b)

        h = max(img_a.shape[0], img_b.shape[0])

        def _resize_h(im, h):
            s = h / float(im.shape[0])
            return cv2.resize(
                im, (max(1, int(im.shape[1] * s)), h),
                interpolation=cv2.INTER_AREA)

        img_a = _resize_h(img_a, h)
        img_b = _resize_h(img_b, h)
        sep = np.full((h, 10, 3), 40, dtype=np.uint8)
        combined = np.hstack([img_a, sep, img_b])

        try:
            cv2.imwrite(str(out_path), combined)
            return True
        except Exception:
            return False

    def _annotate_image(self, image_name, kp_index, pid, xy,
                        out_path, tag, images_dir, scale):
        src = os.path.join(images_dir, image_name)
        if not os.path.isfile(src):
            return False
        img = cv2.imread(src)
        if img is None:
            return False

        color = ((30, 150, 255) if tag == 'A'
                 else (255, 130, 200))
        self._draw_marker_on_image(img, xy, tag, color)

        x = int(round(float(xy[0])))
        y = int(round(float(xy[1])))
        lines = [
            f"[{tag}] {image_name}",
            f"kp #{kp_index}   pid={pid}",
            f"pixel=({x}, {y})",
        ]
        font = cv2.FONT_HERSHEY_SIMPLEX
        fs = 0.75
        th = 2
        pad = 8
        line_heights = []
        text_widths = []
        for ln in lines:
            (tw, height_), baseline = cv2.getTextSize(
                ln, font, fs, th)
            text_widths.append(tw)
            line_heights.append(height_ + baseline)
        bw = max(text_widths) + 2 * pad
        bh = sum(line_heights) + 2 * pad
        cv2.rectangle(img, (8, 8), (8 + bw, 8 + bh),
                      (20, 20, 20), -1)
        cv2.rectangle(img, (8, 8), (8 + bw, 8 + bh),
                      (255, 255, 255), 1)
        yy = 8 + pad
        for ln, lh in zip(lines, line_heights):
            cv2.putText(img, ln, (8 + pad, yy + lh - 6),
                        font, fs, (255, 255, 255), th,
                        lineType=cv2.LINE_AA)
            yy += lh
        try:
            cv2.imwrite(str(out_path), img)
            return True
        except Exception:
            return False

    def export_metric_sparse_model(self):
        global _current_reconstruction, _current_reconstruction_path

        if _current_reconstruction is None:
            messagebox.showwarning(
                "No model", "Load a reconstruction first.")
            return

        scale = _mean_scale()
        if scale is None:
            messagebox.showwarning(
                "No scale set",
                "Add at least one scale anchor before exporting a "
                "metric model.")
            return

        sparse_src = (Path(_current_reconstruction_path)
                      if _current_reconstruction_path else None)
        images_dir = (Path(self.images_path_var.get())
                      if self.images_path_var.get() else None)

        can_copy_images = (images_dir is not None
                           and images_dir.is_dir())
        db_path = _find_database_db(sparse_src, images_dir)
        can_copy_db = db_path is not None

        opts_dlg = MetricExportOptionsDialog(
            self.root, can_copy_images, can_copy_db)
        self.root.wait_window(opts_dlg)
        if opts_dlg.result is None:
            return

        dst_root = filedialog.askdirectory(
            title="Choose destination folder for the metric project")
        if not dst_root:
            return

        ts = _dt.datetime.now().strftime("%Y%m%d_%H%M%S")
        out_root = Path(dst_root) / f"metric_project_{ts}"
        try:
            out_root.mkdir(parents=True, exist_ok=True)
        except Exception as e:
            messagebox.showerror("Export failed", str(e))
            return

        errors = []

        sparse_out = out_root / "sparse" / "0"
        try:
            errs = _write_metric_colmap_model(
                _current_reconstruction, scale, sparse_out,
                fmt=opts_dlg.result['format'])
        except Exception as e:
            shutil.rmtree(str(out_root), ignore_errors=True)
            messagebox.showerror(
                "Export failed",
                f"Could not write sparse model:\n{e}")
            return

        if errs:
            # Any sparse-model serialization error makes the export
            # invalid. Remove the partially-created project so it
            # cannot be mistaken for a completed export.
            shutil.rmtree(str(out_root), ignore_errors=True)
            msg = ["Sparse-model export failed. "
                   "Serialization errors:"]
            for name, err in errs[:20]:
                msg.append(f"  - {name}: {err}")
            if len(errs) > 20:
                msg.append(f"  ... and {len(errs) - 20} more")
            messagebox.showerror("Export failed", "\n".join(msg))
            return

        # Reload the written model and compare counts against the
        # in-memory reconstruction. If this fails, remove the
        # partial export.
        try:
            reloaded = pycolmap.Reconstruction(str(sparse_out))
            expected_cams = len(_current_reconstruction.cameras)
            expected_imgs = len(_current_reconstruction.images)
            expected_pts = len(_current_reconstruction.points3D)
            got_cams = len(reloaded.cameras)
            got_imgs = len(reloaded.images)
            got_pts = len(reloaded.points3D)
            if (got_cams != expected_cams
                    or got_imgs != expected_imgs
                    or got_pts != expected_pts):
                raise RuntimeError(
                    f"integrity mismatch: cameras {got_cams}/"
                    f"{expected_cams}, images {got_imgs}/"
                    f"{expected_imgs}, points {got_pts}/"
                    f"{expected_pts}")
        except Exception as e:
            shutil.rmtree(str(out_root), ignore_errors=True)
            messagebox.showerror(
                "Export failed",
                f"Exported model failed reload validation:\n{e}")
            return

        if opts_dlg.result['include_images'] and can_copy_images:
            try:
                shutil.copytree(str(images_dir),
                                str(out_root / "images"))
            except Exception as e:
                errors.append(("images/", str(e)))

        if opts_dlg.result['include_db'] and can_copy_db:
            try:
                shutil.copy2(str(db_path),
                             str(out_root / "database.db"))
            except Exception as e:
                errors.append(("database.db", str(e)))

        try:
            with open(out_root / "rescale_info.txt", "w",
                      encoding="utf-8") as f:
                f.write("Metric rescale metadata\n")
                f.write("=" * 60 + "\n")
                f.write(f"Timestamp: {ts}\n")
                f.write(
                    f"Source model: "
                    f"{_current_reconstruction_path or '(in-memory)'}\n")
                f.write(
                    f"Sparse format: "
                    f"{opts_dlg.result['format']}\n")
                f.write(
                    f"Scale applied: {scale:.17g} metric/SfM\n")
                f.write(
                    f"Anchors used: {len(_scale_anchors)}\n\n")
                for i, a in enumerate(_scale_anchors, 1):
                    f.write(
                        f"Anchor {i}: "
                        f"a_kind={a['a_kind']} a_ref={a['a_ref']} "
                        f"b_kind={a['b_kind']} b_ref={a['b_ref']} "
                        f"sfm={a['sfm']:.6f} "
                        f"metric={a['metric']:.6f} "
                        f"ratio={a['scale']:.6f}\n")
                f.write("\n")
                f.write(
                    "Note: tvec in images and xyz in points3D were "
                    "multiplied by the scale. Rotations, intrinsics, "
                    "and per-image observations were left unchanged.\n")
        except Exception as e:
            errors.append(("rescale_info.txt", str(e)))

        msg = ["Exported metric COLMAP project to:",
               str(out_root), ""]
        msg.append(f"Sparse format: {opts_dlg.result['format']}")
        msg.append(
            f"Scale applied: {scale:.6f} metric units per SfM unit")
        msg.append(f"Anchors used: {len(_scale_anchors)}")
        if opts_dlg.result['include_images'] and can_copy_images:
            msg.append(f"Images copied from: {images_dir}")
        if opts_dlg.result['include_db'] and can_copy_db:
            msg.append(f"Database copied from: {db_path}")

        if errors:
            msg.append("")
            msg.append(f"Issues ({len(errors)}):")
            for name, err in errors[:10]:
                msg.append(f"  - {name}: {err}")
            messagebox.showwarning(
                "Export completed with issues", "\n".join(msg))
        else:
            messagebox.showinfo("Export complete", "\n".join(msg))

        self.status_var.set(
            f"Exported metric project to {out_root} "
            f"(scale {scale:.6f})")

    def export_metric_points_ply(self):
        global _current_reconstruction

        if _current_reconstruction is None:
            messagebox.showwarning(
                "No model", "Load a reconstruction first.")
            return

        scale = _mean_scale()
        if scale is None:
            messagebox.showwarning(
                "No scale set",
                "Add at least one scale anchor before exporting.")
            return
        if not (math.isfinite(scale) and scale > 0):
            messagebox.showerror(
                "Export failed",
                f"Scale is not finite and positive: {scale!r}")
            return

        # Pre-scan: any point whose scaled coordinates do not fit
        # the 32-bit float precision promised by the PLY header is
        # treated as a fatal export error. A partial point cloud
        # that is reported as complete is worse than no export.
        n_total = 0
        n_bad = 0
        bad_examples = []
        for pid, p in _current_reconstruction.points3D.items():
            n_total += 1
            try:
                x = float(p.xyz[0]) * scale
                y = float(p.xyz[1]) * scale
                z = float(p.xyz[2]) * scale
            except Exception:
                x = y = z = float("nan")
            if not (_fits_float32(x) and _fits_float32(y)
                    and _fits_float32(z)):
                n_bad += 1
                if len(bad_examples) < 5:
                    bad_examples.append(pid)

        if n_bad > 0:
            sample = ", ".join(str(pid) for pid in bad_examples)
            messagebox.showerror(
                "Export failed",
                f"{n_bad} of {n_total} point(s) have scaled "
                f"coordinates that cannot be represented as a "
                f"32-bit float. Export aborted.\n\n"
                f"Example point IDs: {sample}\n\n"
                f"The PLY header declares coordinates as 32-bit "
                f"floats (property float). Values that are NaN, "
                f"infinite, or outside the 32-bit range are "
                f"rejected to avoid writing an unreadable or "
                f"partially-invalid point cloud.\n\n"
                f"Check the reconstruction and the scale value "
                f"before retrying.")
            self.status_var.set(
                f"PLY export aborted: {n_bad} point(s) not "
                f"representable as 32-bit float.")
            return
        path = filedialog.asksaveasfilename(
            title="Export metric point cloud",
            defaultextension=".ply",
            filetypes=[("PLY files", "*.ply"), ("All files", "*.*")])
        if not path:
            return

        try:
            with open(path, "w", encoding="utf-8") as f:
                f.write("ply\n")
                f.write("format ascii 1.0\n")
                f.write("comment units metric\n")
                f.write(f"comment scale_applied {scale:.17g} "
                        f"metric_per_sfm_unit\n")
                f.write(f"comment anchor_count {len(_scale_anchors)}\n")
                f.write(f"element vertex {n_total}\n")
                f.write("property float x\n")
                f.write("property float y\n")
                f.write("property float z\n")
                f.write("property uchar red\n")
                f.write("property uchar green\n")
                f.write("property uchar blue\n")
                f.write("end_header\n")
                for pid, p in _current_reconstruction.points3D.items():
                    x = float(p.xyz[0]) * scale
                    y = float(p.xyz[1]) * scale
                    z = float(p.xyz[2]) * scale
                    try:
                        r = int(p.color[0])
                        g = int(p.color[1])
                        b = int(p.color[2])
                    except Exception:
                        r = g = b = 255
                    f.write(
                        f"{x:.6f} {y:.6f} {z:.6f} {r} {g} {b}\n")
        except Exception as e:
            messagebox.showerror("Export failed", str(e))
            return

        self.status_var.set(
            f"Exported {n_total} metric points to {path} "
            f"(scale {scale:.6f})")
        messagebox.showinfo(
            "Export complete",
            f"Exported {n_total} points to:\n{path}\n\n"
            f"Scale applied: {scale:.6f} metric units per SfM unit\n"
            f"Anchors used: {len(_scale_anchors)}")

    def do_set_scale(self):
        global _recording_stream

        a = self.slot_a
        b = self.slot_b
        if not (_slot_has_xyz(a) and _slot_has_xyz(b)):
            self.status_var.set(
                "Add Scale Anchor requires two slots with valid 3D "
                "points. One of the slots has no XYZ (manual-only "
                "observation or failed triangulation).")
            return

        try:
            sfm = float(np.linalg.norm(a['xyz'] - b['xyz']))
        except Exception:
            self.status_var.set(
                "Could not compute SfM distance from slot "
                "coordinates.")
            return
        if not math.isfinite(sfm) or sfm <= 1e-9:
            self.status_var.set("Picked 3D points are coincident.")
            return

        try:
            known = float(self.known_var.get().strip())
            if not math.isfinite(known) or known <= 0:
                raise ValueError("must be finite and positive")
        except ValueError:
            self.status_var.set(
                "Known metric distance must be a finite positive "
                "number.")
            return

        ratio = known / sfm
        if not math.isfinite(ratio) or ratio <= 0:
            self.status_var.set(
                "Computed scale is not finite and positive.")
            return
        a_kind = 'pid' if a['pid'] is not None else 'target'
        b_kind = 'pid' if b['pid'] is not None else 'target'
        a_ref = (a['pid'] if a_kind == 'pid'
                 else (a.get('from_target') or 'unknown'))
        b_ref = (b['pid'] if b_kind == 'pid'
                 else (b.get('from_target') or 'unknown'))

        _scale_anchors.append({
            'a_kind': a_kind, 'a_ref': a_ref,
            'b_kind': b_kind, 'b_ref': b_ref,
            'a_xyz': np.asarray(a['xyz'], dtype=np.float64).copy(),
            'b_xyz': np.asarray(b['xyz'], dtype=np.float64).copy(),
            'sfm': sfm, 'metric': known, 'scale': ratio,
        })
        mean = _mean_scale()
        self._refresh_scale_display()

        ts = _dt.datetime.now().strftime("%H:%M:%S")
        a_xyz_str = (f"({a['xyz'][0]:.3f}, {a['xyz'][1]:.3f}, "
                     f"{a['xyz'][2]:.3f})")
        b_xyz_str = (f"({b['xyz'][0]:.3f}, {b['xyz'][1]:.3f}, "
                     f"{b['xyz'][2]:.3f})")
        iid = self.anchor_tree.insert(
            "", "end",
            values=(ts,
                    a_xyz_str,
                    b_xyz_str,
                    f"{sfm:.6f}", f"{known:.6f}",
                    f"{ratio:.6f}"),
        )
        self.anchor_tree.see(iid)

        self.distance_var.set("—")
        self.distance_3d_var.set("")
        self.distance_scale_var.set("")

        self.status_var.set(
            f"Anchor added: {sfm:.4f} SfM → {known} metric "
            f"(ratio {ratio:.6f}). Mean {mean:.6f} over "
            f"{len(_scale_anchors)} anchor"
            f"{'s' if len(_scale_anchors) != 1 else ''}.")
        self._refresh_slots()

        if _recording_stream is not None:
            try:
                rr.log("measurements/scale/log",
                       rr.TextLog(
                           f"scale anchor: "
                           f"a_kind={a_kind} a_ref={a_ref} "
                           f"b_kind={b_kind} b_ref={b_ref} "
                           f"sfm={sfm:.6f} metric={known} "
                           f"ratio={ratio:.6f} mean={mean:.6f} "
                           f"n={len(_scale_anchors)}"))
                _safe_flush()
            except Exception as e:
                print(f"WARNING: scale provenance log failed: {e}")

    def do_clear_scale(self):
        _scale_anchors.clear()
        self._refresh_scale_display()
        for iid in self.anchor_tree.get_children():
            self.anchor_tree.delete(iid)
        self._refresh_slots()
        self.distance_var.set("—")
        self.distance_3d_var.set("")
        self.distance_scale_var.set("")
        self.status_var.set("Scale anchors cleared.")

    def _refresh_scale_display(self):
        mean = _mean_scale()
        if mean is None:
            self.scale_var.set("(no scale set)")
            self.model_units_var.set(
                "Model units: SfM (unscaled). Distances and "
                "coordinates are shown in SfM units.")
        else:
            n = len(_scale_anchors)
            self.scale_var.set(
                f"{mean:.6f} metric units per SfM unit "
                f"({n} anchor{'s' if n != 1 else ''})")
            self.model_units_var.set(
                f"Model units: metric. 1 SfM unit = {mean:.6f} "
                f"metric units. All distances and coordinates below "
                f"are shown in metric units.")
        self._refresh_scale_value_display()

    def _refresh_scale_value_display(self):
        if _scale_value_script_path:
            self.sv_method_var.set(
                f"custom: {os.path.basename(_scale_value_script_path)}")
        else:
            self.sv_method_var.set("mean (built-in)")

        mean = _mean_scale()
        if mean is None:
            self.sv_value_var.set(
                "Value: —  (no anchors; model units are SfM)")
        else:
            n = len(_scale_anchors)
            self.sv_value_var.set(
                f"Value: {mean:.6f} metric units per SfM unit  ·  "
                f"computed from {n} anchor"
                f"{'s' if n != 1 else ''}")

    def _select_scale_value_script(self):
        path = filedialog.askopenfilename(
            title="Select scale value calculation script",
            filetypes=[("Python scripts", "*.py"),
                       ("All files", "*.*")],
            parent=self.root)
        if not path:
            return
        if _set_scale_value_script(path):
            self.status_var.set(f"Scale value script set: {path}")
        else:
            messagebox.showerror(
                "Script error",
                "Could not load the scale value script. It must "
                "define a callable named compute_scale(anchors). "
                "Falling back to built-in mean.")
            _set_scale_value_script(None)
        self._refresh_scale_display()
        self._refresh_slots()
        self._refresh_measure_button_state()

    def _reset_scale_value_script(self):
        _set_scale_value_script(None)
        self.status_var.set("Scale value method reset to mean.")
        self._refresh_scale_display()
        self._refresh_slots()
        self._refresh_measure_button_state()

    def run_script(self):
        sparse = self.sparse_path_var.get()
        images = self.images_path_var.get()

        if not sparse or not os.path.exists(sparse):
            messagebox.showerror(
                "Error", "Valid Sparse Model Path is required.")
            return
        if not images or not os.path.exists(images):
            messagebox.showerror(
                "Error", "Valid Images Directory is required.")
            return

        try:
            downscale = float(self.downscale_var.get())
            radii = float(self.point_radii_var.get())
            max_err = float(self.max_error_var.get())
            min_trk = int(self.min_track_var.get())
        except (tk.TclError, ValueError) as e:
            messagebox.showerror("Error", f"Invalid numeric input: {e}")
            return

        blueprint_key = self.blueprint_var.get()
        if blueprint_key not in BLUEPRINT_PRESETS:
            messagebox.showerror(
                "Error", f"Unknown blueprint: {blueprint_key}")
            return

        def _on_commit(new_path):
            # Runs on the worker thread. Marshal to the Tk main
            # thread. Tkinter's after() is safe to call from a
            # worker thread as long as Tcl was built with thread
            # support (the default on CPython 3.x for Windows and
            # Linux).
            try:
                self.root.after(
                    0, self._on_new_reconstruction_committed,
                    new_path)
            except tk.TclError:
                pass

        def _worker():
            try:
                launch_visualization(
                    sparse, images,
                    downscale, radii,
                    self.load_features_var.get(),
                    self.only_triangulated_var.get(),
                    max_err,
                    min_trk, self.draw_traj_var.get(),
                    self.mesh_path_var.get(), blueprint_key,
                    on_reconstruction_committed=_on_commit,
                )
            except Exception as e:
                print(f"WARNING: visualization worker raised: {e}")
                traceback.print_exc()

        threading.Thread(target=_worker, daemon=True).start()


if __name__ == "__main__":
    root = tk.Tk()
    app = ColmapViewerApp(root)
    root.mainloop()